 package model;

import sim.engine.*;
import util.Functions;

import org.eclipse.collections.impl.list.mutable.primitive.FloatArrayList;
import org.eclipse.collections.impl.list.mutable.primitive.IntArrayList;

/**
 * Class of the players of the EGT with influencers to determine opinion dynamics

 * @author mchica
 * @date 2022/06/16
 *
 */

public class GamerAgent implements Steppable {

	// ########################################################################
	// Variables
	// ########################################################################	

	
	private static final long serialVersionUID = 1L;

	//--------------------------------- Fixed -------------------------------//
						
	int gamerAgentId;				// A unique agent Id
		
	float opinion;					// continuous value for the agent' opinion o_j (probability to cooperate)
	
	FloatArrayList opinions;		// array with the evolution of the opinions
	
	int currentStep;				// the current step of the simulation
	
	boolean influencer;				// true if this agent is an influencer

	int degree;						// to speed up, just count the neighbors once.
	
	//------------------------------- Dynamic -------------------------------// 
			
	float currentFitness = Float.MIN_VALUE; // Fitness obtained by the agent at this step
	float previousFitness = Float.MIN_VALUE; // Fitness obtained by the agent previous step

	byte currentStrategy = ModelParameters.UNDEFINED_STRATEGY; // current strategy used by the agent
	byte previousStrategy = ModelParameters.UNDEFINED_STRATEGY; // strategy used by the agent in the previous step
	

	// ########################################################################
	// Constructors
	// ######################################################################## 		
	
	/**
	 * Initializes a new instance of the ClientAgent class.
	 * @param _strategy is the strategy used at the beginning of the simulation
	 * @param _maxSteps the max steps of the simulation
	 * 
	 */
	public GamerAgent( int _gamerId, 
					   byte _strategy, float _opinion,
						int _maxSteps) { 
	    		
		this.gamerAgentId = _gamerId;
		this.currentStrategy = _strategy;
		this.opinion = _opinion;
		this.influencer = false;
		
		this.opinions = new FloatArrayList(_maxSteps);	
	}	
	
	// ########################################################################	
	// Methods/Functions 	
	// ########################################################################

	//--------------------------- Get/Set methods ---------------------------//


	public boolean isInfluencer() {
		return this.influencer;
	}

	public void setInfluencer(boolean _inf) {
		this.influencer = _inf;
	}
	
	/**
	 * Gets the id of the agent
	 * @return
	 */
	public int getGamerAgentId() {
		return gamerAgentId;
	}

	/**
	 * Sets the id of the agent
	 * @param gamerAgentId
	 */
	public void setGamerAgentId(int _gamerAgentId) {
		this.gamerAgentId = _gamerAgentId;
	}
	

	/**
	 * Gets the current payoff of the agent
	 * 
	 * @return - the payoff
	 */
	public float getCurrentFitness() {
		return this.currentFitness;
	}

	/**
	 * Sets the current payoff of the agent
	 * 
	 * @param _strategy - the current payoff to be set
	 */
	public void setCurrentFitness(float _f) {
		this.currentFitness = _f;
	}

	/**
	 * Gets the previous payoff of the agent
	 * 
	 * @return - the payoff
	 */
	public float getPreviousFitness() {
		return this.previousFitness;
	}
	

	/**
	 * 
	 * @param _step
	 * @return
	 */
	public void addPastOpinion (float _value) {
		this.opinions.add(_value);
	}
	
	/**
	 * 
	 * @param _step
	 * @return
	 */
	public void setOpinionAtStep (int _step, float _value) {
		this.opinions.set(_step, _value);
	}
	

	/** 
	 * 
	 * @param _step
	 * @return
	 */
	public float getOpinionAtStep (int _step) {
		return this.opinions.get(_step);
	}

	/**
	 * 
	 * @return
	 */
	public FloatArrayList getOpinionEvolution () {
		return this.opinions;
	}
	
	
	public int getDegree() {
		return degree;
	}

	public void setDegree(int degree) {
		this.degree = degree;
	}
	
	/**
	 * Sets the previous Fitness of the agent
	 * 
	 * @param _strategy - the current Fitness to be set
	 */
	public void setPreviousFitness(float _f) {
		this.previousFitness = _f;
	}

	/**
	 * Gets the current strategy of the agent
	 * 
	 * @return - the strategy
	 */
	public byte getCurrentStrategy() {
		return this.currentStrategy;
	}

	/**
	 * Sets the strategy status of the agent
	 * 
	 * @param _strategy - the current strategy to be set
	 */
	public void setCurrentStrategy(byte _strategy) {
		this.currentStrategy = _strategy;
	}

	/**
	 * Gets the previous strategy of the agent
	 * 
	 * @return - the strategy
	 */
	public byte getPreviousStrategy() {
		return this.previousStrategy;
	}

	/**
	 * Sets the previous strategy of the agent
	 * 
	 * @param _strategy - the current strategy to be set
	 */
	public void setPreviousStrategy(byte _strategy) {
		this.previousStrategy = _strategy;
	}

	/**
	 * Returns true if the agent has changed its strategy this step. False if it has
	 * the same
	 */
	public boolean hasChangedStrategyAtStep(int _step) {

		if ((_step > 0) && (this.getCurrentStrategy() != this.getPreviousStrategy()) )
			return true;
		else
			return false;
		
	}


	/**
	 * Gets the prob 
	 */
	public float getOpinion() {
		return this.opinion;
	}

	/**
	 * Sets the prob 
	 */
	public void setOpinion(float _prob) {
		this.opinion = _prob;
	}
		
	
	/**
	 * With this function we update the strategy with a stochastic pairwise rule using the Fermi distribution
	 * 
	 * Depending on the existence of network in the model, we compare just with the neighbors or with all the population (WM)
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return true if the agent has changed its strategy w.r.t. its previous strategy
	 */
	private boolean fermiRuleForFollowers (SimState state) {

		Model model = (Model) state;				
		GamerAgent neighbor;	
		
		// check if there is a network
		int j = -1;
		
		// first choose an agent at random from the pop or direct contacts in case we have a network

		if (!model.params.getNetworkOption()) {
			
			do {
				
				// get one agent at random to imitate (from the whole pop
				j = model.random.nextInt(model.agents.size());
				neighbor = (GamerAgent) (model.getAgents()).get(j);
				
			} while (this.gamerAgentId == neighbor.getGamerAgentId());
			
		} else {
			
			
			IntArrayList neighbors = model.socialNetwork.getNeighborsOfNode(this.gamerAgentId);

			if (neighbors.size() > 0) {
								
				// there is a network so pick up one direct contact at random			
				j = model.random.nextInt(neighbors.size());

				neighbor = (GamerAgent) (model.getAgents()).get(neighbors.get(j));
				
			} else {
				
				// this node has no neighbors so it cannot copy anyone
				return false;		
			}			
		}
										
		// calculate the prob using the Fermi distribution and fitness difference
			
		double probFermi = Functions.fermiFunction(neighbor.getPreviousFitness (), this.getPreviousFitness (), model.params.getFloatParameter("betaRule"));								

		// Check if the agent adopts the neighbor's strategy
		
		double r = model.random.nextDouble();

		//System.out.println("probFermi=" + probFermi + " and r = " + r);
		
		if (r < probFermi) {
			
			// change the strategy!			
			// this.setCurrentStrategy(neighbor.getPreviousStrategy());

			// also copy the opinion
			this.setOpinion(neighbor.getOpinion());
			
			return true;
		}
										
		return false;		
	}

	/**
	 * With this function model the opinion dynamics following the HK or traditional DeGroot model (if flag is true)
	 * 	 * 
	 * The model works by creating a set with agents having opinion similar to the focal one given by an epsilon.
	 * If DeGroot is true, epsilon is 1, so all the agents' opinions are accepted.
	 * From the set of filtered agents, we aggregate their opinions by their weights (fitness-based)
	 * 
	 * Only implemented with a SN
	 * 
	 * @param state - a simulation model object (SimState).
	 * @param deGroot  - true if we do not consider the epsilon filter for creating a set
	 * @return true if the agent has changed its strategy w.r.t. its previous strategy
	 */
	private boolean HK (SimState state, boolean deGroot) {

		Model model = (Model) state;				
		GamerAgent neighbor;	
		
		float weight = 0;
		
		IntArrayList neighbors = model.socialNetwork.getNeighborsOfNode(this.gamerAgentId);

		// we get epsilon and set to sufficiently high value (e.g., 2) if DeGroot model is ON
		float epsilon = model.params.getFloatParameter("epsilonBC");

		if (deGroot)
			epsilon = 2;

		float newOpinion = 0;		
		float sumWeights = 0;
		boolean atLeastOneNeighbor = false;
		
		//System.out.println("\n---agent " + this.gamerAgentId + " has " + neighbors.size() + " neighs. O_i = " + this.opinion);
		
		for (int i = 0; i < neighbors.size(); i++) {
			
			neighbor = (GamerAgent) (model.getAgents()).get(neighbors.get(i));
			
			//System.out.println("neigh " + neighbor.gamerAgentId + " : o_j=" + neighbor.getOpinion() + " (being \\epsilon= " + epsilon);

			if (Math.abs(neighbor.getOpinion() - this.opinion) < epsilon) {
				
				atLeastOneNeighbor = true;
				
				// the weight is coming from the same Fermi function
				weight = (float) Functions.fermiFunction(neighbor.getPreviousFitness (), this.getPreviousFitness (), model.params.getFloatParameter("betaRule"));								

				sumWeights += weight;
				
				newOpinion += (weight * neighbor.getOpinion());

				//System.out.println("neigh accepted. W_ij = " + weight + ", w_ijo_ij=" + (weight * neighbor.getOpinion()) + ", sumWeights=" + sumWeights + " newOpinion = " + newOpinion);
			}											
		}

		// add the focal agent itself
		weight = (float )0.5;  // always 1/2 as fx difference is 0	
		
		sumWeights += weight;
		
		newOpinion += (weight * this.opinion);
		
		if (atLeastOneNeighbor) {
			
			// divide by the sum of weights to normalize
			newOpinion /= sumWeights;
											
			// linear combination of the opinion with previous opinion of the focal agent
			this.opinion = newOpinion;
			
			//System.out.println("Opinion changed to " + newOpinion);

			return true;
			
		} else {
			
			// no neighbors to interchange opinion
			
			//System.out.println("No opinion changed. It is " + opinion);
			
			return false;
		}
	}

	/**
	 * With this function model the opinion dynamics following the DW opinion dynamics model.
	 * Basically, we get one at random from the neighborhood and update the opinion if it is below threshold \epsilon
	 * 
	 * Only implemented with a SN
	 * 
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return true if the agent has changed its strategy w.r.t. its previous strategy
	 */
	private boolean DW (SimState state) {

		Model model = (Model) state;				
		GamerAgent neighbor;	
		
		float weight = 0;
		
		float mu = model.params.getFloatParameter("muDW");
		float epsilon = model.params.getFloatParameter("epsilonBC");
		
		IntArrayList neighbors = model.socialNetwork.getNeighborsOfNode(this.gamerAgentId);
		
		// there is a network so pick up one direct contact at random			
		int j = model.random.nextInt(neighbors.size());

		neighbor = (GamerAgent) (model.getAgents()).get(neighbors.get(j));
				
		//System.out.println("\n---agent " + this.gamerAgentId + " with opinion " + opinion + ". Neighbor at random " + neighbor.getGamerAgentId() + " with o_i = " + neighbor.getOpinion() );
		
		// check \epsilon constraint for similar opinion
		if (Math.abs(neighbor.getOpinion() - this.opinion) < epsilon) {
					
			// the weight is coming from the same Fermi function
			weight =  (2 * mu) * (float) Functions.fermiFunction(neighbor.getPreviousFitness (), this.getPreviousFitness (), model.params.getFloatParameter("betaRule"));								
				
			// update focal agent's opinion directly by adding or subtracting neighbor's opinion
			this.opinion += (weight * (neighbor.getOpinion() - this.opinion));
			
			//System.out.println("neigh accepted. W_ij = " + weight + ", w_ijo_ij=" + (weight * (neighbor.getOpinion() - this.opinion)) + ", so new opinion is " + this.opinion);
			
		}									
				
		return true;
	}

	/**
	 * With this function we apply the Fermi rule but just among influencers, without taking into account
	 * the network but just the array of influencers in the population
	 * 
 	 * 
	 * @param state - a simulation model object (SimState).
	 * @return true if the agent has changed its strategy w.r.t. its previous strategy
	 */
	private boolean fermiRuleForInfluencers (SimState state) {

		Model model = (Model) state;				
		GamerAgent neighbor;	
		int idInfluencerToImitate;
		

		// choose one influencer agent at random without being the agent itself
		if (model.getInfluencersNodes().size() > 1) {			
			do {
	
				idInfluencerToImitate = model.getInfluencerAtRandom ();
				
			} while (this.gamerAgentId == idInfluencerToImitate);
			
		} else {
			
			// there is only one influencer, we cannot imitate
			return false;
		}
				
		neighbor = (GamerAgent)model.agents.get(idInfluencerToImitate); 							
						
		// calculate the prob using the Fermi distribution and fitness difference			
		double probFermi = Functions.fermiFunction(neighbor.getPreviousFitness (), this.getPreviousFitness (), model.params.getFloatParameter("betaRule"));								

		// Check if the agent adopts the neighbor's strategy
		
		double r = model.random.nextDouble();
								
		if(r < probFermi) {
			
			// change the strategy!
			
			this.setCurrentStrategy(neighbor.getPreviousStrategy());
							
			return true;
		}		
									
		return false;		
	}

	
	// -------------------------- Payoffs and fitness methods --------------------------//

	/**
	 * This function is called to calculate the payoffs of the play of the agent
	 * without a network. The payoff is calculated following the payoff matrix of the defined game
	 * and using one player from the pop or a group of them
	 * 
	 * It is a pairwise game where we accumulate the games' payoffs played by each pair of players
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return the payoff of the agent in this step
	 */
	public double calculatePayoffWM(SimState state) {

		Model model = (Model) state;
					
		// setting the fitness to the agent according to the utility matrix

		// System.out.println("\nFocal-" + this.gamerAgentId + " (str. " + this.getCurrentStrategy() + ")");		 

		this.currentFitness = (float) 0;
		
		float S = (float) model.params.getIntParameter("S");
		float T = (float) model.params.getIntParameter("T");
		

		// get one agent at random to imitate (from the whole pop
		int j = model.random.nextInt(model.agents.size());
		GamerAgent playerToPlay = (GamerAgent) (model.getAgents()).get(j);
		
			
		// System.out.print("\n -Neigh-" + neighbor.gamerAgentId + " (str. " + neighbor.getCurrentStrategy() + ")");		 

		float payoffWithNeighbor = 0;
		
		// depending on the strategy of focal and neighbor, we have different payoff values
	
		if (this.currentStrategy == ModelParameters.COOPERATOR) {
			
			if (playerToPlay.currentStrategy == ModelParameters.COOPERATOR) 
				
				// CASE  C VS. C (= 1 )
				payoffWithNeighbor = 1;

			else if (playerToPlay.currentStrategy == ModelParameters.DEFECTOR) 
														
				// CASE  C VS. D (= S )
				payoffWithNeighbor = S;							

		} else if (this.currentStrategy == ModelParameters.DEFECTOR) {
			
			if (playerToPlay.currentStrategy == ModelParameters.COOPERATOR) {
				
				// CASE  D VS. C (= T )			
				payoffWithNeighbor = T;

			} else if (playerToPlay.currentStrategy == ModelParameters.DEFECTOR) {
														
				// CASE  D VS. D (= 0 )			
				payoffWithNeighbor = 0;				
			}					
		}
					
		// add to the global payoff as we are adding values
		this.currentFitness += payoffWithNeighbor;
		
		//System.out.println("\n**Total payoff for A-" + this.gamerAgentId + ": " + this.currentPayoff);		 

		return this.currentFitness;
	}

	
	/**
	 * This function is called to calculate the payoffs of the play of the agent
	 * within its local neighbourhood of the SN. The payoff is calculated following
	 * the payoff matrix of the defined game
	 * 
	 * It is a pairwise game where we accumulate the games' payoffs played by each pair of players
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return the payoff of the agent in this step
	 */
	public double calculatePayoffWithNeighbors(SimState state) {

		Model model = (Model) state;
		
					
		// if we have a SN structure, we get all the neighbors of the agent in the SN
		IntArrayList neighbors = model.socialNetwork.getNeighborsOfNode(this.gamerAgentId);

		// setting the fitness to the agent according to the utility matrix

		//System.out.println("\nFocal-" + this.gamerAgentId + " (str. " + (char)this.getCurrentStrategy() + ")");		 

		this.currentFitness = (float) 0;
		
		float S = (float) model.params.getFloatParameter("S");
		float T = (float) model.params.getFloatParameter("T");
		
		for (int i = 0; i < neighbors.size(); i++) {

			GamerAgent neighbor = (GamerAgent) (model.getAgents()).get(neighbors.get(i));
			
			//System.out.print("\n -Neigh-" + neighbor.gamerAgentId + " (str. " + (char)neighbor.getCurrentStrategy() + ")");		 

			float payoffWithNeighbor = 0;
			
			// depending on the strategy of focal and neighbor, we have different payoff values
		
			if (this.currentStrategy == ModelParameters.COOPERATOR) {
				
				if (neighbor.currentStrategy == ModelParameters.COOPERATOR) 
					
					// CASE  C VS. C (= 1 )
					payoffWithNeighbor = 1;

				else if (neighbor.currentStrategy == ModelParameters.DEFECTOR) 
															
					// CASE  C VS. D (= S )
					payoffWithNeighbor = S;							

			} else if (this.currentStrategy == ModelParameters.DEFECTOR) {
				
				if (neighbor.currentStrategy == ModelParameters.COOPERATOR) {
					
					// CASE  D VS. C (= T )			
					payoffWithNeighbor = T;

				} else if (neighbor.currentStrategy == ModelParameters.DEFECTOR) {
															
					// CASE  D VS. D (= 0 )			
					payoffWithNeighbor = 0;				
				}					
			}
						
			//System.out.println("fitness with game with neigh = " + payoffWithNeighbor);		 

			// add to the total fitness of the focal agent, as we are adding values
			this.currentFitness += payoffWithNeighbor;
		}						
		
		//System.out.println("\n**Total fitness for A-" + this.gamerAgentId + ": " + this.currentFitness);		 

		return this.currentFitness;
	}

	/**
	 * This function is called to calculate the payoffs of the play of the agent
	 * within its local neighbourhood of the SN using the continuous values of the opinions of the local agent
	 * and neighbors.
	 * The payoff is calculated following the payoff matrix of the defined game and estimating the expected value given 
	 * the probabilities given by the continuous variables
	 * 
	 * This game is a generalized pairwise game where we accumulate the games' payoffs played by each pair of players
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return the payoff of the agent in this step
	 */
	public double calculatePayoffWithNeighborsUsingOpinions (SimState state) {

		Model model = (Model) state;
							
		// if we have a SN structure, we get all the neighbors of the agent in the SN
		IntArrayList neighbors = model.socialNetwork.getNeighborsOfNode(this.gamerAgentId);

		// setting the fitness to the agent according to the utility matrix

		//System.out.println("\nFocal-" + this.gamerAgentId + " (str. " + (char)this.getCurrentStrategy() + ")");		 

		this.currentFitness = (float) 0;
		
		float S = (float) model.params.getFloatParameter("S");
		float T = (float) model.params.getFloatParameter("T");
		
		for (int i = 0; i < neighbors.size(); i++) {

			GamerAgent neighbor = (GamerAgent) (model.getAgents()).get(neighbors.get(i));
			
			//System.out.print("\n -Neigh-" + neighbor.gamerAgentId + " (str. " + (char)neighbor.getCurrentStrategy() + ")");		 

			// we estimate the expected strategies of both taking into account their probabilities
			//     ((O_x*O_y)R + (O_x*(1-O_y))S + ((1-O_x)*O_y)T + ((1-O_x)*(1-O_y))P)
			float payoffWithNeighbor = (this.opinion * neighbor.getOpinion()) 
					+ (this.opinion * (1 - neighbor.getOpinion()))*S 
					+ ((1 - this.opinion) * neighbor.getOpinion())*T;
						
			//System.out.println("fitness with game with neigh = " + payoffWithNeighbor);		 

			// add to the total fitness of the focal agent, as we are adding values
			this.currentFitness += payoffWithNeighbor;
		}						
		
		//System.out.println("\n**Total fitness for A-" + this.gamerAgentId + ": " + this.currentFitness);		 

		return this.currentFitness;
	}


	/**
	 * With this function we update the strategy used by the agent.
	 * We use the defined imitative ev. dynamics rule for calculating the change (if there is a change)
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return true if the agent has changed its strategy w.r.t. its previous strategy
	 */
	public boolean updateRuleForStrategyFollowers (SimState state) {
		
		Model model = (Model) state;
		
		switch ((int) model.params.getIntParameter("updateRule")) {

		case ModelParameters.FERMI_UPDATE_RULE:
			
			return this.fermiRuleForFollowers(state);
			
		case ModelParameters.DEGROOT_OD:
			
			return this.HK(state, true);
			
		case ModelParameters.DW_OD:
			
			return this.DW(state);
	
		case ModelParameters.HK_OD:
			
			return this.HK(state, false);
		}
		
		return false;
		
	}	
	
	//--------------------------- Steppable method --------------------------//	
	
	/**
	 * Step of the simulation.
	 * @param state - a simulation model object (SimState).
	 */
	
	//@Override	
	public void step(SimState state) {

		Model model = (Model) state;
		
		currentStep = (int) model.schedule.getSteps();
        
		if (currentStep > 0) {
		
			// check if the player is an influencer or not for running the typical social and mutation processes	
			if ( !this.influencer ) {
				
				// mutate the strategy 			
				//if (! this.mutateStrategy (state)) {

					// if no mutated, update rule

					this.updateRuleForStrategyFollowers(state);		
				//}						
			} else {
				
				// we have an influencer so it will just imitate other influencers
				// mutate the strategy 			
				//if (! this.mutateStrategy (state)) {

					// if no mutated, update rule
					this.fermiRuleForInfluencers (state);		
				//}			
			}
			
			// store the opinion of this step to store it for plotting
			this.opinions.set(currentStep - 1, this.opinion);
			
		}
	}

}


