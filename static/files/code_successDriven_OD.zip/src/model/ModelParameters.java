package model;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.NoSuchElementException;

import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.graphstream.graph.Graph;

import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.stream.file.FileSourceDGS;


/**
 * 
 * INFLUENCING OPINIONS BY INFLUENCERS IN A GENERALIZED TWO-PLAYERS GAME

	Handling missing properties			https://commons.apache.org/proper/commons-configuration/userguide/howto_basicfeatures.html
				
 * @author mchica
 * @date 2022/06/16
 * @place Oeiras, Lisboa
 *
 */

public class ModelParameters {

	// Read configuration file (apache commons configuration 2.7)
	Configuration config;
	
	// outputing extra information at the end of the simulation
	public static boolean OUTPUT_AGENTS_OPINIONS = false; 
		
	// constants to get different options for simple or SA runs
	public final static int NO_SA = 0;

	public final static int SA_S = 2;
	public final static int SA_mutProb = 3;
	public final static int SA_S_T = 4;
	public final static int SA_BETA_EPSILON = 5;
		
	// FOR THE STRATEGY TYPE FOR AGENTS
	public final static byte NUM_STRATEGIES = 2;
	public final static byte UNDEFINED_STRATEGY = 'U';
	public final static byte COOPERATOR = 'C';
	public final static byte DEFECTOR = 'D';

	public final static int WELL_MIXED_POP = -1;
	public final static int NETWORK = 0;
	
	// TYPE OF UPDATE RULE FOR THE AGENTS
	public final static byte DEGROOT_OD = 1;
	public final static byte DW_OD = 2;
	public final static byte HK_OD = 3;
	public final static byte FERMI_UPDATE_RULE = 4;
		

	// ########################################################################
	// Variables
	// ########################################################################

	String outputFile;

	// modified just to use a static SN from a file

	// FILE_NETWORK ONLY!!
	boolean network;				// true if having a structured network such as SF or Lattice (read from file). false if we do not have it and it is a WM

	// graph read from file
	Graph graphFromFile;



	// --------------------------- Wrapper methods for Config ---------------------------//
	//

	/**
	 * This function add a new parameter to the map of parameters of the model
	 * 
	 * @param _parameterKey is the key of the new parameter to create
	 * @param _value is the value to set to the parameter
	 */
	public void addParameter (String _parameterKey, Object _value) {		
		this.config.addProperty(_parameterKey, _value);		
	}
	
	/**
	 * This function set an existing parameter to the map of parameters of the model
	 * 
	 * @param _parameterKey is the key of the existing parameter to set
	 * @param _value is the value to set to the parameter
	 */
	public void setParameterValue (String _parameterKey, Object _value) {		
		this.config.setProperty(_parameterKey, _value);		
	}
		
	/**
	 * This function retrieve a parameter of type int from the configuration structure of parameters
	 */
	public int getIntParameter (String _parameterKey) {		
		
		return this.config.getInt(_parameterKey);		
		
	}

	/**
	 * This function retrieve a parameter of type float from the configuration structure of parameters
	 */
	public float getFloatParameter (String _parameterKey) {		
		
		return this.config.getFloat (_parameterKey);		
		
	}
	
	/**
	 * This function retrieve a parameter of type long from the configuration structure of parameters
	 */
	public long getLongParameter (String _parameterKey) {		
		
		return this.config.getLong (_parameterKey);		
		
	}

	/**
	 * This function retrieve a parameter of type String from the configuration structure of parameters
	 */
	public String getStringParameter (String _parameterKey) {		
		
		return this.config.getString (_parameterKey);		
		
	}
	
	// --------------------------- Methods for SN configuration ---------------------------//
	//
			
		
	/**
	* @return the value of having a network or not
	*/
	public boolean getNetworkOption () {
		return this.network;
	}
	
	/**
	* @param _v if having a network from file
	*/
	public void setNetworkOption (boolean _v) {
		this.network = _v;
	}
	

	/**
	 * @return the graph
	 */
	public Graph getGraph () {
		return graphFromFile;
	}

	/**
	 * @param _graph
	 *            to set
	 */
	public void setGraph (Graph _graph) {
		this.graphFromFile = _graph;
	}


	/**
	 * @param _graph
	 *            to set
	 * @throws IOException
	 */
	public void readGraphFromFile(String fileNameGraph) throws IOException {

		FileSourceDGS fileSource = new FileSourceDGS();
		graphFromFile = new SingleGraph("SNFromFile");

		fileSource.addSink(graphFromFile);
		fileSource.readAll(fileNameGraph);

		fileSource.removeSink(graphFromFile);		
	
	}
	

	// ########################################################################
	// Constructors
	// ########################################################################

	/**
	 * 
	 */
	public ModelParameters() {

	}

	// ########################################################################
	// Export methods
	// ########################################################################

	public String export() {

		String values = "";

		values += exportGeneral() + "------\n";
		values += exportSpecifics();

		return values;
	}

	private String exportSpecifics() {

		String result = "";

		result += "percentageCs = " + config.getFloat("percentageCs") + " (k_C = " + config.getInt("k_C") + ", k_D = " + config.getInt("k_D") + ")\n";
		result += "percentageInfluencers = " + config.getFloat("percentageInfluencers") + " (" + config.getInt("noInfluencers") + " agents)\n";

		result += "probInfluencers = " + config.getFloat("probInfluencers") + "\n";	
		result += "probFollowers = " + config.getFloat("probFollowers") + "\n";		
	
		result += "S = " + config.getFloat("S") + "\n";
		result += "T = " + config.getFloat("T") + "\n";


		return result;

	}
	
	/**
	 * Prints simple statistics evolution during the time.
	 */
	public void printParameters(PrintWriter writer) {

		// printing general params
		writer.println(this.export());

	}

	private String exportGeneral() {

		String result = "";

		result += "MC_runs = " + config.getInt("MCRuns") + "\n";
		result += "seed = " + config.getLong("seed") + "\n";
		result += "nrAgents = " + config.getInt("nrAgents") + "\n";
		result += "maxSteps = " + config.getInt("maxSteps") + "\n";

		result += "Network? = " + this.network + "\n";
		result += "SNFile = " + config.getString("SNFile") + "\n";		
		
		if (config.getInt("updateRule") == ModelParameters.DEGROOT_OD)
			result += "updateRule = DEGROOT_OD \n";
		
		else if (config.getInt("updateRule") == ModelParameters.DW_OD) {
			result += "updateRule = DW_OD\n";
			result += "muDW = " + config.getFloat("muDW") + "\n";
			result += "epsilonBC = " + config.getFloat("epsilonBC") + "\n";
		}
		
		else if (config.getInt("updateRule") == ModelParameters.HK_OD) {
			result += "updateRule = HK_OD\n";
			result += "epsilonBC = " + config.getFloat("epsilonBC") + "\n";
		}
					
		else if (config.getInt("updateRule") == ModelParameters.FERMI_UPDATE_RULE)
			result += "updateRule = FERMI_UPDATE_RULE\n";
		
		result += "betaRule = " + config.getFloat("betaRule") + "\n";
		
		result += "mutProb = " + config.getFloat("mutProb") + "\n";
			
		return result;
	}

	/** 
	 * Generate the absolute number of initial influencers and Cs
	 */
	public void updateInitialAdoptersFromPercentages() {

		int k_C = (int) Math.round(config.getInt("nrAgents") * config.getFloat("percentageCs"));
		
		config.addProperty("k_C", k_C);
		config.addProperty("k_D", config.getInt("nrAgents") - k_C);
		config.addProperty("percentageDs", 1 - config.getFloat("percentageCs"));
		
		// init value before running a SA
		config.addProperty("percentageFollowers", 1 - config.getFloat("percentageInfluencers"));
		config.addProperty("noInfluencers", Math.round(config.getFloat("percentageInfluencers")*config.getInt("nrAgents")));
		
	}
		
	
	/**
	 * Reads parameters from the configuration file.
	 */
	public void readParameters(String CONFIGFILENAME) {

		Configurations configs = new Configurations();

		try {

			// Read parameters from the file
			this.config = configs.properties(new File(CONFIGFILENAME));									
			
			if (config.getInt("updateRule") != ModelParameters.FERMI_UPDATE_RULE && config.getInt("updateRule") != ModelParameters.DW_OD
					&& config.getInt("updateRule") != ModelParameters.HK_OD && config.getInt("updateRule") != ModelParameters.DEGROOT_OD) {
				
				throw new UnsupportedOperationException ("Only Fermin, HK, DEGroot and DW are implemented\n");
			}
						
			// set type of network			
			if (config.getInt("typeOfNetwork") == NETWORK) 	
				this.network = true;
			else if (config.getInt("typeOfNetwork") == WELL_MIXED_POP) 
					this.network = false;			
								
			
			// if having a SN from file to read, do it
			if (this.network == true) 
				this.readGraphFromFile(config.getString("SNFile"));
															
												
		} catch (IOException e) {

			System.err.println("ModelParameters: Error when handling or opening the properties file " + CONFIGFILENAME + "\n"
					+ e.getMessage());
			e.printStackTrace(new PrintWriter(System.err));
			
		} catch (ConfigurationException ce) {

			System.err.println("ModelParameters: Error when managing the configuration module (Apache) with file " + CONFIGFILENAME + "\n"
					+ ce.getMessage());
			ce.printStackTrace(new PrintWriter(System.err));
			
		} catch (NoSuchElementException noSuch) {

			System.err.println("Warning ModelParameters: Property not defined in " + CONFIGFILENAME + "\n"
					+ noSuch.getMessage());
		}
	}
	
}
