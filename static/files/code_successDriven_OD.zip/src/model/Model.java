package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import sim.engine.*;
import sim.util.*;

import socialnetwork.*;
import util.BriefFormatter;
import util.ClusteringByHistogram;
import util.Functions;
import util.LocationWrapper;

import org.apache.commons.math3.ml.clustering.Cluster;
import org.apache.commons.math3.ml.clustering.DBSCANClusterer;
import org.apache.commons.math3.stat.Frequency;
// https://github.com/eclipse/eclipse-collections/blob/master/docs/guide.md#eclipse-collections-reference-guide
import org.eclipse.collections.impl.list.mutable.primitive.IntArrayList;
import org.eclipse.collections.impl.list.mutable.FastList;
import org.eclipse.collections.impl.list.mutable.primitive.FloatArrayList;

//import org.eclipse.collections.impl.set.mutable.primitive.IntHashSet;
//import org.graphstream.algorithm.Toolkit;
//import org.graphstream.graph.Node;

// random generator from DSI of Milano
import it.unimi.dsi.util.*;



/**
 * 
 * Influencing opinion dynamics for EGT
 * 
 * Simulation core, responsible for scheduling agents of the evolutionary game
 * 
 * @author mchica
 * @location Oeiras
 * @date 2022/06/16
 * 
 */
public class Model extends SimState {

	// ########################################################################
	// Variables
	// ########################################################################
			
	private static final long serialVersionUID = -8094551352549697295L;

	static String CONFIGFILENAME;
				
	// LOGGING
	public static final Logger log = Logger.getLogger( Model.class.getName() );
			
	// MODEL VARIABLES
	
	it.unimi.dsi.util.XoRoShiRo128PlusRandom random;
	
	ModelParameters params;
	
	Bag agents;	
	
	float followersC_Agents[]; // a counter of the touristsC agents during the simulation
	float followersD_Agents[]; // a counter of the touristsD agents during the simulation
	float followers_rateCoopActs[]; // fraction of cooperation acts for all the follower players

	float influencersC_Agents[]; // a counter of the stakeholdersC agents during the simulation
	float influencersD_Agents[]; // a counter of the stakeholdersD agents during the simulation
	float influencers_rateCoopActs[]; // fraction of cooperation acts for all the follower players

	float finalNumClusters[];		// we save the number of clusters from the agents' opinions at the end of the sim
	
	
	// SOCIAL NETWORK
	GraphStreamer socialNetwork;
	float avgDegree;

	IntArrayList influencersNodes;   // in this arrayList we will store the nodes of the influencers
	IntArrayList followersNodes;   	// in this arrayList we will store the nodes of the followers for quicker access
	
	
	int MC_RUN = -1 ;
	
	//--------------------------- Clone method ---------------------------//	
	
		
	//--------------------------- Get/Set methods ---------------------------//	
	//
	
	/**
	 * returns the final number of clusters
	 * 
	 */
	public float[] getFinalNumClusters () {
		return this.finalNumClusters;
	}
	
	/**
	 * 
	 */
	public void setFinalNumClusters (float _numClusters []) {
		this.finalNumClusters = _numClusters;
	}
	
	
	/**
	 * Return the array of influencers (ids of the agents)
	 * @return
	 */
	public IntArrayList getInfluencersNodes () {
		return influencersNodes;
	}
	

	public float getAvgDegree () {		
		return this.avgDegree;		
	}
	
	/**
	 * Return the array of followers (ids of the agents)
	 * @return
	 */
	public IntArrayList getFollowersNodes () {
		return followersNodes;
	}
	
	
	/**
	 * Return true if the agent is an influencer
	 * @return
	 */
	public boolean checkIfInfluencer (int idAgent) {		
		return this.influencersNodes.contains(idAgent);		
	}
	
	/** 
	 * 
	 * @return the agentId of an influencer node at random
	 */
	public int getInfluencerAtRandom () {		
		int randomPos = random.nextInt(influencersNodes.size());
		
		return influencersNodes.get(randomPos);
	}
	
	/** 
	 * 
	 * @return the agentId of a follower node at random
	 */
	public int getFollowerAtRandom () {		
		int randomPos = random.nextInt(followersNodes.size());
		
		return followersNodes.get(randomPos);
	}
	
	/** 
	 * set the array of id of the influencer agents
	 * @param _array
	 */
	public void setInfluencersNodes ( IntArrayList _array) {		
		influencersNodes = _array;		
	}
	
	/** 
	 * set the array of id of the follower agents
	 * @param _array
	 */
	public void setFollowersNodes ( IntArrayList _array) {		
		followersNodes = _array;		
	}
	
	
	public static String getConfigFileName() {
		return CONFIGFILENAME;
	}
	
	public static void setConfigFileName(String _configFileName) {
		CONFIGFILENAME = _configFileName;
	}

	public GraphStreamer getSocialNetwork() {	
		return socialNetwork;	
	}	
		
	/**
	 * 
	 * @return the bag of agents.
	 */
	public Bag getAgents() {
		return agents;
	}

	/**
	 *  
	 * @param _agents is the bag (array) of agents
	 */
	public void setAgents(Bag _agents) {
		this.agents = _agents;
	}		
			

	/**
	 * Get the number of C agents at a given step - time
	 * 
	 * @return the number of C agents
	 */
	public float getFollowersC_AgentsAtStep(int _position) {
		return followersC_Agents[_position];
	}

	/**
	 * Get the number of D agents for all the period of time
	 * 
	 * @return an ArrayList with the evolution of the D agents
	 */
	public float[] getFollowersD_AgentsArray() {
		return followersD_Agents;
	}


	/**
	 * Get the number of C agents for all the period of time
	 * 
	 * @return an ArrayList with the evolution of C agents
	 */
	public float[] getFollowersC_AgentsArray() {
		return followersC_Agents;
	}

	/**
	 * Get the number of D agents at a given step - time
	 * 
	 * @return the number of D agents
	 */
	public float getFollowersD_AgentsAtStep(int _position) {
		return followersD_Agents[_position];
	}

	/**
	 * Get the number of C agents at a given step - time
	 * 
	 * @return the number of C agents
	 */
	public float getInfluencersC_AgentsAtStep(int _position) {
		return influencersC_Agents[_position];
	}

	/**
	 * Get the number of D agents for all the period of time
	 * 
	 * @return an ArrayList with the evolution of the D agents
	 */
	public float[] getInfluencersD_AgentsArray() {
		return influencersD_Agents;
	}


	/**
	 * 
	 * @return
	 */
	public float[] getInfluencersRateCoop_AgentsArray() {
		return this.influencers_rateCoopActs;
	}
	
	/** 
	 * 
	 * @return
	 */
	public float[] getFollowersRateCoop_AgentsArray() {
		return this.followers_rateCoopActs;
	}

	/**
	 * Get the number of C agents for all the period of time
	 * 
	 * @return an ArrayList with the evolution of C agents
	 */
	public float[] getInfluencersC_AgentsArray() {
		return influencersC_Agents;
	}

	/**
	 * Get the number of D agents at a given step - time
	 * 
	 * @return the number of D agents
	 */
	public float getInfluencersD_AgentsAtStep(int _step) {
		return influencersD_Agents[_step];
	}
	
	/**
	 * Get ratio of cooperation for influencers at a given step - time
	 * 
	 * @param _step the time step for returning the ratio
	 * @return ratio of C influencers at given step
	 */
	public float getCooperationRateForInfluencersAtStep(int _step) {
		return influencersC_Agents[_step]/this.params.getIntParameter("nrAgents");
	}
	
	/**
	 * Get ratio of cooperation for influencers at current step
	 * 
	 * @return ratio of C influencers 
	 */
	public float getCooperationRateForInfluencersAtCurrentStep() {
		return getCooperationRateForInfluencersAtStep((int) schedule.getSteps());
	}
	
	/**
	 * Get ratio of cooperation for followers at a given step - time
	 * 
	 * @param _step the time step for returning the ratio
	 * @return ratio of C followers at given step
	 */
	public float getCooperationRateForFollowersAtStep(int _step) {
		return followersC_Agents[_step]/this.params.getIntParameter("nrAgents");
	}
	
	/**
	 * Get ratio of cooperation for followers at current step
	 * 
	 * @return ratio of C followers
	 */
	public float getCooperationRateForFollowersAtCurrentStep() {
		return getCooperationRateForFollowersAtStep((int) schedule.getSteps());
	}
	
	/**
	 * Get the parameter object with all the input parameters
	 */
	public ModelParameters getParametersObject () {
		return  this.params;
	}

	/**
	 * Set the parameters
	 * @param _params the object to be assigned
	 */
	public void setParametersObject (ModelParameters _params) {
		this.params = _params;
	}

	
	// ########################################################################
	// Constructors
	// ########################################################################

	/**
	 * Initializes a new instance of the simulation model
	 * @param _params an object with all the parameters of the model
	 */
	public Model(ModelParameters _params) {
	    
		super( (long)_params.getLongParameter("seed") );	
		
		// use our specific class for random generator
		this.random = new XoRoShiRo128PlusRandom();
		this.random.setSeed((long)_params.getLongParameter("seed"));
		 
		
		try {  

	        // This block configure the logger with handler and formatter  
			long millis = System.currentTimeMillis();
			FileHandler fh = new FileHandler("./logs/" + _params.getStringParameter("outputFile") + "_" + millis + ".log");  
	        log.addHandler(fh);
	        BriefFormatter formatter = new BriefFormatter();  
	        fh.setFormatter(formatter);  
	        
	        log.setLevel(Level.FINE);

	        log.log(Level.FINE, "Log file created at " + millis +" (System Time Millis)\n");  

	    } catch (SecurityException e) {  
	        e.printStackTrace(); 	        
	    } catch (IOException e) {  
	        e.printStackTrace();  
	    }  

		// get parameters
		params = _params;	
		
		int _maxSteps =(int) params.getIntParameter("maxSteps");
		int _nrAgents =(int) params.getIntParameter("nrAgents");
	
		// store an IDs array with the agents to be k_C, k_D at the beginning of the simulation
		// This is done according to the parameters of their k_C, k_D distribution
				
		// Initialization of the type of strategy counts
		followersC_Agents = new float[_maxSteps];
		followersD_Agents = new float[_maxSteps];
		influencersC_Agents = new float[_maxSteps];
		influencersD_Agents = new float[_maxSteps];
		
		influencers_rateCoopActs = new float[_maxSteps];
		followers_rateCoopActs = new float[_maxSteps];
		
        finalNumClusters = new float[_maxSteps];

		// list of nodes being influencers and followers
		this.influencersNodes = new IntArrayList();
		this.followersNodes = new IntArrayList();

				
		// social network initialization from file				
		if (params.getNetworkOption()) {
			
			socialNetwork = new GraphStreamer(_nrAgents, params);
			socialNetwork.setGraph(params);		
			this.avgDegree = (float) socialNetwork.getAvgDegree();

		} else {
			
			socialNetwork = null;
		}			
	}
	
	/** 
	 * Dirty temporal method to use different SF networks from file not to use the same network always.
	 * We use 10 SFs for every 10th of the MC runs
	 * 
	 */
		
	private void loadDiffSFs () {
				
		String path = "./networks/SF-5knodes_m_3.dgs";

		int bin = this.params.getIntParameter("MCRuns") / 10;
		
		if (this.MC_RUN > bin) {
			
			if (this.MC_RUN < bin * 2) {
				
				path = "./networks/SF-5knodes_m_3_0.dgs";				
				
			} else if (this.MC_RUN < bin * 3) {
				
				path = "./networks/SF-5knodes_m_3_1.dgs";
			
			} else if (this.MC_RUN < bin * 4) {
							
				path = "./networks/SF-5knodes_m_3_2.dgs";
				
			} else if (this.MC_RUN < bin * 5) {
				
				path = "./networks/SF-5knodes_m_3_3.dgs";
				
			} else if (this.MC_RUN < bin * 6) {
				
				path = "./networks/SF-5knodes_m_3_4.dgs";
			
			} else if (this.MC_RUN < bin * 7) {
										
				path = "./networks/SF-5knodes_m_3_5.dgs";
				
			} else 	if (this.MC_RUN < bin * 8) {
				
				path = "./networks/SF-5knodes_m_3_6.dgs";
			
			} else 	if (this.MC_RUN < bin * 9) {
				
				path = "./networks/SF-5knodes_m_3_7.dgs";	
				
			} else {

				path = "./networks/SF-5knodes_m_3_8.dgs";
				
			}
		}
		
		if (path.compareTo(this.params.getStringParameter("SNFile")) != 0 ) {
			
			// the network has changed, load a new one
			try {
				this.params.setParameterValue("SNFile", path);				
				this.params.readGraphFromFile(path);
				
				socialNetwork.setGraph(params);		
				
				
			} catch (IOException e) {

				System.err.println("ModelParameters: Error when handling or opening the properties file " + CONFIGFILENAME + "\n"
						+ e.getMessage());
				e.printStackTrace(new PrintWriter(System.err));
				
			}			
		}		
	}
	
	
	//--------------------------- SimState methods --------------------------//

	/**
	 * Sets up the simulation. The first method called when the simulation.
	 */
	public void start() {

		super.start();
		
		this.MC_RUN ++;
		
		// HARDCODE TO USE DIFFERENT NETWORKS
		//if (this.params.getIntParameter("typeOfNetwork") == ModelParameters.NETWORK ) 
			
			//this.loadDiffSFs();
			
		
		if (((int) params.getIntParameter("k_C") + (int) params.getIntParameter("k_D") ) != 
				(int)params.getIntParameter("nrAgents")) {			
			System.err.println(	"Error with the k_C, k_D distribution. "
					+ "Check k_C + k_D is equal to the total number of agents \n");
		}

        final int FIRST_SCHEDULE = 0;
        int scheduleCounter = FIRST_SCHEDULE;
        
        
		// at random, create an array with the IDs unsorted. 
		// In this way we can randomly distribute the agents are going to be k_C, k_D
		// this is done here to change every MC simulation without changing the SN
		// IMPORTANT! IDs of the SN nodes and agents must be the same to avoid BUGS!!
		       			
						                        
        // Initialization of the agents
        agents = new Bag();
        		
		// select the nodes by degree when having seeding Ps
        for (int i = 0; i < (int) params.getIntParameter("nrAgents"); i++) {
        	           	
            byte strategy = ModelParameters.UNDEFINED_STRATEGY;
            float opinion = -1;
            
            if (i < (int) params.getIntParameter("k_C")) {
                // we need to add it as k_C strategy
                strategy = ModelParameters.COOPERATOR;
                 
            } else if (i < ((int) params.getIntParameter("k_C") + (int) params.getIntParameter("k_D"))) {
                // it is a k_D strategy
                strategy = ModelParameters.DEFECTOR;    
            } 
            
            // set an opinion at random
            opinion = this.random.nextFloat();
            
            // generate the agent, push in the bag, and schedule
            GamerAgent cl = generateAgent (i, strategy, opinion);  
                                    
            // Add agent to the list and schedule
            agents.add(cl);
            
            // Add agent to the schedule
            schedule.scheduleRepeating(Schedule.EPOCH, scheduleCounter, cl);             
        }       
         
        // shuffle agents in the Bag and later, reassign the id to the position in the bag        
        agents.shuffle(this.random);
                
        // we clear the arrays of followers and influencers in case there was another MC run previously
        this.influencersNodes.clear();
        this.followersNodes.clear();
        
        for (int i = 0; i < this.params.getIntParameter("noInfluencers"); i++) {
        	
        	int posRandom;
        	
        	do {
        		posRandom = this.random.nextInt(agents.size());
        	} while(this.influencersNodes.contains(posRandom));
        	        	
    		this.influencersNodes.add(posRandom);
        }
                
        // assign shuffled IDs to agents and set their parameters
        for (int agentId = 0; agentId < agents.size(); agentId++) {

        	((GamerAgent) agents.get(agentId)).setGamerAgentId(agentId);
        
        	// set the degree of the agent
        	((GamerAgent) agents.get(agentId)).setDegree(socialNetwork.getNeighborsOfNode(agentId).size());
        	
        	// check if this agent is an influencer or not        	
        	// depending on its influencer role, set its probability

        	if (this.influencersNodes.contains(agentId)) {
        		
        		((GamerAgent) agents.get(agentId)).setInfluencer(true);             		
             	
        	} else {
        		
        		((GamerAgent) agents.get(agentId)).setInfluencer(false);

            	// include the node in the hash for tracking followers
        		this.followersNodes.add(agentId);
        	}        	
        }	          
                	
        // Add anonymous agent to calculate statistics
        setAnonymousAgentApriori(scheduleCounter);
        scheduleCounter++;    
                           
        setAnonymousAgentAposteriori(scheduleCounter);               
			
	}


	//-------------------------- Auxiliary methods --------------------------//	
	
	/**
	 * Generates the agent with its initial strategy, id, probability to act and 
	 * its computed activity array (from the latter probability).
	 * This is important as we can save time not to ask at each step if the agent is active or not
	 * 
	 * @param _nodeId is the id of the agent
	 * @param _strategy is the type of strategy the agent is going to follow
	 * @return the agent created by the method
	 */
	private GamerAgent generateAgent(int _nodeId, byte _strategy, float _opinion) {
		
		GamerAgent  cl = new GamerAgent (_nodeId, _strategy, _opinion, (int) params.getIntParameter("maxSteps"));

		/*System.out.println("--> IDAgent " + _nodeId + " with " 
		+ this.socialNetwork.getNeighborsOfNode(_nodeId).size() + " neighbors.");*/
									
		return cl;
	}	
	
	/**
	 * Adds the anonymous agent to schedule (at the beginning of each step), 
	 * which calculates the statistics.
	 * @param scheduleCounter
	 */
	private void setAnonymousAgentApriori(int scheduleCounter) {
				
		// Add to the schedule at the end of each step
		schedule.scheduleRepeating(Schedule.EPOCH, scheduleCounter, new Steppable()
		{ 
			/**
			 * 
			 */
			private static final long serialVersionUID = -2837885990121299044L;

			public void step(SimState state) {
	    			    							
			}			
		});				
	}
		

	/**
	 * Counts the number of players with C, D, and P strategies to update the data structures 
	 * If there is a network, we only count the strategy of the focal agent to use this structure to track
	 * how many Cs, Ds, we have in the population
	 * 
	 */
	private void updateNumberStrategiesCounting (int currentStep) {
				
		followersC_Agents[currentStep] = followersD_Agents[currentStep] = 
				influencersC_Agents[currentStep] = influencersD_Agents[currentStep] = 0;
		
		influencers_rateCoopActs[currentStep] = followers_rateCoopActs[currentStep] = (float) 0.;
		
		finalNumClusters[currentStep] = -1;
		
		float rateCoopsFollowers = (float)0.;
		float rateCoopsInfluencers = (float)0.;
		
		for (int i = 0; i < (int)params.getIntParameter("nrAgents"); i++) {
			
			float o_i = ((GamerAgent) agents.get(i)).getOpinion();
			
			// estimate fraction of cooperation acts and count Cs/Ds by 0.5
			
			if (!((GamerAgent) agents.get(i)).isInfluencer()) {
				
				if (o_i >= 0.5)  
					followersC_Agents[currentStep] ++;
				else
					followersD_Agents[currentStep] ++;	

				// cooperation acts estimation
				rateCoopsFollowers += o_i * ((GamerAgent) agents.get(i)).getDegree();
				
				//System.out.println(i + " agent: o_i = " + o_i + ", and degree is " + ((GamerAgent) agents.get(i)).getDegree() + ", rate = " + rateCoopsFollowers);
				
			} else if (((GamerAgent) agents.get(i)).isInfluencer()) {
				
				if (o_i >= 0.5 )  
					influencersC_Agents[currentStep] ++;
				else
					influencersD_Agents[currentStep] ++;	
				
				// cooperation acts estimation
				rateCoopsInfluencers += o_i * ((GamerAgent) agents.get(i)).getDegree();
			}			
		
		}	

		this.followers_rateCoopActs[currentStep] = rateCoopsFollowers / ( this.avgDegree * this.agents.size());
		this.influencers_rateCoopActs[currentStep] = rateCoopsInfluencers / ( this.avgDegree * this.agents.size());
		
		//System.out.println("Step " + currentStep + ", rate is " +  this.followers_rateCoopActs[currentStep]  + " having avg degree of " +  this.avgDegree);

	}
	
	
	/**
	 * Adds the anonymous agent to schedule (at the end of each step), 
	 * which calculates the statistics.
	 * @param scheduleCounter
	 */
	private void setAnonymousAgentAposteriori(int scheduleCounter) {
				
		// Add to the schedule at the end of each step
		schedule.scheduleRepeating(Schedule.EPOCH, scheduleCounter, new Steppable()
		{ 
			
			private static final long serialVersionUID = 3078492735754898981L;

			public void step(SimState state) { 
				
				int currentStep = (int) schedule.getSteps();
									
				updateNumberStrategiesCounting (currentStep);									
				
				// array to save agents' opinions to calculate clusters
				FloatArrayList setOfOpinions = new FloatArrayList();
				//FastList<LocationWrapper> clusterInput = new FastList<LocationWrapper>((int) params.getIntParameter("nrAgents"));


				// we calculate the payoffs locally if we have a network or in a WM way
				for (int i = 0; i < (int) params.getIntParameter("nrAgents"); i++) {				
					
					GamerAgent iAgent = ((GamerAgent) agents.get(i));
					
					//if (currentStep == ((int) params.getIntParameter("maxSteps") - 1)) {
						
						// add agent's opinion to the array
						setOfOpinions.add(iAgent.getOpinion());
						
						// add each opinion as a point, with a fixed y value
						//clusterInput.add(new LocationWrapper(iAgent.getOpinion(), 0));
					//}
					
					if (params.getNetworkOption()) 
						
						iAgent.calculatePayoffWithNeighborsUsingOpinions (state);

					else 						
						iAgent.calculatePayoffWM(state);
						
					// update previous fitness and strategies values
					iAgent.setPreviousFitness(iAgent.getCurrentFitness());
					iAgent.setPreviousStrategy(iAgent.getCurrentStrategy());	
					
					// save opinion at the historical array of the agent
					iAgent.addPastOpinion(iAgent.getOpinion());
				}				
				
				// show the result of the last step in the console				
				//if (currentStep == ((int) params.getIntParameter("maxSteps") - 1)) {
				
					finalNumClusters[currentStep] = ClusteringByHistogram.computeClustersFromPeaksInBins(setOfOpinions, (float)0.01, 50);
					
					//System.out.println("step " + currentStep + "----- :");
					
					// initialize a DBSCAN clustering algorithm to calculate clusters in opinions
					// https://commons.apache.org/proper/commons-math/userguide/ml.html#clustering
					/*double epsilon = 0.01;
					int minPointsForCluster = 1;
					DBSCANClusterer<LocationWrapper> clusterer = 
							new DBSCANClusterer<LocationWrapper>(epsilon, minPointsForCluster);
					
					List<Cluster<LocationWrapper>> clusterResults = clusterer.cluster(clusterInput);

					// output the clusters
					for (int i=0; i<clusterResults.size(); i++) {
					    System.out.println("Cluster " + i);
					    for (LocationWrapper locationWrapper : clusterResults.get(i).getPoints())
					        System.out.println(locationWrapper.strPoint());
					    System.out.println();
					} */
					
					/*System.out.println(
							"Final step;" + "numInfluencersC;" + influencersC_Agents[currentStep] 
							+ ";numInfluencersD;" + influencersD_Agents[currentStep] + ";numFollowersC;" +
							followersC_Agents[currentStep] + ";numFollowersD;" + followersD_Agents[currentStep]);*/
				//}
				
				// plotting and saving additional output information for analysis
				plotSaveAdditionalInfo(currentStep);						
			}										
		});		
	}
	
	
	/**
	 * This method wraps all the processes of saving and plotting additional
	 * information to study the dynamics of the simulation (e.g., data about groups, wealth 
	 * distribution of the agents etc)
	 * 
	 * 
	 * @param _currentStep is the step of the simulation
	 * 
	 */

	protected void plotSaveAdditionalInfo(int _currentStep) {
						
		// here, we save information about the status of the groups at the last step
		if ((ModelParameters.OUTPUT_AGENTS_OPINIONS) && (_currentStep == ((int) params.getIntParameter("maxSteps") - 1))) {

			try {

				// save
				File fileStrength = new File("./logs/agents/" + "AgentsOutput_" 
						+ params.getStringParameter("outputFile") + "." + this.MC_RUN + ".txt");
				
				PrintWriter printWriter = new PrintWriter(fileStrength);

				printWriter.write("agentId;degree;opinion;strategy;fitness\n");

				// loop for all the agents
				for (int i = 0; i < (int)params.getIntParameter("nrAgents"); i++) {
					
					if (params.getNetworkOption() == false)

						// print all info of the step without printing the degree as we don't have a network
						printWriter.write(i + ";-1;" + 
						((GamerAgent) agents.get(i)).getOpinion() + ";" + ((GamerAgent) agents.get(i)).getCurrentStrategy() 
						+ ";" + ((GamerAgent) agents.get(i)).getCurrentFitness() + "\n");
					else 
						
						// print all info of the step
						printWriter.write(i + ";" + this.socialNetwork.getNeighborsOfNode(i).size() + ";" +  ((GamerAgent) agents.get(i)).getOpinion()
						+ ";" + ((GamerAgent) agents.get(i)).getCurrentStrategy() + ";" + ((GamerAgent) agents.get(i)).getCurrentFitness() + "\n");
				}

				printWriter.close();

			} catch (FileNotFoundException e) {

				e.printStackTrace();
				log.log(Level.SEVERE, e.toString(), e);
			}
			
			// save into a file the opinions' evolution of the agents
			try {

				// save
				File fileStrength = new File("./logs/agents/" + "AgentsEvolutionOfOpinions_" 
						+ params.getStringParameter("outputFile") + "." + this.MC_RUN + ".txt");
				
				PrintWriter printWriter = new PrintWriter(fileStrength);

				printWriter.write("step;");				
				for (int i = 0; i < (int)params.getIntParameter("nrAgents"); i++) 
					printWriter.write("a" + i + ";");	
				printWriter.write("\n");

				for (int k = 0; k < (int)params.getIntParameter("maxSteps"); k++) {					
				
					printWriter.write(k + ";");	
				
					// loop for all the agents
					for (int i = 0; i < (int)params.getIntParameter("nrAgents"); i++)						
						printWriter.write(((GamerAgent) agents.get(i)).getOpinionAtStep(k) + ";");
					
					printWriter.write("\n");
				}
				
				printWriter.close();

			} catch (FileNotFoundException e) {

				e.printStackTrace();
				log.log(Level.SEVERE, e.toString(), e);
			}
		}	
		
	}

}
