package view;

import java.io.IOException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.eclipse.collections.impl.list.mutable.primitive.DoubleArrayList;

import controller.Controller;
import model.Model;
import model.ModelParameters;
import util.RunStats;
import util.SensitivityAnalysis;

//----------------------------- MAIN FUNCTION -----------------------------//

/**
 * Main function for the Evolutionary Influencers opinions game 
 * 
 * @author mchica
 * @date 2022/06/15
 * @place Oeiras, Lisboa
 */

public class ConsoleSimulation {		
	

	// LOGGING
	private static final Logger log = Logger.getLogger( Model.class.getName() );
	
	/**
	 * Create an options class to store all the arguments of the command-line call of the program
	 * 
	 * @param options the class containing the options, when returned. It has to be created before calling
	 */
	private static void createArguments (Options options) {
				
					
		options.addOption("paramsFile", true, "Pathfile with the parameters file");
		options.getOption("paramsFile").setRequired(true);

		options.addOption("maxSteps", true, "Max number of steps of the simulation");
		options.addOption("MCRuns", true, "Number of MC simulations");
		options.addOption("seed", true, "Seed for running the MC simulations");
		
		options.addOption("SNFile", true, "File with the SN to run");
		
		options.addOption("outputFile", true, "File to store all the information about the simulation");
		options.getOption("outputFile").setRequired(true);
		
		options.addOption("percentageCs", true, "% of agents to be cooperators at the beginning of the simulation");
		options.addOption("percentageInfluencers", true, "% of agents to be influencers at the beginning of the simulation");

		options.addOption("S", true, "S parameter of the game \\in [-1, 1]");
		options.addOption("T", true, "T parameter of the game \\in [0, 2]");
		options.addOption("mutProb", true, "mutation probability \\in [0, 1]");
		options.addOption("betaRule", true, "beta of the update rule \\in [0, 5]");
		options.addOption("probInfluencers", true, "prob to cooperate of an influencer \\in [0, 1]");
		options.addOption("probFollowers", true, "prob to cooperate of a follower \\in [0, 1]");
		

		options.addOption("updateRule", true, "Type of rule to update (DEGROOT_OD = 1, DW_OD = 2, HK_OD = 3, FERMI = 4)");
		options.addOption("epsilonBC", true, "\\epsilon for BC opinion dynamics \\in [0, 1]");
		options.addOption("muDW", true, "\\mu for DW opinion dynamics \\in [0, 0.5]");
		

		// parameters for SA
		options.addOption("SA_S", false, "If running a SA over the S parameter");	
		options.addOption("SA_S_T", false, "If running a SA over the S and T parameters");	
		options.addOption("SA_BETA_EPSILON", false, "If running a SA over the BETA and EPSILON parameters");	
		options.addOption("SA_mutProb", false, "If running a SA over the mutProb parameter");
				
		// to show help
		options.addOption("help", false, "Show help information");	
		
	}
	
	/**
	 * MAIN CONSOLE-BASED FUNCTION TO RUN A SIMPLE RUN OR A SENSITIVITY ANALYSIS OF THE MODEL PARAMETERS
	 
	 * @param args
	 */
	public static void main (String[] args) {
    	
		String paramsFile = "";
		String outputFile = "";

		ModelParameters params = null;
		
		// parsing the arguments
		Options options = new Options();
		
		createArguments (options);		

		// create the parser
	    CommandLineParser parser = new DefaultParser();
	    
	    try {
	    	
	        // parse the command line arguments for the given options
	        CommandLine line = parser.parse( options, args );

			// get parameters
			params = new ModelParameters();	
			
	        // retrieve the arguments
	        		    
		    if( line.hasOption( "paramsFile" ) )		    
		    	paramsFile = line.getOptionValue("paramsFile");
		    else 		    	
		    	System.err.println( "A parameters file is needed");

		    if( line.hasOption( "outputFile" ) ) 			    
		    	outputFile = line.getOptionValue("outputFile");

		    // read parameters from file
			params.readParameters(paramsFile);

			// add the output file to the configuration of the model
			params.addParameter("outputFile", outputFile);
						
			// once parameters from file are loaded, we modify those read by arguments of command line		
			
		    // load the parameters file and later, override them if there are console arguments for these parameters
			
			 // MC
		    if( line.hasOption( "MCRuns" ) ) 			    
		    	params.setParameterValue("MCRuns", Integer.parseInt(line.getOptionValue("MCRuns")));

		    // seed
		    if( line.hasOption( "seed" ) ) 			    
		    	params.setParameterValue("seed", Long.parseLong(line.getOptionValue("seed")));

		    // maxSteps
		    if( line.hasOption( "maxSteps" ) ) 			    
		    	params.setParameterValue("maxSteps", Integer.parseInt(line.getOptionValue("maxSteps")));
		    	    			    
			
		    if( line.hasOption( "percentageCs" ) ) 			    
		    	params.setParameterValue("percentageCs", Float.parseFloat(line.getOptionValue("percentageCs")));
			
		    if( line.hasOption( "percentageInfluencers" ) ) 			    
		    	params.setParameterValue("percentageInfluencers", Float.parseFloat(line.getOptionValue("percentageInfluencers")));

		    if( line.hasOption( "probInfluencers" ) ) 			    
		    	params.setParameterValue("probInfluencers", Float.parseFloat(line.getOptionValue("probInfluencers")));
		    
		    if( line.hasOption( "probFollowers" ) ) 			    
		    	params.setParameterValue("probFollowers", Float.parseFloat(line.getOptionValue("probFollowers")));

		    if( line.hasOption( "mutProb" ) ) 			    
		    	params.setParameterValue("mutProb", Float.parseFloat(line.getOptionValue("mutProb")));

		    if( line.hasOption( "betaRule" ) ) 			    
		    	params.setParameterValue("betaRule", Float.parseFloat(line.getOptionValue("betaRule")));

		    if( line.hasOption( "S" ) ) 			    
		    	params.setParameterValue("S", Float.parseFloat(line.getOptionValue("S")));
		    
		    if( line.hasOption( "T" ) ) 			    
		    	params.setParameterValue("T", Float.parseFloat(line.getOptionValue("T")));

		    if( line.hasOption( "muDW" ) ) 			    
		    	params.setParameterValue("muDW", Float.parseFloat(line.getOptionValue("muDW")));

		    if( line.hasOption( "epsilonBC" ) ) 			    
		    	params.setParameterValue("epsilonBC", Float.parseFloat(line.getOptionValue("epsilonBC")));

		    if( line.hasOption( "updateRule" ) ) 			    
		    	params.setParameterValue("updateRule", Integer.parseInt(line.getOptionValue("updateRule")));
		    	    			   
			
			
		    // save file for the SN
		    if( line.hasOption( "SNFile" ) ) 
		    	// read again the network apart from setting the name of the file (inside next function)
		    	try {

					params.readGraphFromFile(line.getOptionValue("SNFile"));
					
		    	} catch (IOException e) {

					System.err.println("ConsoleSimulation: Error with SN file when loading parameters for the simulation " + line.getOptionValue("SNFile") + "\n"
							+ e.getMessage());
					e.printStackTrace(new PrintWriter(System.err));
				}
		    			  
		  		   
		    		
		    // help information
		    if( line.hasOption("help") ) {
			    	
			    // automatically generate the help statement
			    HelpFormatter formatter = new HelpFormatter();
			    formatter.printHelp( "Influencing opinions for EGT, June 2022. Manuel Chica", options);			   	
			}	
		  		    		    
		   		    				
		   if( line.hasOption( "SA_S" ) ) {
		    	
		    	// we have to run a SA on the risk param
		    	params.setParameterValue("SA_type", ModelParameters.SA_S);
		    	
		    } else if( line.hasOption( "SA_mutProb" ) ) {
		    	
		    	// we have to run a SA on the mut Prob
		    	params.setParameterValue("SA_type", ModelParameters.SA_mutProb);
		    			    	
		    } else if( line.hasOption( "SA_S_T" ) ) {
		    	
		    	// we have to run a SA on the mut Prob
		    	params.setParameterValue("SA_type", ModelParameters.SA_S_T);
		    			    	
		    } else if( line.hasOption( "SA_BETA_EPSILON" ) ) {
		    	
		    	// we have to run a SA on the mut Prob
		    	params.setParameterValue("SA_type", ModelParameters.SA_BETA_EPSILON);
		    			    	
		    } else {
		    	
		    	params.setParameterValue("SA_type", ModelParameters.NO_SA);
		    }
		   
		    // to update initial adopters from percentage
		    params.updateInitialAdoptersFromPercentages();
		    
	    }
	    
	    catch (ParseException exp ) {
	    	
	        // oops, something went wrong
	        System.err.println( "Parsing failed.  Reason: " + exp.getMessage() );
			
	    } catch (IllegalArgumentException e ) {
	    	
	        // oops, something went wrong
	        System.err.println( "IllegalArguments for command line.  Reason: " + e.getMessage() );
			log.log(Level.SEVERE, "IllegalArguments for command line.  Reason: " + e.toString(), e);
			
	    }
	    	
        System.out.println("\n****** STARTING INFLUENCING OPINION DYNAMICS IN EGT ******\n");

        Date date = new Date();
    	System.out.println("Experiment output file: **" + params.getStringParameter("outputFile") + "**" );
        System.out.println("Launched on " + date.toString()+ "\n" + "\nParameters of the model:\n-----------------------");
    	
        File fileAllMC = new File ("./logs/" + "AllMCruns_" + params.getStringParameter("outputFile") + ".txt");
        File fileSummaryMC = new File ("./logs/" + "SummaryMCruns_" +  params.getStringParameter("outputFile") + ".txt");
        File fileAllMCLQ = new File ("./logs/" + "AllMCrunsLQ_" + params.getStringParameter("outputFile") + ".txt");
        File fileSummaryMCLQ = new File ("./logs/" + "SummaryMCrunsLQ_" +  params.getStringParameter("outputFile") + ".txt");
        File fileTimeSeriesMC = new File ("./logs/" + "TimeSeriesMCruns_" +   params.getStringParameter("outputFile") + ".txt");
       
        // the SA check    	    			
        int SA = params.getIntParameter("SA_type");
        
	    if (SA == ModelParameters.NO_SA) {
	    	
	    	// no SA, simple run
	    	
	    	RunStats stats;
	    	
	    	// print parameters for double-checking
		    PrintWriter out = new PrintWriter(System.out, true);
	        params.printParameters(out);
	        
	        log.log(Level.FINE, "\n*** Parameters' values of this model:\n" + params.export());
	        
	        
	        // START PREPARING CONTROLLER FOR RUNNING
			long time1 = System.currentTimeMillis ();
		
			Controller controller;
			
			controller = new Controller (params, paramsFile);
			
	        // END PREPARING CONTROLLER FOR RUNNING
	 		
			
			// BEGIN RUNNING MODEL WITH ALL THE MC SIMULATION
			
	 		stats = controller.runModel();	
	 		
	 		// END RUNNING MODEL WITH ALL THE MC SIMULATION
	 		
	 		stats.setExpName (params.getStringParameter("outputFile"));
	 		
	 		long  time2  = System.currentTimeMillis( );
	 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the simulation");
	 		
	 		stats.calcAllStats();
	         
	 		// print the stats in the screen 		
	 		stats.printSummaryStats(out, false);
			stats.printSummaryStatsByAveragingLastQuartile(out, false);  // also the last quartile info

	 		System.out.println();
	 		
	 		// print the stats into a file
	        System.out.println("\n****** Stats also saved into a file ******\n");
	         
	        PrintWriter printWriter;
	         
	 		try {
	 			
	 			
	 			// print all the runs info into a file
	 			printWriter = new PrintWriter (fileAllMC);
	 			stats.printAllStats (printWriter, false);
	 	        printWriter.close (); 
	 	        
	 	        // print all the runs info (last quartiles of the sims) into a file
	 			printWriter = new PrintWriter (fileAllMCLQ);
	 			stats.printAllStatsByAveragingLastQuartile (printWriter, false);
	 	        printWriter.close ();  
	 	        
	 	        // print the summarized MC runs into a file
	 	        printWriter = new PrintWriter (fileSummaryMC);
	 			stats.printSummaryStats (printWriter, false);
	 	        printWriter.close ();    
	 	        
	 	        // print the summarized MC runs (last quartiles of the sims) into a file
	 	        printWriter = new PrintWriter (fileSummaryMCLQ);
	 			stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);
	 	        printWriter.close ();    

	 	        // print the time series into a file
	 	        printWriter = new PrintWriter (fileTimeSeriesMC);
	 			stats.printTimeSeriesStats (printWriter);
	 	        printWriter.close ();    
	 	        
	 	        
	 	        
	 		} catch (FileNotFoundException e) {
	 			
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 			
	 		    log.log( Level.SEVERE, e.toString(), e );
	 		} 
	    	
	    } else {
	    
	    	if ( SA == ModelParameters.SA_S) {
	    		

	    		SensitivityAnalysis.setParam1Info ("S",(float) 0, (float)2, (float)0.05);

	    		SensitivityAnalysis.runSAOnOneParameter (params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    		
	    	} else if ( SA == ModelParameters.SA_mutProb) {

	    		SensitivityAnalysis.setParam1Info ("mutProb",(float) 0, 1, (float)0.1);

	    		SensitivityAnalysis.runSAOnOneParameter (params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	} else if ( SA == ModelParameters.SA_S_T) {

	    		SensitivityAnalysis.setParam1Info ("S", -1, 1, 0.1);
	    		SensitivityAnalysis.setParam2Info ("T", 0, 2, 0.1);

	    		SensitivityAnalysis.runSAOnTwoParameters(params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	} else if ( SA == ModelParameters.SA_BETA_EPSILON) {

	    		SensitivityAnalysis.setParam1Info ("betaRule", -1, 1, 0.1);
	    		
	    		// specific values for beta
	    		DoubleArrayList valuesBeta = new DoubleArrayList();
	    		valuesBeta.add(0.);
	    		valuesBeta.add(0.001);
	    		valuesBeta.add(0.01);
	    		valuesBeta.add(0.1);
	    		valuesBeta.add(0.5);
	    		valuesBeta.add(1);
	    		valuesBeta.add(2);
	    		valuesBeta.add(3);
	    		valuesBeta.add(4);
	    		valuesBeta.add(5);
	    		
	    		SensitivityAnalysis.resetParam1Values(valuesBeta);
	    		
	    		SensitivityAnalysis.setParam2Info ("epsilonBC", 0, 0.8, 0.05);

	    		SensitivityAnalysis.runSAOnTwoParameters(params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	}	   
	    }
	}
}

