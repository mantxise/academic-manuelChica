package controller;

import java.util.logging.Level;
import java.util.logging.Logger;


import model.*;
import util.RunStats;

/** 
 * Controller of the EGT with influencers and opinion dynamics
 * 
 * This class is the controller to call the model  
 * It calls the model, run it to get all the steps and returns a list
 * of simulated values
 * 
 * @author mchica
 * @date 2022/06/16
 * @place Oeiras
 * 
 */

public class Controller {

	// LOGGING
	private static final Logger log = Logger.getLogger( Model.class.getName() );
	
	protected Model model = null;
	
	
	/**
	 * @return the ModelParameters object where all the parameters are defined
	 */
	public ModelParameters getModelParameters() {
		return model.getParametersObject();
	}


	/**
	 * Set the ModelParameters object for all the defined parameters 
	 */
	public void setModelParameters(ModelParameters _params) {
		model.setParametersObject(_params);
	}

	
	/**
	 * Constructor having config, seed and maxSteps
	 */
	public Controller(ModelParameters _params, String _paramsFile) {
				
		Model.setConfigFileName(_paramsFile);
		
		this.model = new Model(_params);
	}
		
	
	/**
	 * Run the model one time
	 * @return the statistics after running the model
	 * 
	 */
	public RunStats runModel() {
		
		// starting and looping the mode

		int mcRuns = model.getParametersObject().getIntParameter("MCRuns");
		int maxSteps = model.getParametersObject().getIntParameter("maxSteps");
		
		// object to store results into the stats object
		
		RunStats stats = new RunStats(mcRuns, maxSteps);
		
		// create the map of the KPI stats for the 4 different KPIs of this model
		stats.createKPIInMap(0, "FC");
		stats.createKPIInMap(1, "FD");
		stats.createKPIInMap(2, "IC");
		stats.createKPIInMap(3, "ID");

		stats.createKPIInMap(4, "NoClusters");
		
		
		//stats.createKPIInMap(5, "FRateCoop");
		//stats.createKPIInMap(6, "IRateCoop");

		
		
		log.log(Level.FINE, "\n**Starting MC agent-based simulation (EGT with influencers & opinion dynamics)\n");
		log.log (Level.FINE, "\n" + model.getParametersObject().export()  + "\n");	

        System.out.print(mcRuns + " MC runs"  + ": ");
     
        
   		for (int i = 0; i <  mcRuns; i++) {
						
			// for each MC run we start the model and run it
    		        
			model.start();
			
			do {					
				if (!model.schedule.step(model)) break;
				 				
			} while (model.schedule.getSteps() <  maxSteps );			

			model.finish();	
					        
	        // store to the stats object
		    
			stats.setKPIForRun(0, i, model.getFollowersC_AgentsArray());
			stats.setKPIForRun(1, i, model.getFollowersD_AgentsArray());
			stats.setKPIForRun(2, i, model.getInfluencersC_AgentsArray());
			stats.setKPIForRun(3, i, model.getInfluencersD_AgentsArray());

			stats.setKPIForRun(4, i, model.getFinalNumClusters());
			
			
			//stats.setKPIForRun(5, i, model.getInfluencersRateCoop_AgentsArray());
			//stats.setKPIForRun(6, i, model.getFollowersRateCoop_AgentsArray());

   
			log.log(Level.FINE, "MC-" + (i+1) + "/" + 
					mcRuns + " ended\n\n");

	        System.out.print(".");
		}						
        
        System.out.println("");
        		        			    	
        
		return stats;
		
	}
		
}
