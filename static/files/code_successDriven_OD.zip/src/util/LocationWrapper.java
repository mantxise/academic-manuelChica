package util;


import org.apache.commons.math3.ml.clustering.Clusterable;

// wrapper class


public class LocationWrapper implements Clusterable {
	
    private double[] points;

    /**
     * 
     * @param _x
     * @param _y
     */
    public LocationWrapper(float _x, float _y) {
        this.points = new double[] { _x, _y };
    }

    /**
     * 
     * @return
     */
    public String strPoint () {
        return String.valueOf(points[0]) + ", " + String.valueOf(points[1]);
    }
    
    
    /**
     * 
     */
    public double[] getPoint() {
        return points;
    }
}