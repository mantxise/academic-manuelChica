package util;

import org.eclipse.collections.impl.list.mutable.FastList;
import org.eclipse.collections.impl.list.mutable.primitive.FloatArrayList;


/**
 * A way to calculate clusters by the frequencies of real values.
 * It was used in delVicario2017 where they define 100 bins of opinions and later,
 * merge peaks closer than a given threshold
 * 

 * @author mchica
 * @location Oeiras, Lisboa
 * 
 */

public class ClusteringByHistogram {

	/**
	 * Function to calculate the clusters in a pop of agents with different opinions
	 * 
	 * We generate a set of bins and assume the range of opinions o_i \in [0,1]
	 * We merge those peaks(bins) within a threshold given as an argument
	 * 
	 * @param arrayOfFloats the set of values to clusterize
	 * @param initialNumOfBins
	 * @param thresholdToMerge
	 * @return the number of clusters from peaks
	 */
	
	public static int computeClustersFromPeaksInBins(FloatArrayList _arrayOfFloats, float thresholdToMerge,
			int initialNumOfBins) {
		
		
		double binWidth = 1. / initialNumOfBins;
		
		FastList<FloatArrayList> bins = new FastList <FloatArrayList> ();

		for (int i = 0; i < initialNumOfBins; i++)
			bins.add(new FloatArrayList ());
		
		//System.out.println(binWidth + " " + initialNumOfBins);
		for (int i = 0; i < _arrayOfFloats.size(); i++) {
			
			int binPos = (int)Math.floor( _arrayOfFloats.get(i) / binWidth); 
			
			// to check that, if we have maximum possible opinion 1, we don't go to an additional bin (out of bounds)
			if (binPos >= initialNumOfBins)
				binPos = initialNumOfBins - 1;
				
			// add the value at its bin
			(bins.get(binPos)).add(_arrayOfFloats.get(i));
			
			//System.out.println("value " + _arrayOfFloats.get(i) + " will be in bin " + binPos );
		}
		
		FloatArrayList clusters = new FloatArrayList ();
		int posCluster = -1;
		
		// at this point, we have the frequencies for the n number of bins
		for (int i = 0; i < bins.size(); i++) {
			
			//System.out.println("bin " + i + " has " + (bins.get(i)).size() + " elements" );
			
			// see if this bin has at least one element
			if ((bins.get(i)).size() > 0) {
				
				// first we calculate the average of the elements (opinions) of the bin			
				float avgBin = (float)bins.get(i).average();  

				//System.out.println("Its average is " + avgBin);

				// check if it is the first cluster
				if (posCluster == -1) {
					posCluster = 0;
					
					// add the average value of the elements of the bin
					clusters.add(avgBin);
					
					//System.out.println("First cluster with avg " + avgBin);
				} else {
					
					// we already have at least one cluster so we see if it is necessary to open a new one
					// or just add to the existing one
					if (Math.abs(avgBin - clusters.get(posCluster)) <= thresholdToMerge) {
						
						float newAvgCluster = (avgBin + clusters.get(posCluster)) / 2;
						clusters.set(posCluster, newAvgCluster);
						
						//System.out.println("Merged value " + avgBin + " to cluster " + posCluster + ". New avg " + newAvgCluster);

					} else {
						
						// the peaks are more distanced than the threshold so we open a new one
						posCluster ++;
						clusters.add(avgBin);
						
						//System.out.println("New cluster open ("+ posCluster + "), with avg: " + avgBin);

					}
				}
			}
		}
				
		return posCluster + 1;
	}
	
}
