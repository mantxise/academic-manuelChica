package view;

// package for std and mean

import java.io.PrintWriter;

import org.apache.commons.math3.stat.descriptive.*;


/** 
 * StatsRun
 * 
 * This class will store all the results for the MonteCarlo simulation.
 * It will also update the stats and error metrics w.r.t. the historical data.
 * 
 * @author mchica
 *
 */
public class RunStats {

	private int numberRuns;				// number of MC simulations

	private int numberSteps;			// number of steps simulation
	
	// fields for k_I members of the population (time series)
	private int k_I[][];			// all the k_I members (each for run and step)
	private float avgk_I[];			// average k_I over all the runs for each step
	private float stdk_I[];			// std k_I over all the runs for each step
	private float[] min_k_I;
	private float[] max_k_I;
	
	// fields for k_T members of the population (time series)
	private int k_T[][];			// all the k_T members (each for run and step)
	private float avgk_T[];			// average k_T over all the runs for each step
	private float stdk_T[];			// std k_T over all the runs for each step
	private float[] min_k_T;
	private float[] max_k_T;
	
	// fields for k_U members of the population (time series)
	private int k_U[][];			// all the k_U members (each for run and step)
	private float avgk_U[];			// average k_U over all the runs for each step
	private float stdk_U[];			// std k_U over all the runs for each step
	private float[] min_k_U;
	private float[] max_k_U;
	
	// fields for netWealth
	private float netWealth[][];			// all the netWealth metrics (each for run and step)
	private float avgnetWealth[];			// average over all the runs for each step
	private float stdnetWealth[];			// std over all the runs for each step
	private float[] min_netWealth;
	private float[] max_netWealth;
	
	// fields for changes in the agents' strategies
	private int strategyChanges[][];			// the number of strategy changes in the agents (each for run and step)
	private float avgStrategyChanges[];			// average of the number of strategy changes over all the runs for each step
	private float stdStrategyChanges[];			// std of the number of strategy changes over all the runs for each step
	private float[] min_StrategyChanges;		// min of the number of strategy changes over all the runs for each step
	private float[] max_StrategyChanges;		// max of the number of strategy changes over all the runs for each step
				
	private String expName;				// the key name of this experiment (all the MC runs)
	
	
	// ########################################################################	
	// Methods/Functions 	
	// ########################################################################

	//--------------------------- Getters and setters ---------------------------//


	/**
	 * @return the numberRuns
	 */
	public int getNumberRuns() {
		return numberRuns;
	}

	/**
	 * @param _numberRuns the numberRuns to set
	 */
	public void setNumberRuns(int _numberRuns) {
		this.numberRuns = _numberRuns;
	}

	/**
	 * @return the stdk_T
	 */
	public float[] getStdk_T() {
		return stdk_T;
	}

	/**
	 * @param _stdk_T the stdk_T to set
	 */
	public void setStdk_T(float _stdk_T[]) {
		this.stdk_T= _stdk_T;
	}

	/**
	 * @return the avgk_T
	 */
	public float[] getAvgk_T() {
		return avgk_T;
	}

	/**
	 * @param _avgk_T the avgk_T to set
	 */
	public void setAvgk_T(float _avgk_T[]) {
		this.avgk_T = _avgk_T;
	}

	/**
	 * @return the k_T
	 */
	public int[][] getk_T() {
		return k_T;
	}

	/**
	 * @param _k_T the k_T to set
	 */
	public void setk_T(int _k_T[][]) {
		this.k_T = _k_T;
	}

	/**
	 * @return the stdk_U
	 */
	public float[] getStdStrategyChanges() {
		return stdStrategyChanges;
	}

	/**
	 * @param _stdStrategyChanges the stdStrategyChanges to set
	 */
	public void setStdStrategyChanges(float[] _stdStrategyChanges) {
		this.stdStrategyChanges = _stdStrategyChanges;
	}

	/**
	 * @return the avgStrategyChanges
	 */
	public float[] getAvgStrategyChanges() {
		return avgStrategyChanges;
	}

	/**
	 * @param _avgStrategyChanges the avgStrategyChanges to set
	 */
	public void setAvgStrategyChanges(float _avgStrategyChanges[]) {
		this.avgStrategyChanges = _avgStrategyChanges;
	}

	/**
	 * @return the strategyChanges
	 */
	public int[][] getStrategyChanges() {
		return strategyChanges;
	}

	/**
	 * @param _StrategyChanges the StrategyChanges to set
	 */
	public void setStrategyChanges(int _StrategyChanges[][]) {
		this.strategyChanges = _StrategyChanges;
	}
	
	/**
	 * @return the stdk_U
	 */
	public float[] getStdk_U() {
		return stdk_U;
	}

	/**
	 * @param _stdk_U the stdk_U to set
	 */
	public void setStdk_U(float[] _stdk_U) {
		this.stdk_U = _stdk_U;
	}

	/**
	 * @return the avgk_U
	 */
	public float[] getAvgk_U() {
		return avgk_U;
	}

	/**
	 * @param _avgk_U the avgk_U to set
	 */
	public void setAvgk_U(float _avgk_U[]) {
		this.avgk_U = _avgk_U;
	}

	/**
	 * @return the k_U
	 */
	public int[][] getk_U() {
		return k_U;
	}

	/**
	 * @param _k_U the k_U to set
	 */
	public void setk_U(int _k_U[][]) {
		this.k_U = _k_U;
	}

	/**
	 * @return the stdnetWealth
	 */
	public float[] getStdnetWealth() {
		return stdnetWealth;
	}

	/**
	 * @param _stdnetWealth the stdnetWealth to set
	 */
	public void setStdnetWealth(float[] _stdnetWealth) {
		this.stdnetWealth = _stdnetWealth;
	}

	/**
	 * @return the avgnetWealth
	 */
	public float[] getAvgnetWealth() {
		return avgnetWealth;
	}
	
	public String getExpName() {
		return expName;
	}

	public void setExpName(String expName) {
		this.expName = expName;
	}

	/**
	 * @param _avgnetWealth the avgnetWealth to set
	 */
	public void setAvgnetWealth(float[] _avgnetWealth) {
		this.avgnetWealth = _avgnetWealth;
	}

	/**
	 * @return the netWealth
	 */
	public float[][] getnetWealth() {
		return netWealth;
	}

	/**
	 * @param _netWealth the netWealth to set for run _numberOfRun
	 */
	public void setnetWealthForRun(int _numberOfRun, float _netWealth[]) {
		
		for (int i = 0; i < this.numberSteps; i++)
			this.netWealth[_numberOfRun][i] = _netWealth[i];
	}
	
	/**
	 * @param _k_I k_I value to set for run _numberOfRun
	 */
	public void setk_IForRun(int _numberOfRun, int _k_I[]) {
		
		for (int i = 0; i < this.numberSteps; i++)
			this.k_I[_numberOfRun][i] = _k_I[i];
		
	}

	/**
	 * @param _k_T k_T value to set for run _numberOfRun
	 */
	public void setk_TForRun(int _numberOfRun, int _k_T[]) {
		
		for (int i = 0; i < this.numberSteps; i++)
			this.k_T[_numberOfRun][i] = _k_T[i];
		
	}

	/**
	 * 
	 * @param _numberOfRun number of the run to which we will set the changes in the strategies 
	 * @param _strategyChanges value of changing strategies to set for run _numberOfRun
	 */
	public void setStrategyChangesForRun(int _numberOfRun, int _strategyChanges[]) {
		
		for (int i = 0; i < this.numberSteps; i++)
			this.strategyChanges[_numberOfRun][i] = _strategyChanges[i];
		
	}
	/**
	 * @param _numberOfRun number of the run to which we will set the value of k_U 
	 * @param k_U k_U value to set for run _numberOfRun
	 */
	public void setk_UForRun(int _numberOfRun, int _k_U[]) {
		
		for (int i = 0; i < this.numberSteps; i++)
			this.k_U[_numberOfRun][i] = _k_U[i];
		
	}
	
	/**
	 * @param _netWealth the netWealth to set
	 */
	public void setnetWealth(float _netWealth[][]) {
		
		this.netWealth = _netWealth;
	}
	
	/**
	 * @return the stdk_I
	 */
	public float[] getStdk_I() {
		return stdk_I;
	}

	/**
	 * @param _stdk_I the stdk_I to set
	 */
	public void setStdk_I(float[] _stdk_I) {
		this.stdk_I = _stdk_I;
	}

	/**
	 * @return the avgk_I
	 */
	public float[] getAvgk_I() {
		return avgk_I;
	}

	/**
	 * @param _avgk_I the avgk_I to set
	 */
	public void setAvgk_I(float _avgk_I[]) {
		this.avgk_I = _avgk_I;
	}

	/**
	 * @return the k_I
	 */
	public int[][] getk_I() {
		return k_I;
	}

	/**
	 * @param _k_I the k_I to set
	 */
	public void setk_I(int _k_I[][]) {
		this.k_I = _k_I;
	}
	
	/**
	 * @return the numberSteps
	 */
	public int getNumberSteps() {
		return numberSteps;
	}

	/**
	 * @param _numberSteps the numberSteps to set
	 */
	public void setNumberSteps(int _numberSteps) {
		this.numberSteps = _numberSteps;
	}
	
    
	//--------------------------- Constructor ---------------------------//
	/**
	 * constructor of Stats
	 * @param _nRuns
	 */
	public RunStats (int _nRuns, int _nSteps){

		numberRuns = _nRuns;
		numberSteps = _nSteps;
		
		// allocating space for metrics
		this.k_I = new int[_nRuns][_nSteps];
		this.k_T = new int[_nRuns][_nSteps];
		this.k_U = new int[_nRuns][_nSteps];
		this.netWealth = new float[_nRuns][_nSteps];
		this.strategyChanges = new int[_nRuns][_nSteps];

		this.avgk_I = new float[_nSteps];	
		this.stdk_I = new float[_nSteps];
		this.min_k_I = new float[_nSteps];	
		this.max_k_I = new float[_nSteps];

		this.avgk_T = new float[_nSteps];	
		this.stdk_T = new float[_nSteps];
		this.min_k_T = new float[_nSteps];	
		this.max_k_T = new float[_nSteps];

		this.avgk_U = new float[_nSteps];	
		this.stdk_U = new float[_nSteps];
		this.min_k_U = new float[_nSteps];	
		this.max_k_U = new float[_nSteps];
		
		this.avgnetWealth = new float[_nSteps];	
		this.stdnetWealth = new float[_nSteps];
		this.min_netWealth = new float[_nSteps];	
		this.max_netWealth = new float[_nSteps];

		this.avgStrategyChanges = new float[_nSteps];	
		this.stdStrategyChanges = new float[_nSteps];
		this.min_StrategyChanges = new float[_nSteps];	
		this.max_StrategyChanges = new float[_nSteps];
		
	}
		
	/**
	 * This method prints all the steps values (avg and stdev of the MC RUNS) to a stream file (or to the console)
	 * @param writer that is opened before calling the function
	 */
	public void printTimeSeriesStats(PrintWriter writer) {
		
		writer.println("step;netWealthAvg;netWealthStd;netWealthMin;netWealthMax;"
				+ "k_IAvg;k_IStd;k_IMin;k_IMax;k_TAvg;k_TStd;k_TMin;k_TMax;k_UAvg;k_UStd;k_UMin;k_UMax;" +
				"strategyChangesAvg;strategyChangesStd;strategyChangesMin;strategyChangesMax;");
		
		for (int i = 0; i < this.numberSteps; i++) {
			
			String toPrint = i + ";" 
					+ String.format("%.4f", this.avgnetWealth[i]) + ";" + String.format("%.4f", this.stdnetWealth[i]) + ";" 
					+ String.format("%.4f", this.min_netWealth[i]) + ";" + String.format("%.4f", this.max_netWealth[i]) + ";"
					+ String.format("%.4f", this.avgk_I[i]) + ";" + String.format("%.4f", this.stdk_I[i]) + ";" 
					+ String.format("%.4f", this.min_k_I[i]) + ";" + String.format("%.4f", this.max_k_I[i]) + ";"
					+ String.format("%.4f", this.avgk_T[i]) + ";" + String.format("%.4f", this.stdk_T[i]) + ";" 
					+ String.format("%.4f", this.min_k_T[i]) + ";" + String.format("%.4f", this.max_k_T[i]) + ";"
					+ String.format("%.4f", this.avgk_U[i]) + ";" + String.format("%.4f", this.stdk_U[i]) + ";" 
					+ String.format("%.4f", this.min_k_U[i]) + ";"+ String.format("%.4f", this.max_k_U[i]) + ";"
					+ String.format("%.4f", this.avgStrategyChanges[i]) + ";" + String.format("%.4f", this.stdStrategyChanges[i]) + ";" 
					+ String.format("%.4f", this.min_StrategyChanges[i]) + ";" + String.format("%.4f", this.max_StrategyChanges[i]) + ";\n";
					
			writer.print (toPrint);
		}
			
	}
		

	/**
	 * This method prints summarized stats (avg and std of MC runs) to a stream file (or to the console)
	 * @param append true if we append the line to an existing file, false if we destroy it first
	 * @param writer that is opened before calling the function
	 */
	public void printSummaryStats (PrintWriter writer, boolean append) {
		
		String toPrint = "keyNameExp;" + this.expName + ";netWealth;" 
				+ String.format("%.4f", this.avgnetWealth[(this.numberSteps - 1)]) + ";" + 
				String.format("%.4f", this.stdnetWealth[(this.numberSteps - 1)]) + ";k_I;" 
				+ String.format("%.4f", this.avgk_I[(this.numberSteps - 1)]) + ";" + 
				String.format("%.4f", this.stdk_I[(this.numberSteps - 1)]) 	+ ";k_T;" + 
				String.format("%.4f", this.avgk_T[(this.numberSteps - 1)]) + ";" + 
				String.format("%.4f", this.stdk_T[(this.numberSteps - 1)]) + ";k_U;" 
				+ String.format("%.4f", this.avgk_U[(this.numberSteps - 1)]) + ";" + 
				String.format("%.4f", this.stdk_U[(this.numberSteps - 1)]) + ";strategyChanges;" 
				+ String.format("%.4f", this.avgStrategyChanges[(this.numberSteps - 1)]) + ";" + 
				String.format("%.4f", this.stdStrategyChanges[(this.numberSteps - 1)]) + ";";
		
		if (append) {
			writer.append (toPrint);
			writer.append("\n");
		} else {
			writer.println (toPrint);
		}
					
			
	
	}
	
	/**
	 * This method prints (by appending to an existing file) the 
	 * summarized stats (avg and std of MC runs) to a stream file (or to the console)
	 * @param writer that is opened before calling the function
	 */
	public void appendSummaryStats (PrintWriter writer) {		
		printSummaryStats (writer, true);				
	}
	
	/**
	 * This method prints all the stats of the MC runs (by appending to an existing file) 
	 * to a stream file (or to the console)
	 * @param writer that is opened before calling the function
	 */
	public void appendAllStats (PrintWriter writer) {		
		printAllStats (writer, true);				
	}

	
	/**
	 * This method prints all the stats of the MC runs to a stream file (or to the console)
	 * @param writer that is opened before calling the function
	 * @param append true if we append the line to an existing file, false if we destroy it first
	 */
	public void printAllStats (PrintWriter writer, boolean append) {
		 			
		for (int i = 0; i < this.numberRuns; i++) {
			
			String toPrint = "keyNameExp;" + this.expName + ";MCrun;" + i + ";netWealth;" + 
					String.format("%.4f", this.netWealth[i][(this.numberSteps - 1)]) + ";k_I;" 
				+  String.format("%d", this.k_I[i][(this.numberSteps - 1)]) 
				+ ";k_T;" + String.format("%d", this.k_T[i][(this.numberSteps - 1)]) + ";k_U;" 
				+ String.format("%d", this.k_U[i][(this.numberSteps - 1)]) + ";strategyChanges;" 
				+ String.format("%d", this.strategyChanges[i][(this.numberSteps - 1)]) + ";\n";
		
			
			if (append) 	
				writer.append (toPrint);				
			else 					
				writer.print (toPrint);					
		}	
	}
	
	/**
	 * This method prints summarized stats of the last quartile of the simulation (avg and std of MC runs) 
	 * to a stream file (or to the console)
	 * @param append true if we append the line to an existing file, false if we destroy it first
	 * @param writer that is opened before calling the function
	 */
	public void printSummaryStatsByAveragingLastQuartile (PrintWriter writer, boolean append) {
		
		double lastQuartileNW = 0.;
		double lastQuartileK_I = 0.;
		double lastQuartileK_T = 0.;
		double lastQuartileK_U = 0.;
		double lastQuartileStrategyChanges = 0.;

		double lastQuartileNWStd = 0.;
		double lastQuartileK_IStd = 0.;
		double lastQuartileK_TStd = 0.;
		double lastQuartileK_UStd = 0.;
		double lastQuartileStrategyChangesStd = 0.;
		
		// check the number of steps which means the last 25% of them
		int quartileSteps = (int) Math.round(0.25*this.numberSteps);
		
		for ( int j = 1; j <= quartileSteps; j++) {
			
			// averaging the MC outputs for the last quartile of the simulation
			lastQuartileNW += this.avgnetWealth[(this.numberSteps - j)];
			lastQuartileK_I += this.avgk_I[(this.numberSteps - j)];
			lastQuartileK_T += this.avgk_T[(this.numberSteps - j)];
			lastQuartileK_U += this.avgk_U[(this.numberSteps - j)];
			lastQuartileStrategyChanges += this.avgStrategyChanges[(this.numberSteps - j)];
			
			// averaging the MC stdev outputs for the last quartile of the simulation
			lastQuartileNWStd += this.stdnetWealth[(this.numberSteps - j)];
			lastQuartileK_IStd += this.stdk_I[(this.numberSteps - j)];
			lastQuartileK_TStd += this.stdk_T[(this.numberSteps - j)];
			lastQuartileK_UStd += this.stdk_U[(this.numberSteps - j)];
			lastQuartileStrategyChangesStd += this.stdStrategyChanges[(this.numberSteps - j)];			
			
		}

		lastQuartileNW /= quartileSteps;
		lastQuartileK_I /= quartileSteps;
		lastQuartileK_T /= quartileSteps;
		lastQuartileK_U /= quartileSteps;
		lastQuartileStrategyChanges /= quartileSteps;
		
		lastQuartileNWStd /= quartileSteps;
		lastQuartileK_IStd /= quartileSteps;
		lastQuartileK_TStd /= quartileSteps;
		lastQuartileK_UStd /= quartileSteps;
		lastQuartileStrategyChangesStd /= quartileSteps;
		
		String toPrint = "LQkeyNameExp;" + this.expName + ";netWealthLQ;" 
				+ String.format("%.4f", lastQuartileNW) + ";" + String.format("%.4f", lastQuartileNWStd) + ";k_ILQ;" 
				+ String.format("%.4f", lastQuartileK_I) + ";" + String.format("%.4f", lastQuartileK_IStd) 
				+ ";k_TLQ;" + String.format("%.4f", lastQuartileK_T) + ";" + String.format("%.4f", lastQuartileK_TStd) + ";k_ULQ;" 
				+ String.format("%.4f", lastQuartileK_U) + ";" + String.format("%.4f", lastQuartileK_UStd) + ";strategyChangesLQ;" 
				+ String.format("%.4f", lastQuartileStrategyChanges) + ";" + String.format("%.4f", lastQuartileStrategyChangesStd) + ";";
				
		if (append) {
			writer.append (toPrint);
			writer.append("\n");
		} else {
			writer.println (toPrint);
		}	
			
	}
	
	
	/**
	 * This method prints all the averaging stats in the last quartile of the simulation for all 
	 * the MC runs to a stream file (or to the console)
	 * @param writer that is opened before calling the function
	 * @param append true if we append the line to an existing file, false if we destroy it first
	 */
	public void printAllStatsByAveragingLastQuartile (PrintWriter writer, boolean append) {
		
		for ( int i = 0; i < this.numberRuns; i++) {
			
			double lastQuartileNW = 0.;
			double lastQuartileK_I = 0.;
			double lastQuartileK_T = 0.;
			double lastQuartileK_U = 0.;
			double lastQuartileStrategyChanges = 0.;
			
			// check the number of steps which means the last 25% of them
			int quartileSteps = (int)Math.round(0.25*this.numberSteps);
			
			for ( int j = 1; j <= quartileSteps; j++) {
				lastQuartileNW += this.netWealth[i][(this.numberSteps - j)];
				lastQuartileK_I += this.k_I[i][(this.numberSteps - j)];
				lastQuartileK_T += this.k_T[i][(this.numberSteps - j)];
				lastQuartileK_U += this.k_U[i][(this.numberSteps - j)];
				lastQuartileStrategyChanges += this.strategyChanges[i][(this.numberSteps - j)];
			}

			lastQuartileNW /= quartileSteps;
			lastQuartileK_I /= quartileSteps;
			lastQuartileK_T /= quartileSteps;
			lastQuartileK_U /= quartileSteps;
			lastQuartileStrategyChanges /= quartileSteps;
			
			String toPrint = "LQKeyNameExp;" + this.expName + ";MCrun;" + i + ";netWealthLQ;" + 
					String.format("%.4f", lastQuartileNW) + ";k_ILQ;" 
					+  String.format("%.4f", lastQuartileK_I) 
					+ ";k_TLQ;" + String.format("%.4f", lastQuartileK_T) + ";k_ULQ;" 
					+ String.format("%.4f", lastQuartileK_U) + ";strategyChangesLQ;" 
					+ String.format("%.4f", lastQuartileStrategyChanges) + ";\n";
					
			if (append) 
				writer.append (toPrint);		
			else 
				writer.print (toPrint);					
			
		}	
		
	}
	
	
	/**
	 * This method is for calculating all the statistical information for 
	 * the runs of the metrics
	 * 	 
	 */
	public void calcAllStats () {
					
		for( int j = 0; j < this.numberSteps; j++) {
			
			// Get a DescriptiveStatistics instance
			DescriptiveStatistics statsk_I = new DescriptiveStatistics();
			DescriptiveStatistics statsk_T = new DescriptiveStatistics();
			DescriptiveStatistics statsk_U = new DescriptiveStatistics();
			DescriptiveStatistics statsnetWealth = new DescriptiveStatistics();
			DescriptiveStatistics statsStrategyChanges = new DescriptiveStatistics();
			
			// Add the data from the array
			for( int i = 0; i < this.numberRuns; i++) {
				
		        statsk_I.addValue(this.k_I[i][j]);
		        statsk_T.addValue(this.k_T[i][j]);
		        statsk_U.addValue(this.k_U[i][j]);
		        
		        statsnetWealth.addValue(this.netWealth[i][j]);	  
		        
		        statsStrategyChanges.addValue(this.strategyChanges[i][j]);	 		        
		        
			}

			// calc mean and average for all of them
			
			this.avgk_I[j] = (float)statsk_I.getMean();	
			this.stdk_I[j] = (float)statsk_I.getStandardDeviation();
			this.min_k_I[j] = (float)statsk_I.getMin();	
			this.max_k_I[j] = (float)statsk_I.getMax();
			
			this.avgk_T[j] = (float)statsk_T.getMean();	
			this.stdk_T[j] = (float)statsk_T.getStandardDeviation();
			this.min_k_T[j] = (float)statsk_T.getMin();	
			this.max_k_T[j] = (float)statsk_T.getMax();

			this.avgk_U[j] = (float)statsk_U.getMean();	
			this.stdk_U[j] = (float)statsk_U.getStandardDeviation();
			this.min_k_U[j] = (float)statsk_U.getMin();	
			this.max_k_U[j] = (float)statsk_U.getMax();
			
			this.avgnetWealth[j] = (float)statsnetWealth.getMean();	
			this.stdnetWealth[j] = (float)statsnetWealth.getStandardDeviation();
			this.min_netWealth[j] = (float)statsnetWealth.getMin();	
			this.max_netWealth[j] = (float)statsnetWealth.getMax();

			this.avgStrategyChanges[j] = (float)statsStrategyChanges.getMean();	
			this.stdStrategyChanges[j] = (float)statsStrategyChanges.getStandardDeviation();
			this.min_StrategyChanges[j] = (float)statsStrategyChanges.getMin();	
			this.max_StrategyChanges[j] = (float)statsStrategyChanges.getMax();
		}				
	}

}
