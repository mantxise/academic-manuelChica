package view;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import controller.Controller;
import model.Model;
import model.ModelParameters;

//----------------------------- MAIN FUNCTION -----------------------------//

/**
 * Main function.
 * 
 * @param args
 */

public class ConsoleSimulation {		

	// constants to get different options for simple or SA runs
	public final static int NO_SA = 0;
	public final static int SA_INITIAL_POPULATION = 1;
	public final static int SA_RT_RU = 2;
	
	
	// LOGGING
	private static final Logger log = Logger.getLogger( Model.class.getName() );
	
	/**
	 * Create an options class to store all the arguments of the command-line call of the program
	 * 
	 * @param options the class containing the options, when returned. It has to be created before calling
	 */
	private static void createArguments (Options options) {
				
		options.addOption("paramsFile", true, "Pathfile with the parameters file");
		options.getOption("paramsFile").setRequired(true);
		
		options.addOption("SNFile", true, "File with the SN to run");
		
		options.addOption("outputFile", true, "File to store all the information about the simulation");
		options.getOption("outputFile").setRequired(true);
		
		options.addOption("percentageTrusters", true, "% of agents to be trusters at the beginning of the simulation");
		options.addOption("percentageTrustworthies", true, "% of agents to be trustworthy trustees at the beginning of the simulation");
		
		options.addOption("R_T", true, "R_T value");
		options.addOption("R_U", true, "R_U value");
		
		options.addOption("maxSteps", true, "Max number of steps of the simulation");

		options.addOption("MC", true, "Number of MC simulations");
		options.addOption("seed", true, "Seed for running the MC simulations");
				
		// parameters for SA
		options.addOption("SA", false, "If running a SA over the initial population parameters");		
		options.addOption("SA_RT_RU", false, "If running a SA over the ratio between R_T-R_U parameters");
				
		options.addOption("SA_trusters_min", true, "Minimum value for parameter % of trusters (OAT SA)");
		options.addOption("SA_trusters_max", true, "Maximum value for parameter % of trusters (OAT SA)");
		options.addOption("SA_trusters_step", true, "Step value forparameter % of trusters (OAT SA)");

		options.addOption("SA_trustworthies_min", true, "Minimum value for parameter % of trustworthies (OAT SA)");
		options.addOption("SA_trustworthies_max", true, "Maximum value for parameter % of trustworthies (OAT SA)");
		options.addOption("SA_trustworthies_step", true, "Step value forparameter % of trustworthies (OAT SA)");
				
		// to log additional information for studying dynamics of agents
		options.addOption("output_lattice_fractal", false, "To save in files additional information to analyze fractals");	
		options.addOption("output_spatial_corr", false, "To save in different files additional information to analyze spatil correlations");	
		options.addOption("output_spatio_temporal_corr", false, "To save information of spatio temporal correlations about the system (WARNING: much more memory needed)");	
		options.addOption("output_whole_evolution", false, "To save in files additional information of the whole system evolution");	
					
		// to show help
		options.addOption("help", false, "Show help information");	
					
		
	}
	
	/**
	 * MAIN CONSOLE-BASED FUNCTION TO RUN A SIMPLE RUN OR A SENSITIVITY ANALYSIS OF THE MODEL PARAMETERS
	 * @param args
	 */
	public static void main (String[] args) {
		
		int SA = NO_SA;
		   	
    	
		String paramsFile = "";
		String outputFile = "";

		ModelParameters params = null;
		
		// parsing the arguments
		Options options = new Options();
		
		createArguments (options);		

		// create the parser
	    CommandLineParser parser = new DefaultParser();
	    
	    try {
	    	
	        // parse the command line arguments for the given options
	        CommandLine line = parser.parse( options, args );

			// get parameters
			params = new ModelParameters();	
			
	        // retrieve the arguments
	        		    
		    if( line.hasOption( "paramsFile" ) )		    
		    	paramsFile = line.getOptionValue("paramsFile");
		    else 		    	
		    	System.err.println( "A parameters file is needed");

		    if( line.hasOption( "outputFile" ) ) 			    
		    	outputFile = line.getOptionValue("outputFile");

		    // read parameters from file
			params.readParameters(paramsFile);

			// set the outputfile
			params.setOutputFile(outputFile);
			
			
			// once parameters from file are loaded, we modify those read by arguments of command line		
			
		    // load the parameters file and later, override them if there are console arguments for these parameters
		    if( line.hasOption( "percentageTrusters" ) ) 			    
		    	params.setPercentageTrusters(Float.parseFloat(line.getOptionValue("percentageTrusters")));
		    
		    if( line.hasOption( "percentageTrustworthies" ) ) 			    
		    	params.setPercentageTrustworthies(Float.parseFloat(line.getOptionValue("percentageTrustworthies")));
			
		    // to update kI, kT, and kU from new percentages
		    params.updateKsFromPercentages();

		    // save file for the SN
		    if( line.hasOption( "SNFile" ) )		    
		    	params.setNetworkFilesPattern(line.getOptionValue("SNFile"));		    	
			  
		    // MC
		    if( line.hasOption( "MC" ) ) 			    
		    	params.setRunsMC(Integer.parseInt(line.getOptionValue("MC")));
		  
		    // seed
		    if( line.hasOption( "seed" ) ) 			    
		    	params.setSeed(Long.parseLong(line.getOptionValue("seed")));

		    // maxSteps
		    if( line.hasOption( "maxSteps" ) ) 			    
		    	params.setMaxSteps(Integer.parseInt(line.getOptionValue("maxSteps")));
		    	
		    // R_T
		    if( line.hasOption( "R_T" ) ){
		    	params.setR_T(Float.parseFloat(line.getOptionValue("R_T")));
		    }		  		    	
		    
		    // R_U
		    if( line.hasOption( "R_U" ) ){
		    	params.setR_U(Float.parseFloat(line.getOptionValue("R_U")));
		    }		    		
		    
		    // help information
		    if( line.hasOption("help") ) {
			    	
			    // automatically generate the help statement
			    HelpFormatter formatter = new HelpFormatter();
			    formatter.printHelp( "TrustDynamics. Last update April 2019. Manuel Chica", options);			   	
			}	
		  		    		    
		    // check if we have to store additional information
		    if(line.hasOption("output_lattice_fractal") ) {			    	
		    	ModelParameters.OUTPUT_LATTICE_FRACTAL = true;
			}		    
		    if(line.hasOption("output_spatial_corr") ) {			    	
		    	ModelParameters.CALCULATE_SPATIAL_CORR = true;
			}			    
		    if(line.hasOption("output_spatio_temporal_corr") ) {			    	
		    	ModelParameters.CALCULATE_SPATIO_TEMPORAL_CORR = true;
			}		    
		    if(line.hasOption("output_whole_evolution") ) {			    	
		    	ModelParameters.OUTPUT_WHOLE_EVOLUTION  = true;
			}	   
	
		    				
		    // if a SA is running
		    if( line.hasOption( "SA" ) ) {
		    	
		    	SA = SA_INITIAL_POPULATION;
		    	
		    	// we have to get the rest of the parameters of the SA running (they were changed to integer instead of ratios because of 
		    	// differences between machines when calculating the exact number of agents)
		    	
		    	if (line.hasOption( "SA_trustworthies_min" ))
		    		SensitivityAnalysis.trustworthies_min = Integer.parseInt(line.getOptionValue("SA_trustworthies_min"));
		    	if (line.hasOption( "SA_trustworthies_max" ))
		    		SensitivityAnalysis.trustworthies_max = Integer.parseInt(line.getOptionValue("SA_trustworthies_max"));
		    	if (line.hasOption( "SA_trustworthies_step" ))
		    		SensitivityAnalysis.trustworthies_step = Integer.parseInt(line.getOptionValue("SA_trustworthies_step"));
		    	
		    	if (line.hasOption( "SA_trusters_min" ))
		    		SensitivityAnalysis.trusters_min = Integer.parseInt(line.getOptionValue("SA_trusters_min"));
		    	if (line.hasOption( "SA_trusters_max" ))
		    		SensitivityAnalysis.trusters_max = Integer.parseInt(line.getOptionValue("SA_trusters_max"));
		    	if (line.hasOption( "SA_trusters_step" ))
		    		SensitivityAnalysis.trusters_step = Integer.parseInt(line.getOptionValue("SA_trusters_step"));
		    
		    } else if( line.hasOption( "SA_RT_RU" ) ) {
		    	
		    	// we have to run a SA on the ratio between R_T and R_U
		    	
		    	SA = SA_RT_RU;
		    	
		    }
		    			
	    }
	    
	    catch (ParseException exp ) {
	    	
	        // oops, something went wrong
	        System.err.println( "Parsing failed.  Reason: " + exp.getMessage() );
			log.log(Level.SEVERE, "Parsing failed.  Reason: " + exp.toString(), exp);
			
	    }
	    
	    	
        System.out.println("\n****** STARTING THE RUN OF THE TRUST DYNAMICS ABM MODEL (Apr. 2019)******\n");

        Date date = new Date();
        System.out.println("****** " + date.toString() + "******\n");

        File fileAllMC = new File ("./logs/" + "AllMCruns_" + params.getOutputFile() + ".txt");
        File fileSummaryMC = new File ("./logs/" + "SummaryMCruns_" +  params.getOutputFile() + ".txt");
        File fileAllMCLQ = new File ("./logs/" + "AllMCrunsLQ_" + params.getOutputFile() + ".txt");
        File fileSummaryMCLQ = new File ("./logs/" + "SummaryMCrunsLQ_" +  params.getOutputFile() + ".txt");
        File fileTimeSeriesMC = new File ("./logs/" + "TimeSeriesMCruns_" +  params.getOutputFile() + ".txt");
       
        // the SA check    	    			    	
	    if (SA == NO_SA) {
	    	
	    	// no SA, simple run
	    	
	    	RunStats stats;
	    	
	    	// print parameters for double-checking
	    	System.out.println("-> Parameters values:");
		    PrintWriter out = new PrintWriter(System.out, true);
	        params.printParameters(out);
	        
	        log.log(Level.FINE, "\n*** Parameters values of this model:\n" + params.export());
	        
	        
	        // START PREPARING CONTROLLER FOR RUNNING
			long time1 = System.currentTimeMillis ();
		
			Controller controller;
			
			controller = new Controller (params, paramsFile);
			
	        // END PREPARING CONTROLLER FOR RUNNING
	 		
			
			// BEGIN RUNNING MODEL WITH ALL THE MC SIMULATION
	 		stats = controller.runModel();		
	 		// END RUNNING MODEL WITH ALL THE MC SIMULATION
	 		
	 		stats.setExpName(params.getOutputFile());
	 		
	 		long  time2  = System.currentTimeMillis( );
	 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the simulation");
	 		
	 		stats.calcAllStats();
	         
	 		// print the stats in the screen 		
	 		stats.printSummaryStats(out, false);
	 		stats.printSummaryStatsByAveragingLastQuartile(out, false);  // also the last quartile info
	 		System.out.println();
	 		
	 		// print the stats into a file
	        System.out.println("\n****** Stats also saved into a file ******\n");
	         
	        PrintWriter printWriter;
	         
	 		try {
	 			
	 			// print all the runs info into a file
	 			printWriter = new PrintWriter (fileAllMC);
	 			stats.printAllStats (printWriter, false);
	 	        printWriter.close (); 
	 	        
	 	        // print all the runs info (last quartiles of the sims) into a file
	 			printWriter = new PrintWriter (fileAllMCLQ);
	 			stats.printAllStatsByAveragingLastQuartile (printWriter, false);
	 	        printWriter.close ();  
	 	        
	 	        // print the summarized MC runs into a file
	 	        printWriter = new PrintWriter (fileSummaryMC);
	 			stats.printSummaryStats (printWriter, false);
	 	        printWriter.close ();    
	 	        
	 	        // print the summarized MC runs (last quartiles of the sims) into a file
	 	        printWriter = new PrintWriter (fileSummaryMCLQ);
	 			stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);
	 	        printWriter.close ();    

	 	        // print the time series into a file
	 	        printWriter = new PrintWriter (fileTimeSeriesMC);
	 			stats.printTimeSeriesStats (printWriter);
	 	        printWriter.close ();    
	 	        
	 	        
	 		} catch (FileNotFoundException e) {
	 			
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 			
	 		    log.log( Level.SEVERE, e.toString(), e );
	 		} 
	    	
	    } else {
	    
	    	// SA over the initial population
	    	
	    	if (SA == SA_INITIAL_POPULATION) {
	    			    	    
	    		SensitivityAnalysis.runSA_kI_kT_kU (params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	} else if ( SA == SA_RT_RU) {
	    		
	    		SensitivityAnalysis.runSA_RT_RU (params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	}
	    
	    }
								
	}
	
	
}
