package view;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


import controller.Controller;
import model.Model;
import model.ModelParameters;


/**
 * SA class to run and save results when running the MC model with different parameter configuration
 * from a config base
 * 
 * @param args
 */

public class SensitivityAnalysis {		
	
	// CHANGED TO CONSIDER ABSOLUTE VALUES AND NOT PERCENTAGES!! (BECAUSE OF HAVING DIFFERENCES BETWEEN MACHINES...)

	static int trusters_min = 0;
	static int trusters_max = 0;
	static int trusters_step = 0;
			
	static int trustworthies_min = 0;
	static int trustworthies_max = 0;
	static int trustworthies_step = 0;
	
	
	// LOGGING
	private static final Logger log = Logger.getLogger( Model.class.getName() );
	
	/**
	 * Static function to run a SA (OAT) for k_I,k_T,k_U
	 * 
	 */	
	public static void runSA_kI_kT_kU (ModelParameters _params, String _paramsFile, 
			File fileAllMC, File fileSummaryMCRuns, File fileAllMCLQ, File fileSummaryMCRunsLQ) {

		// create output files in case they exist as we will append the simulation contents
		
		if (fileAllMC.exists() && !fileAllMC.isDirectory()) {
			fileAllMC.delete();
		}
		
		if (fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory()) {
			fileSummaryMCRuns.delete();
		}
		
		if (fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory()) {
			fileAllMCLQ.delete();
		}
		
		if (fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory()) {
			fileSummaryMCRunsLQ.delete();
		}
		
		
		// *********************  Arrays with the k_I,k_T param values
		/* int[] values_k_1 = {
		//		1, 5, 7, 10, 20, 30, 50, 75, 100, 125, 200, 250
				150, 200, 250, 300, 350, 400
		};
		
		int[] values_k_2 = {
				// 0, 1, 5, 7, 10, 20, 30, 50, 75, 100, 125, 200, 500
				150, 200, 250, 300, 350, 400, 450, 500
		};
		// *********************  Arrays with the k_I,k_T param values */
		
		// create the arrays with the k_I, k_T values from min, max and step values
		ArrayList<Integer> values_k_I = new ArrayList<Integer>();
		ArrayList<Integer> values_k_T = new ArrayList<Integer>();
		
		/*int min_k_1 = (int) Math.round(trusters_min * _params.getNrAgents());
		int min_k_2 = (int) Math.round(trustworthies_min * _params.getNrAgents());
		
		int max_k_1 = (int) Math.round(trusters_max * _params.getNrAgents());
		int max_k_2 = (int) Math.round(trustworthies_max * _params.getNrAgents());
		
		int step_k_1 = (int) Math.round(trusters_step * _params.getNrAgents());
		int step_k_2 = (int) Math.round(trustworthies_step * _params.getNrAgents());*/
		
		// CHANGED TO CONSIDER ABSOLUTE VALUES AND NOT PERCENTAGES!! (DIFFERENCES BETWEEN MACHINES)
		int min_k_I = trusters_min;
		int min_k_T = trustworthies_min;
		
		int max_k_I = trusters_max;
		int max_k_T = trustworthies_max;
		
		int step_k_I = trusters_step;
		int step_k_T = trustworthies_step;
		
		// save the values to the array of k1s
		for (int i = min_k_I; i <= max_k_I; i += step_k_I) {
			values_k_I.add(i);
		}
		
		for (int i = min_k_T; i <= max_k_T; i += step_k_T) {
			values_k_T.add(i);
		}				
		
	    Controller controller = new Controller (_params, _paramsFile);

	    for (int i = 0; i < values_k_I.size(); i++ ) {

		    for (int j = 0; j < values_k_T.size(); j++ ) {
		    	
		    	// check if we have more agents of k1 and k2 than the total number of agents
		    	if ( (values_k_I.get(i) + values_k_T.get(j)) > _params.getNrAgents()) {
		    		
		    		log.log( Level.FINE, "\n-> OAT Warning: No running for " + values_k_I.get(i) + ", " + values_k_T.get(j) 
		 		    + " as there are more k_I,k_T than the total number of agents");
		    		
		    		System.out.println("-> OAT Warning: No running for " + values_k_I.get(i) + ", " + values_k_T.get(j) 
		 		    + " as there are more k_I,k_T than the total number of agents");
		 				   
		    	} else {
		    		
		    		// the number of k1s and k2s is correct
		    		
		    		// set the given k values to the params	    	
			    	_params.setk_I(values_k_I.get(i));
			    	_params.setk_T(values_k_T.get(j));
			    	_params.setk_U(_params.getNrAgents() - (values_k_I.get(i) + values_k_T.get(j)));

			        System.out.println("-> OAT for k_I = " + _params.getk_I() + " k_T = " + _params.getk_T() +
			        		" k_U = " + _params.getk_U());

					log.log(Level.FINE, "\n****** Running Monte-Carlo simulation for OAT configuration: k_I = " + 
							_params.getk_I() + " k_T = " + _params.getk_T() + " k_U = " + _params.getk_U() + " \n");
			
					RunStats stats;

					long time1 = System.currentTimeMillis ();
					
			 		// running the model with the MC simulations
			 		stats = controller.runModel();		

			 		long  time2  = System.currentTimeMillis( );
			 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the OAT simulation");

			 		// calculate the stats for this run and set the name of this experiment
			 		stats.setExpName("k_IValue;" + _params.getk_I() + ";k_TValue;" + _params.getk_T() + ";k_UValue;" + _params.getk_U());		    	
			 		stats.calcAllStats();

					PrintWriter out = new PrintWriter(System.out, true);
					_params.printParameters(out);
					 
			 		// print the stats in the screen 		
			        System.out.println("\n****** Stats of this OAT configuration ******\n");
			 		stats.printSummaryStats (out, false);
			 		stats.printSummaryStatsByAveragingLastQuartile(out, false);

					// print the stats into a file
					System.out.println("\n****** Stats of this OAT configuration also saved into a file ******\n");
					
					PrintWriter printWriter;
			         
			 		try {
			 			
			 			// print all the runs in a file 			
			 			printWriter = new PrintWriter (new FileOutputStream(fileAllMC, true));
			 			
			 			if ( fileAllMC.exists() && !fileAllMC.isDirectory() )
			 		        stats.appendAllStats (printWriter);		 		        
			 		    else
				 			stats.printAllStats (printWriter, false);	
			 	        printWriter.close ();       	
			 	        
			 	        // print the summarized MC runs in a file
			 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRuns, true));
			 	        
			 	        if ( fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory() )
			 	    	    stats.appendSummaryStats (printWriter);		 		        
			 		    else		 		    	
			 		    	stats.printSummaryStats (printWriter, false);	
			 	        printWriter.close ();    
			 	    
			 	        // print all the runs in a file 			
			 			printWriter = new PrintWriter (new FileOutputStream(fileAllMCLQ, true));
			 			
			 			if ( fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory() )
				 			stats.printAllStatsByAveragingLastQuartile(printWriter, true);	      
			 		    else
				 			stats.printAllStatsByAveragingLastQuartile(printWriter, false);	
			 	        printWriter.close ();       	
			 	        
			 	        // print the summarized MC runs in a file
			 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRunsLQ, true));
			 	        
			 	        if ( fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory() )
			 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, true);	
			 		    else		 		    	
			 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);	
			 	        printWriter.close ();    
			 	        
			 		} catch (FileNotFoundException e) {
			 			
			 			// TODO Auto-generated catch block
			 			e.printStackTrace();
			 			
			 		    log.log( Level.SEVERE, e.toString(), e );
			 		} 
		    	}
		    	
		    }
	    }	    					
		
	}
	
	/**
	 * Static function to run a SA for the combination of R_T/R_U
	 * by using a ratio from 0.5 to 1 and therefore, get all the possible R_U
	 * combinations from the value of R_T
	 * 
	 */	
	public static void runSA_RT_RU (ModelParameters _params, String _paramsFile, 
			File fileAllMC, File fileSummaryMCRuns, File fileAllMCLQ, File fileSummaryMCRunsLQ) {

		// create output files in case they exist as we will append the simulation contents
		

		if (fileAllMC.exists() && !fileAllMC.isDirectory()) {
			fileAllMC.delete();
		}
		
		if (fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory()) {
			fileSummaryMCRuns.delete();
		}
		
		if (fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory()) {
			fileAllMCLQ.delete();
		}
		
		if (fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory()) {
			fileSummaryMCRunsLQ.delete();
		}
		
		// *********************  Array with the ratio values 
		// as 1 < R_T < R_U < 2R_T, ratio is from 0 (limit value, infeasible)
		// and 1 (limit value, infeasible)
		
		// create the arrays with the R_U values
		ArrayList<Float> valuesRatio = new ArrayList<Float>();
		
		// save the values to the array of ratios
		float v = (float) 1.;
		float step = (float) 0.05;
		int k = 0;
		while (v >= 0.49){	
				    	
			valuesRatio.add(k, v);
			v = v - step;
			k ++;
		}

	    Controller controller = new Controller (_params, _paramsFile);

	    for (int i = 0; i < valuesRatio.size(); i++ ) {
		    		
    		// set the given R_U value to the params (the only changing parameter)  	
	    	float newR_T = _params.getR_T() / valuesRatio.get(i);
	    	
	    	_params.setR_UT(valuesRatio.get(i));
	    	_params.setR_U(newR_T);

	        System.out.println("-> OAT for ratio r_UT of " + valuesRatio.get(i) + 
	        		" (with a fixed R_T = " + _params.getR_T() + ") -> R_U = " + _params.getR_U());

			log.log(Level.FINE, "\n****** Running Monte-Carlo simulation for OAT configuration: R_T = " + 
					_params.getR_T() + " R_U = " + _params.getR_U() + " (set by a ratio of " + _params.getR_UT()
					+ " \n");
		
			RunStats stats;

			long time1 = System.currentTimeMillis ();
			
	 		// running the model with the MC simulations
	 		stats = controller.runModel();		

	 		long  time2  = System.currentTimeMillis( );
	 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the R_T/R_U simulation");

	 		// calculate the stats for this run and set the name of this experiment
	 		stats.setExpName("R_IValue;" + _params.getR_T() + ";R_TValue;" + _params.getR_U());		    	
	 		stats.calcAllStats();

			PrintWriter out = new PrintWriter(System.out, true);
			_params.printParameters(out);
			 
	 		// print the stats in the screen 		
	        System.out.println("\n****** Stats of this R_T/R_U OAT configuration ******\n");
	 		stats.printSummaryStats(out, false);
	 		stats.printSummaryStatsByAveragingLastQuartile(out, false);

			// print the stats into a file
			System.out.println("\n****** Stats of this R_T/R_U OAT onfiguration also saved into a file ******\n");
			
			PrintWriter printWriter;
	         
	 		try {
	 			
	 			// print all the runs in a file 			
	 			printWriter = new PrintWriter (new FileOutputStream(fileAllMC, true));
	 			
	 			if ( fileAllMC.exists() && !fileAllMC.isDirectory() )
	 		        stats.appendAllStats(printWriter);		 		        
	 		    else
		 			stats.printAllStats(printWriter, false);		 		  
	 		    
	 	        printWriter.close ();       	
	 	        
	 	        // print the summarized MC runs in a file
	 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRuns, true));
	 	        
	 	       if ( fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory() )
	 	    	    stats.appendSummaryStats(printWriter);		 		        
	 		    else		 		    	
	 		    	stats.printSummaryStats(printWriter, false);
	 		    		 				 			
	 	        printWriter.close (); 
	 	        
	 	        // print all the runs in a file 			
	 			printWriter = new PrintWriter (new FileOutputStream(fileAllMCLQ, true));
	 			
	 			if ( fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory() )
		 			stats.printAllStatsByAveragingLastQuartile(printWriter, true);		 		 
	 		    else
		 			stats.printAllStatsByAveragingLastQuartile(printWriter, false);		 		  
	 		    
	 	        printWriter.close ();       	
	 	        
	 	        // print the summarized MC runs in a file
	 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRunsLQ, true));
	 	        
	 	       if ( fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory() )
	 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, true);
	 		    else		 		    	
	 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);
	 		    		 				 			
	 	        printWriter.close ();  
	 	        
	 		} catch (FileNotFoundException e) {
	 			
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 			
	 		    log.log( Level.SEVERE, e.toString(), e );
	 		} 
    	}
    	
    }				
		
}
