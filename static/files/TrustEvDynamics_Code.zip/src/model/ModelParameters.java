package model;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Set;

import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.stream.file.FileSourceDGS;

import socialnetwork.GraphStreamer.NetworkType;
import util.*;

//import socialnetwork.GraphStreamer; 				 // It does not make sense as it is for segments
//import socialnetwork.GraphStreamer.NetworkType;    // It does not make sense as it is for segments

/**
 * Parameters of the model of evolutionary dynamics for the N-player Trust Game
 * 
 * @author mchica
 * @date 2016/04/27
 *
 */

public class ModelParameters {

	// Read configuration file
	ConfigFileReader config;
	
	// CONFIGURATION TO CALCULATE, STORE STATISTICS	
	public static boolean CALCULATE_SPATIO_TEMPORAL_CORR = false;  // IMPORTANT: this is also carrying out high consumption of memory (agents' whole evolution)
	public static boolean OUTPUT_LATTICE_FRACTAL = false; 
	public static boolean CALCULATE_SPATIAL_CORR = false;  
	public static boolean OUTPUT_WHOLE_EVOLUTION = false; 
	
	// FOR THE STRATEGY TYPE FOR AGENTS
	public final static int UNDEFINED_STRATEGY = 0;
	public final static int TRUSTER = 1;
	public final static int TRUSTWORTHY_TRUSTEE = 2;
	public final static int UNTRUSTWORTHY_TRUSTEE = 3;

	public final static int WELL_MIXED_POP = -1;
	public final static int SF_NETWORK = 0;
	public final static int ER_NETWORK = 1;
	public final static int SW_NETWORK = 2;
	public final static int PGP_NETWORK = 3;
	public final static int EMAIL_NETWORK = 4;
	public final static int REGULAR_NETWORK = 5;

	// TYPE OF UPDATE RULE FOR THE AGENTS
	public final static int PROPORTIONAL_UPDATE_RULE = 1;
	public final static int UI_UPDATE_RULE = 2;
	public final static int VOTER_UPDATE_RULE = 3;
	public final static int FERMI_UPDATE_RULE = 4;
	public final static int MORAN_UPDATE_RULE = 5;

	// ########################################################################
	// Variables
	// ########################################################################

	String outputFile;

	// modified just to use a static SN from a file

	// FILE_NETWORK ONLY!!
	// Choose between several social networks:
	// SCALE_FREE_NETWORK, scale-free (Barabasi)
	// ER_RANDOM_NETWORK
	// SW_RANDOM_NETWORK
	NetworkType typeOfNetwork;

	String networkFilesPattern;

	// graph read from file
	Graph graphFromFile;

	
	//////////////////////////////////////////////7
	
	
	// multipliers for the payoff calculation between cooperators
	float R_T; // multiplier of what is received by k_T from k_I (R_T*tv)
	float R_U; // multiplier of what is received by k_U from k_I (R_U*tv)
	float r_UT; // temptation to defect ratio which falls in (0,1). It is equal to (R_U-R_T)/R_T

	float tv; // value payed by trusters to trustee (normally fixed)

	// population distribution
	int nrAgents;

	float percentageTrusters; // percentage of agents to be trusters at the
								// beginning of the simulation w.r.t. total
								// users
	float percentageTrustworthies; // percentage of agents to be trustworthy
									// trustees w.r.t. the trustees of the pop
									// (nrAgents - (k_I*nrAgents))

	int k_I; // number of agents to be trusters/investors at the beginning of the simulation
	int k_T; // number of agents to be trustworthy trustees at the beginning of the simulation
	int k_U; // number of agents to be untrustworthy trustees at the beginning of the simulation

	// update's rule for the ev dynamics game
	int T_rounds = 1; // number of steps to update the strategy of the agents by
						// an update rule
	int maxSteps; // maximum number of steps for the simulation
	int runsMC; // number of MC runs
	int updateRule; // identifier for the update rule of the agents

	float q_VM = 1;	// q value in [0,1] to either choose the VM or UI. If 1, always VM. 1-q, UI is applied
	

	long seed; // seed to run all the simulations

	// --------------------------- Get/Set methods ---------------------------//
	//
	
	/**
	 * @return the q value for choosing between VM or UI
	 */
	public float getQ_VM() {
		return q_VM;
	}

	/** 
	 * 
	 * @param q_VM THE q value for choosing between VM or UI
	 */
	public void setQ_VM(float q_VM) {
		this.q_VM = q_VM;
	}
	
	/**
	 * @return the seed for running all the simulations
	 */
	public long getSeed() {
		return seed;
	}

	/**
	 * @param the
	 *            seed to run all the simulation
	 */
	public void setSeed(long _seed) {
		this.seed = _seed;
	}

	/**
	 * @return the max number of steps of the simulation
	 */
	public int getMaxSteps() {
		return maxSteps;
	}

	/**
	 * @param the max number of steps of the simulation
	 */
	public void setMaxSteps(int _maxSteps) {
		this.maxSteps = _maxSteps;
	}

	public String getOutputFile() {
		return outputFile;
	}

	public void setOutputFile(String outputFile) {
		this.outputFile = outputFile;
	}

	/**
	 * @return the temptation to defect ratio calculated as r_{UT}=  (R_U-R_T)/R_T
	 */
	public float getR_UT() {
		return this.r_UT;
	}

	/**
	 * @param _ratio is the ratio r_UT, calculated as r_{UT}= (R_U-R_T)/R_T
	 */
	public void setR_UT(float _ratio) {
		this.r_UT = _ratio;
	}

	/**
	 * @return the number of rounds to use the update rule
	 */
	public int getT_rounds() {
		return T_rounds;
	}

	/**
	 * @param _T_rounds
	 *            is the number of rounds to use the update rule
	 */
	public void setT_rounds(int _T_rounds) {
		this.T_rounds = _T_rounds;
	}

	/**
	 * @return the typeOfNetwork
	 */
	public NetworkType getTypeOfNetwork() {
		return typeOfNetwork;
	}

	/**
	 * @param typeOfNetwork
	 *            the typeOfNetwork to set
	 */
	public void setTypeOfNetwork(NetworkType typeOfNetwork) {
		this.typeOfNetwork = typeOfNetwork;
	}

	/**
	 * @return the graph
	 */
	public Graph getGraph() {
		return graphFromFile;
	}

	/**
	 * @param _graph
	 *            to set
	 */
	public void setGraph(Graph _graph) {
		this.graphFromFile = _graph;
	}

	public String getNetworkFilesPattern() {
		return networkFilesPattern;
	}

	public void setNetworkFilesPattern(String networkFilesPattern) {
		this.networkFilesPattern = networkFilesPattern;
	}

	/**
	 * @param _graph
	 *            to set
	 * @throws IOException
	 */
	public void readGraphFromFile(String fileNameGraph) throws IOException {

		FileSourceDGS fileSource = new FileSourceDGS();
		graphFromFile = new SingleGraph("SNFromFile");

		fileSource.addSink(graphFromFile);
		fileSource.readAll(fileNameGraph);

		fileSource.removeSink(graphFromFile);
		
		//this.displayGraph();
		
		/*System.out.println("number of nodes: " + graphFromFile.getNodeCount());

		int distr[] = Toolkit.degreeDistribution(graphFromFile);
		
		for (int k = 0; k < distr.length; k++)
			System.out.println("degree "  + k + "; " + distr[k]);*/
		
	}

	/**
	 * Display the graph
	 * 
	 * @return
	 */
	public void displayGraph (Set<Integer> k_I, Set <Integer> k_T, Set<Integer> k_U) {
	
		for (Node node : graphFromFile) {
			

			node.addAttribute("ui.color",3);
			node.setAttribute("size", "medium");
			//node.setAttribute("ui:fill-color", "blue");
			node.addAttribute("ui.label", node.getId());
			
			if (k_I.contains(Integer.getInteger(node.getId()))) {

				node.setAttribute("ui.color", 0); // The node will be green.
				
			} else if (k_T.contains(Integer.getInteger(node.getId()))) {

				node.setAttribute("ui.color", 0.5); // The node will be a mix of green and red.
				
			} else if (k_U.contains(Integer.getInteger(node.getId()))) {

				node.setAttribute("ui.color", 1); // The node will be red.
			}
			
		}
	
		graphFromFile.display();	
	}
	
	
	/**
	 * Gets the number of agents.
	 * 
	 * @return
	 */
	public int getNrAgents() {
		return nrAgents;
	}

	/**
	 * Sets the number of agents
	 * 
	 * @param nrAgents
	 */
	public void setNrAgents(int nrAgents) {
		if (nrAgents > 0)
			this.nrAgents = nrAgents;
	}

	/**
	 * Gets the type of update rule for the agents.
	 * 
	 * @return
	 */
	public int getUpdateRule() {
		return this.updateRule;
	}

	/**
	 * Sets the update rule.
	 * 
	 * @param updateRule
	 */
	public void setUpdateRule(int _updateRule) {
		this.updateRule = _updateRule;
	}

	/**
	 * Gets tv.
	 * 
	 * @return
	 */
	public float getTv() {
		return this.tv;
	}

	/**
	 * Sets tv.
	 * 
	 * @param _tv
	 */
	public void setTv(float _tv) {
		this.tv = _tv;
	}

	/**
	 * Gets R_T.
	 * 
	 * @return
	 */
	public float getR_T() {
		return this.R_T;
	}

	/**
	 * Sets R_T.
	 * 
	 * @param _R_T
	 */
	public void setR_T(float _R_T) {
		this.R_T = _R_T;
	}

	/**
	 * Gets R_U.
	 * 
	 * @return
	 */
	public float getR_U() {
		return this.R_U;
	}

	/**
	 * Sets R_U.
	 * 
	 * @param _R_U
	 */
	public void setR_U(float _R_U) {
		this.R_U = _R_U;
	}

	/**
	 * Gets percentageTrusters
	 * 
	 * @return the percentages of trustworthies w.r.t. all the population
	 */
	public float getPercentageTrusters() {
		return percentageTrusters;
	}

	/**
	 * Gets percentageTrustworthies
	 * 
	 * @return the percentages of trustworthies w.r.t. all the trustees
	 */
	public float getPercentageTrustworthies() {
		return percentageTrustworthies;
	}

	/**
	 * Sets percentageTrusters
	 * 
	 * @param percentageTrusters
	 *            is the percentage
	 */
	public void setPercentageTrusters(float percentageTrusters) {
		this.percentageTrusters = percentageTrusters;
	}

	/**
	 * Sets percentageTrustworthies
	 * 
	 * @param percentageTrustworthies
	 *            is the percentage
	 */
	public void setPercentageTrustworthies(float percentageTrustworthies) {
		this.percentageTrustworthies = percentageTrustworthies;
	}

	/**
	 * Gets k_I (number of trusters).
	 * 
	 * @return
	 */
	public int getk_I() {
		return this.k_I;
	}

	/**
	 * Sets k_I (number of trusters).
	 * 
	 * @param _k_I
	 */
	public void setk_I(int _k_I) {
		this.k_I = _k_I;
	}

	/**
	 * Gets k_T (number of trustworthy trustees).
	 * 
	 * @return
	 */
	public int getk_T() {
		return this.k_T;
	}

	/**
	 * Sets k_T (number of trustworthy trustees).
	 * 
	 * @param _k_T
	 */
	public void setk_T(int _k_T) {
		this.k_T = _k_T;
	}

	/**
	 * Gets k_U (number of untrustworthy trustees).
	 * 
	 * @return
	 */
	public int getk_U() {
		return this.k_U;
	}

	/**
	 * Sets k_U (number of untrustworthy trustees).
	 * 
	 * @param _k_U
	 */
	public void setk_U(int _k_U) {
		this.k_U = _k_U;
	}

	/**
	 * @return number of MC runs
	 */
	public int getRunsMC() {
		return runsMC;
	}

	/**
	 * Sets number of MC runs
	 * 
	 * @param _runsMC
	 */
	public void setRunsMC(int _runsMC) {
		this.runsMC = _runsMC;
	}

	// ########################################################################
	// Constructors
	// ########################################################################

	/**
	 * 
	 */
	public ModelParameters() {

	}

	// ########################################################################
	// Export methods
	// ########################################################################

	public String export() {

		String values = "";

		values += exportGeneral();

		values += exportSN();

		return values;
	}

	private String exportSN() {

		String result = "";

		result += "SNFile = " + this.networkFilesPattern + "\n";
		result += "typeOfSN = " + this.typeOfNetwork + "\n";

		return result;

	}

	private String exportGeneral() {

		String result = "";

		result += "MC_runs = " + this.runsMC + "\n";
		result += "seed = " + this.seed + "\n";

		result += "nrAgents = " + this.nrAgents + "\n";

		result += "maxSteps = " + this.maxSteps + "\n";
		result += "T_rounds = " + this.T_rounds + "\n";

		result += "percentage_trusters = " + this.percentageTrusters + "\n";
		result += "percentage_trustworthies = " + this.percentageTrustworthies + "\n";

		result += "k_I = " + this.k_I + "\n";
		result += "k_T = " + this.k_T + "\n";
		result += "k_U = " + this.k_U + "\n";

		result += "R_T = " + this.R_T + "\n";
		result += "r_UT = " + this.r_UT + "\n";
		result += "R_U = " + this.R_U + "\n";

		result += "tv = " + this.tv + "\n";

		if (this.updateRule == ModelParameters.PROPORTIONAL_UPDATE_RULE)
			result += "updateRule = PROPORTIONAL_UPDATE_RULE\n";
		
		else if (this.updateRule == ModelParameters.UI_UPDATE_RULE)
			result += "updateRule = UI_UPDATE_RULE\n";
		
		else if (this.updateRule == ModelParameters.VOTER_UPDATE_RULE) {
			result += "updateRule = VOTER_UPDATE_RULE\n";
			result += "q_VM = " + this.q_VM + "\n";
		}
			
		
		else if (this.updateRule == ModelParameters.FERMI_UPDATE_RULE)
			result += "updateRule = FERMI_UPDATE_RULE\n";
		
		else if (this.updateRule == ModelParameters.MORAN_UPDATE_RULE)
			result += "updateRule = MORAN_UPDATE_RULE\n";
			
		return result;
	}

	/** 
	 * 
	 */
	public void updateKsFromPercentages() {

		this.k_I = (int) Math.round(this.nrAgents * this.percentageTrusters);
		this.k_T = (int) Math.round(this.nrAgents * this.percentageTrustworthies);
		this.k_U = this.nrAgents - (this.k_I + this.k_T);

		/*
		 * if ((this.k_I + this.k_T + this.k_U) != this.nrAgents) { throw new
		 * IOException("Error with the k_I, k_T, k_U distribution. Check params k_I, k_T and k_U with total number of agents\n"
		 * ); }
		 */
	}

	/**
	 * Reads parameters from the configuration file.
	 */
	public void readParameters(String CONFIGFILENAME) {

		try {

			// Read parameters from the file
			config = new ConfigFileReader(CONFIGFILENAME);

			config.readConfigFile();

			// Get global parameters
			this.maxSteps = config.getParameterInteger("maxSteps");
			this.runsMC = config.getParameterInteger("MCRuns");
			this.T_rounds = config.getParameterInteger("T_rounds");
			this.seed = config.getParameterInteger("seed");

			this.nrAgents = config.getParameterInteger("nrAgents");

			// obtain the percentage of trusters and trustworthies to calculate k_I, k_T, k_U
			this.percentageTrusters = (float) config.getParameterDouble ("percentage_trusters");
			this.percentageTrustworthies = (float) config.getParameterDouble("percentage_trustworthies");

			if ((this.percentageTrusters + this.percentageTrustworthies) > 1.0) {
				throw new IOException("Error with % of trusters and trustworthies. It is > 1. "
						+ "Check params percentageTrusters and percentageTrustworthies\n");
			}

			this.updateKsFromPercentages();

			this.updateRule = config.getParameterInteger("updateRule");

			if (this.updateRule == ModelParameters.VOTER_UPDATE_RULE) {
				try {
					this.q_VM = (float) config.getParameterDouble("q_VM");
				} catch (Exception e) {
					
					// if it is not defined, q by default (= 1). Always VM
					this.q_VM = (float) 1.;
				}
					
				
			} else {
				this.q_VM = -1;
			}
			
			this.R_T = (float) config.getParameterDouble("R_T");
			this.r_UT = (float) config.getParameterDouble("r_UT");
			this.R_U = (1 + this.r_UT) * this.R_T;  // changed from initial definition which was R_T/R_U. But the correct is (R_U-R_T)/R_T

			this.tv = config.getParameterInteger("tv");

			// Always read social network file but this file can be SF, Random,
			// RW or regular

			setNetworkFilesPattern(config.getParameterString("SNFile"));

			this.readGraphFromFile(networkFilesPattern);

			if (config.getParameterInteger("typeOfNetwork") == SW_NETWORK) {

				typeOfNetwork = NetworkType.SW_NETWORK;
			}
			if (config.getParameterInteger("typeOfNetwork") == ER_NETWORK) {

				typeOfNetwork = NetworkType.RANDOM_NETWORK;
			}
			if (config.getParameterInteger("typeOfNetwork") == SF_NETWORK) {

				typeOfNetwork = NetworkType.SCALE_FREE_NETWORK;
			}
			if (config.getParameterInteger("typeOfNetwork") == WELL_MIXED_POP) {

				typeOfNetwork = NetworkType.WELL_MIXED_POP;
			}
			if (config.getParameterInteger("typeOfNetwork") == PGP_NETWORK) {

				typeOfNetwork = NetworkType.PGP_NETWORK;
			}
			if (config.getParameterInteger("typeOfNetwork") == EMAIL_NETWORK) {

				typeOfNetwork = NetworkType.EMAIL_NETWORK;
			}
			if (config.getParameterInteger("typeOfNetwork") == REGULAR_NETWORK) {

				typeOfNetwork = NetworkType.REGULAR_NETWORK;
			}

		} catch (IOException e) {

			System.err.println("Error with SN file when loading parameters for the simulation " + CONFIGFILENAME + "\n"
					+ e.getMessage());
			e.printStackTrace(new PrintWriter(System.err));
		}
	}

	// ----------------------------- I/O methods -----------------------------//

	/**
	 * Prints simple statistics evolution during the time.
	 */
	public void printParameters(PrintWriter writer) {

		// printing general params
		writer.println(this.export());

	}

}
