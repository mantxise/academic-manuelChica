package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.graphstream.graph.Edge;
import org.graphstream.graph.Node;
import org.graphstream.ui.graphicGraph.GraphPosLengthUtils;

import sim.engine.*;
import sim.util.*;

import socialnetwork.*;
import util.BriefFormatter;
import util.Colors;

import util.SpatialCorrelationSN;

/**
 * Simulation core, responsible for scheduling agents of the n-trust game
 * 
 * @author mchica
 */
public class Model extends SimState {

	// ########################################################################
	// Variables
	// ########################################################################

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	static String CONFIGFILENAME;

	// ADDITIONAL INFO FOR CALCULATING AND STORING
	public static boolean SHOW_SN = false;

	// LOGGING
	public static final Logger log = Logger.getLogger(Model.class.getName());

	// MODEL VARIABLES

	ModelParameters params;

	float minPayOff; // min payoff to be obtained by agents for the update rule
	float maxPayOff; // max payoff to be obtained by agents for the update rule

	Bag agents;

	int k_I_Agents[]; // a counter of the k_I agents during the simulation
	int k_T_Agents[]; // a counter of the k_T agents during the simulation
	int k_U_Agents[]; // a counter of the k_U agents during the simulation

	int strategyChanges[]; // array with the total number of strategy changes during the simulation

	float globalPayoffs[]; // array with the sum of all the payoffs of the population at each step

	float corrCoef[]; // array with the spatio-temporal correlation values at each step

	// SOCIAL NETWORK
	GraphStreamer socialNetwork;

	int MC_RUN = -1;

	// --------------------------- Clone method ---------------------------//

	// --------------------------- Get/Set methods ---------------------------//
	//

	public static String getConfigFileName() {
		return CONFIGFILENAME;
	}

	public static void setConfigFileName(String _configFileName) {
		CONFIGFILENAME = _configFileName;
	}

	public GraphStreamer getSocialNetwork() {
		return socialNetwork;
	}

	/**
	 * 
	 * @return the payoffs of all the agents
	 */
	public float[] getGlobalPayoffs() {
		return globalPayoffs;
	}

	/**
	 * @param _globalPayoffs is the array with the payoffs for all the agents
	 */
	public void setGlobalPayoffs(float[] _globalPayoffs) {
		this.globalPayoffs = _globalPayoffs;
	}

	/**
	 * 
	 * @return the spatio-correlation values
	 */
	public float[] getSpatioTempCorrelations() {
		return this.corrCoef;
	}

	/**
	 * @param _corr is the array with the spatio-correlation values
	 */
	public void setSpatioTempCorrelations(float[] _corr) {
		this.corrCoef = _corr;
	}

	/**
	 * 
	 * @return the bag of agents.
	 */
	public Bag getAgents() {
		return agents;
	}

	/**
	 * 
	 * @param _agents is the bag (array) of agents
	 */
	public void setAgents(Bag _agents) {
		this.agents = _agents;
	}

	/**
	 * Get the global net-wealth of the population at a given step
	 * 
	 * @return the number of k_T agents
	 */
	public float getGlobalPayoffAtStep(int _position) {
		return this.globalPayoffs[_position];
	}

	/**
	 * Get the number of k_T agents at a given step - time
	 * 
	 * @return the number of k_T agents
	 */
	public int getk_T_AgentsAtStep(int _position) {
		return k_T_Agents[_position];
	}

	/**
	 * Get the number of k_T agents for all the period of time
	 * 
	 * @return an ArrayList with the evolution of the k_T agents
	 */
	public int[] getk_T_AgentsArray() {
		return k_T_Agents;
	}

	/**
	 * Get the number of k_I agents at a given step - time
	 * 
	 * @return the number of k_I agents
	 */
	public int getk_I_AgentsAtStep(int _position) {
		return k_I_Agents[_position];
	}

	/**
	 * Get the number of k_I agents for all the period of time
	 * 
	 * @return an ArrayList with the evolution of k_I agents
	 */
	public int[] getk_I_AgentsArray() {
		return k_I_Agents;
	}

	/**
	 * Get the number of k_U agents at a given step - time
	 * 
	 * @return the number of k_U agents
	 */
	public int getk_U_AgentsAtStep(int _position) {
		return k_U_Agents[_position];
	}

	/**
	 * Get the number of changes in the strategy of the agents for all the period of
	 * time
	 * 
	 * @return an ArrayList with the evolution of the strategy changes for all the
	 *         agents
	 */
	public int[] getStrategyChanges_AgentsArray() {
		return strategyChanges;
	}

	/**
	 * Get the number of k_U agents for all the period of time
	 * 
	 * @return an ArrayList with the evolution of the k_U agents
	 */
	public int[] getk_U_AgentsArray() {
		return k_U_Agents;
	}

	/**
	 * Get the parameter object with all the input parameters
	 */
	public ModelParameters getParametersObject() {
		return this.params;
	}

	/**
	 * Set the parameters
	 * 
	 * @param _params the object to be assigned
	 */
	public void setParametersObject(ModelParameters _params) {
		this.params = _params;
	}

	// ########################################################################
	// Constructors
	// ########################################################################

	/**
	 * Initializes a new instance of the simulation class.
	 * 
	 * @param _params an object with all the parameters of the model
	 */
	public Model(ModelParameters _params) {

		super(_params.getSeed());

		try {

			// This block configure the logger with handler and formatter
			long millis = System.currentTimeMillis();
			FileHandler fh = new FileHandler("./logs/" + _params.getOutputFile() + "_" + millis + ".log");
			log.addHandler(fh);
			BriefFormatter formatter = new BriefFormatter();
			fh.setFormatter(formatter);

			log.setLevel(Level.FINE);

			log.log(Level.FINE, "Log file created at " + millis + " (System Time Millis)\n");

		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		// get parameters
		params = _params;

		// store an IDs array with the agents to be k_I, k_T, and k_U at the beginning
		// of the simulation
		// This is done according to the parameters of their k_I, k_T, and k_U
		// distribution

		// this.scrambledAgentIds = new ArrayList<Integer> ();

		// Initialization of the type of strategy counts
		k_I_Agents = new int[params.getMaxSteps()];
		k_T_Agents = new int[params.getMaxSteps()];
		k_U_Agents = new int[params.getMaxSteps()];

		strategyChanges = new int[params.getMaxSteps()];

		globalPayoffs = new float[params.getMaxSteps()];

		corrCoef = new float[params.getMaxSteps()];

		// social network initialization from file

		socialNetwork = new GraphStreamer(params.nrAgents, params);
		socialNetwork.setGraph(params);
		
		minPayOff = maxPayOff = (float) -1.;

	}

	// --------------------------- SimState methods --------------------------//

	/**
	 * Sets up the simulation. The first method called when the simulation.
	 */
	public void start() {

		super.start();

		this.MC_RUN++;

		if ((params.getk_I() + params.getk_T() + params.getk_U()) != params.nrAgents) {
			System.err.println("Error with the k_I, k_T, k_U distribution. "
					+ "Check k_I + k_T + k_U is equal to the total number of agents \n");
		}

		final int FIRST_SCHEDULE = 0;
		int scheduleCounter = FIRST_SCHEDULE;

		// at random, create an array with the IDs unsorted.
		// In this way we can randomly distribute the agents are going to be k_I, k_T,
		// and k_U
		// this is done here to change every MC simulation without changing the SN
		// IMPORTANT! IDs of the SN nodes and agents must be the same to avoid BUGS!!

		// init variables for controlling number of agents and payoffs and other summary
		// arrays
		for (int i = 0; i < params.getMaxSteps(); i++) {
			k_I_Agents[i] = k_T_Agents[i] = k_U_Agents[i] = 0;

			strategyChanges[i] = 0;

			globalPayoffs[i] = (float) 0.;

			corrCoef[i] = (float) 0.;
		}

		// calculate max and min payoff values to normalize update rule
		this.minPayOff = -1 * params.getTv();
		this.maxPayOff = (float) socialNetwork.getAvgDegree() * params.getR_U() * params.getTv();

		// System.out.println("min is " + minPayOff + " and max is " + maxPayOff);

		// Initialization of the agents
		agents = new Bag();

		for (int i = 0; i < params.getNrAgents(); i++) {

			// get a random value from the scrambled IDs data structure and remove it

			/*
			 * int randomPos = this.random.nextInt(this.scrambledAgentIds.size()); int
			 * idAgent = this.scrambledAgentIds.get(randomPos);
			 * this.scrambledAgentIds.remove(randomPos);
			 */

			// System.out.print(idAgent + ";");

			byte strategy = ModelParameters.UNDEFINED_STRATEGY;

			if (i < params.k_I) {
				// we need to add it as k_I strategy
				strategy = ModelParameters.TRUSTER;

			} else if (i < (params.k_I + params.k_T)) {
				// it is a k_T strategy
				strategy = ModelParameters.TRUSTWORTHY_TRUSTEE;

			} else if (i < (params.k_I + params.k_T + params.k_U)) {

				// it is a k_U strategy
				strategy = ModelParameters.UNTRUSTWORTHY_TRUSTEE;
			}

			// generate the agent, push in the bag, and schedule
			GamerAgent cl = generateAgent(i, strategy);

			// Add agent to the list and schedule
			agents.add(cl);

			// Add agent to the schedule
			schedule.scheduleRepeating(Schedule.EPOCH, scheduleCounter, cl);

		}

		// shuffle agents in the Bag and later, reassign the id to the position in the
		// bag
		agents.shuffle(this.random);
		for (int i = 0; i < agents.size(); i++) {
			// System.out.print("agent with id " + ((GamerAgent)
			// agents.get(i)).getGamerAgentId());
			((GamerAgent) agents.get(i)).setGamerAgentId(i);
			// System.out.println(" changed to id " + ((GamerAgent)
			// agents.get(i)).getGamerAgentId());
		}

		if (Model.SHOW_SN) {
			// to visualize the social network
			this.testShowSN();
		}

		// in case we want to calculate spatial correlation and it is not a regular network
		if ( (this.MC_RUN == 0) && (ModelParameters.CALCULATE_SPATIAL_CORR) && (params.typeOfNetwork != GraphStreamer.NetworkType.REGULAR_NETWORK) ) {
			
			// calculate distances between nodes
			SpatialCorrelationSN.calculateShortestDistances(agents, socialNetwork.getGraph());
			
			System.out.println("Finished calculating shortest distances in the SN.");
			
		}
								
		// Add anonymous agent to calculate statistics
		setAnonymousAgentApriori(scheduleCounter);
		scheduleCounter++;

		setAnonymousAgentAposteriori(scheduleCounter);

	}

	// TESTING PURPOSES!! TO SHOW THE SOCIAL NETWORK
	private void testShowSN() {

		String stylesheet = "graph { " + "  fill-color: rgb(255,255,255);" + "  padding: 50px;" + "}" + "node { "
				+ "  size: 12px;" + "  fill-mode: dyn-plain;"
				+ "  fill-color: red,green,blue,yellow,orange,pink,purple;" + "}" + "node .membrane {" + "  size: 25px;"
				+ "}" + "edge {" + "fill-color: grey;" + "}" + "edge.important {" + "fill-color: red;" + "}"
				+ "edge.reset {" + "fill-color: grey;" + "}";

		getSocialNetwork().getGraph().addAttribute("ui.stylesheet", stylesheet);

		Colors colorPalette = new Colors(6);
		getSocialNetwork().getGraph().addAttribute("ui.default.title", "MC " + this.MC_RUN + ", seed: " + this.seed());

		for (Node node : getSocialNetwork().getGraph()) {

			node.setAttribute("size", "medium");
			node.addAttribute("ui.label", node.getId());
		}

		System.out.print("Trusters: ");
		for (int i = 0; i < agents.size(); i++) {
			if (((GamerAgent) agents.get(i)).getCurrentStrategy() == ModelParameters.TRUSTER) {
				System.out.print(((GamerAgent) agents.get(i)).getGamerAgentId() + ",");
				getSocialNetwork().setNodeColor(i, 1, colorPalette);

			}
		}
		System.out.println("");
		System.out.print("Trustworthies: ");
		for (int i = 0; i < agents.size(); i++) {
			if (((GamerAgent) agents.get(i)).getCurrentStrategy() == ModelParameters.TRUSTWORTHY_TRUSTEE) {
				System.out.print(((GamerAgent) agents.get(i)).getGamerAgentId() + ",");
				getSocialNetwork().setNodeColor(i, 2, colorPalette);
			}
		}
		System.out.println("");
		System.out.print("Untrustworthies: ");
		for (int i = 0; i < agents.size(); i++) {
			if (((GamerAgent) agents.get(i)).getCurrentStrategy() == ModelParameters.UNTRUSTWORTHY_TRUSTEE) {
				System.out.print(((GamerAgent) agents.get(i)).getGamerAgentId() + ",");
				getSocialNetwork().setNodeColor(i, 3, colorPalette);
			}
		}
		System.out.println("");

		this.socialNetwork.getGraph().display();

	}

	// TESTING PURPOSES!! TO SHOW THE SOCIAL NETWORK
	private void updateSN() {

		Colors colorPalette = new Colors(6);

		for (int i = 0; i < agents.size(); i++) {
			if (((GamerAgent) agents.get(i)).getCurrentStrategy() == ModelParameters.TRUSTER) {
				getSocialNetwork().setNodeColor(i, 1, colorPalette);

			}
		}
		for (int i = 0; i < agents.size(); i++) {
			if (((GamerAgent) agents.get(i)).getCurrentStrategy() == ModelParameters.TRUSTWORTHY_TRUSTEE) {
				getSocialNetwork().setNodeColor(i, 2, colorPalette);
			}
		}
		for (int i = 0; i < agents.size(); i++) {
			if (((GamerAgent) agents.get(i)).getCurrentStrategy() == ModelParameters.UNTRUSTWORTHY_TRUSTEE) {
				getSocialNetwork().setNodeColor(i, 3, colorPalette);
			}
		}
	}

	// -------------------------- Auxiliary methods --------------------------//

	/**
	 * Generates the agent with its initial strategy, id, probability to act and its
	 * computed activity array (from the latter probability). This is important as
	 * we can save time not to ask at each step if the agent is active or not
	 * 
	 * @param _nodeId   is the id of the agent
	 * @param _strategy is the type of strategy the agent is going to follow
	 * @return the agent created by the method
	 */
	private GamerAgent generateAgent(int _nodeId, byte _strategy) {

		GamerAgent cl = new GamerAgent(_nodeId, _strategy, this.params.maxSteps, this.params.T_rounds);

		// double probToAct = this.random.nextDouble();
		// cl.setProbabilityToAct(probToAct);

		// cl.setProbabilityToAct(1); // Changed. All the agents are always active

		// compute its array of activity
		// boolean active[] = new boolean[this.params.maxSteps];

		// for (int i = 0; i < active.length; i++) {

		// we check if it is active according to its probability
		/*
		 * double r = this.random.nextDouble (true, true);
		 * 
		 * if(r < cl.getProbabilityToAct()) {
		 * 
		 * // the agent is active to cooperate at this step
		 * 
		 * active[i] = true;
		 * 
		 * } else {
		 * 
		 * // it is not active to cooperate active[i] = false; }
		 */
		// }

		// save it to the agent's field
		// cl.setActiveArray(active);

		/*
		 * System.out.println("--> IDAgent " + _nodeId + " with " +
		 * this.socialNetwork.getNeighborsOfNode(_nodeId).size() + " neighbors.");
		 */

		return cl;
	}

	/**
	 * This function calculates the global wealth of the population for the current
	 * step and it is called when finishing the steps. It counts the number of k_I,
	 * k_T, and k_U of the whole population (without taking into account the SN) and
	 * apply the utility matrix.
	 * 
	 * Also, this function updates the individual payoffs for each agent depending
	 * on its strategy
	 * 
	 * @return the global payoff of this step
	 * 
	 */
	private double calculatePayoffWithNeighborsGlobally() {

		// we use k_I_Agents[currentStep], k_T_Agents[currentStep] and
		// k_U_Agents[currentStep]
		// for the already calculated count of agents' strategies

		// Iterate over all the agents to update their payoff from the utility matrix
		// and add to the global netwealth

		int currentStep = (int) schedule.getSteps();

		float tv = this.getParametersObject().getTv();
		float R_T = this.getParametersObject().getR_T();
		float R_U = this.getParametersObject().getR_U();

		float denom = (k_T_Agents[currentStep] + k_U_Agents[currentStep]);

		float agentWealth;

		this.globalPayoffs[currentStep] = (float) 0.;

		for (int i = 0; i < params.nrAgents; i++) {

			agentWealth = (float) 0.;

			// in case there is not any trustee then wealth is 0 potato
			if (denom > 0) {

				// check if this agent is a trustee
				switch (((GamerAgent) agents.get(i)).getCurrentStrategy()) {

				case ModelParameters.TRUSTER:

					// it is a truster so we apply its utility function: tv * (R_T * (k_T/k_TU) - 1)

					agentWealth = tv * ((R_T * (float) (k_T_Agents[currentStep] / denom)) - 1);

					break;

				case ModelParameters.TRUSTWORTHY_TRUSTEE:

					// it is a trustworthy so we apply its utility function: R_T * tv * (k_I/k_TU)

					agentWealth = R_T * tv * (float) (k_I_Agents[currentStep] / denom);

					break;

				case ModelParameters.UNTRUSTWORTHY_TRUSTEE:

					// it is a untrustworthy so we apply its utility function: R_U * tv *
					// (k_I/k_TU). I.e., R_U = (1 + r_{UT})*R_T

					agentWealth = R_U * tv * (float) (k_I_Agents[currentStep] / denom);

					break;

				default:
					System.err.println("Fatal Error!! There are agent with an unknown strategy different "
							+ "from truster and trust/untrust trustworthies.\n");

					break;
				}

			} else {

				// Model.log.log(Level.FINE, " No trustees to perform a transaction. Therefore,
				// wealth of this step is 0\n");
			}

			// save it to the agent's array
			((GamerAgent) agents.get(i)).setCurrentPayoff(agentWealth);

			// store the payoff of this step in the evolution if needed
			if (ModelParameters.CALCULATE_SPATIO_TEMPORAL_CORR) {
				((GamerAgent) agents.get(i)).setEvolutionPayoffAtStep(agentWealth, currentStep);
			}

			// add to the global payoff of the population
			globalPayoffs[currentStep] += agentWealth;

		}

		return globalPayoffs[currentStep];
	}

	/**
	 * Adds the anonymous agent to schedule (at the beginning of each step), which
	 * calculates the statistics.
	 * 
	 * @param scheduleCounter
	 */
	private void setAnonymousAgentApriori(int scheduleCounter) {

		// Add to the schedule at the end of each step
		schedule.scheduleRepeating(Schedule.EPOCH, scheduleCounter, new Steppable() {
			/**
			 * 
			 */
			private static final long serialVersionUID = -2837885990121299044L;

			public void step(SimState state) {

				// reseting colours when showing the SN
				if (Model.SHOW_SN) {

					// reset all the edges colors
					for (Edge e : getSocialNetwork().getGraph().getEachEdge()) {
						e.setAttribute("ui.class", "reset");
					}
				}

				// log.log(Level.FINE, "Step " + schedule.getSteps() + "\n");
			}
		});

	}

	/**
	 * Adds the anonymous agent to schedule (at the end of each step), which
	 * calculates the statistics.
	 * 
	 * @param scheduleCounter
	 */
	private void setAnonymousAgentAposteriori(int scheduleCounter) {

		// Add to the schedule at the end of each step
		schedule.scheduleRepeating(Schedule.EPOCH, scheduleCounter, new Steppable() {

			private static final long serialVersionUID = 3078492735754898981L;

			public void step(SimState state) {

				int currentStep = (int) schedule.getSteps();

				// System.out.println("\n****Step " + currentStep);

				k_I_Agents[currentStep] = k_T_Agents[currentStep] = k_U_Agents[currentStep] = 0;
				strategyChanges[currentStep] = 0;

				for (int i = 0; i < params.nrAgents; i++) {

					if (((GamerAgent) agents.get(i)).getCurrentStrategy() == ModelParameters.TRUSTER) {
						k_I_Agents[currentStep]++;
					}

					if (((GamerAgent) agents.get(i)).getCurrentStrategy() == ModelParameters.TRUSTWORTHY_TRUSTEE) {
						k_T_Agents[currentStep]++;
					}

					if (((GamerAgent) agents.get(i)).getCurrentStrategy() == ModelParameters.UNTRUSTWORTHY_TRUSTEE) {
						k_U_Agents[currentStep]++;
					}

					if (((GamerAgent) agents.get(i)).hasChangedStrategyAtStep(currentStep)) {
						strategyChanges[currentStep]++;
					}

				}

				// update the payoffs

				globalPayoffs[currentStep] = (float) 0.;

				// we decide whether to apply a well-mixed population (no SN to calculate
				// payoffs so
				// they are calculated locally) or locally by the SN structure

				if (params.typeOfNetwork == GraphStreamer.NetworkType.WELL_MIXED_POP) {

					// calculate global payoffs and assign the payoff for all the agents of the pop
					calculatePayoffWithNeighborsGlobally();

				} else {

					// locally assign payoff

					for (int i = 0; i < params.nrAgents; i++) {

						globalPayoffs[currentStep] += ((GamerAgent) agents.get(i)).calculatePayoffWithNeighbors(state);

						// update previous payoff and strategies values

						((GamerAgent) agents.get(i)).setPreviousPayoff(((GamerAgent) agents.get(i)).getCurrentPayoff());
						((GamerAgent) agents.get(i))
								.setPreviousStrategy(((GamerAgent) agents.get(i)).getCurrentStrategy());

					}
				}

				// show the result of the last step in the console
				if (currentStep == (params.getMaxSteps() - 1))
					log.log(Level.FINE,
							"Final step;wealth;" + globalPayoffs[currentStep] + ";k_I;" + k_I_Agents[currentStep]
									+ ";k_T;" + k_T_Agents[currentStep] + ";k_U;" + k_U_Agents[currentStep]
									+ ";strategyChanges;" + strategyChanges[currentStep] + "\n");

				// when showing the social network, we have an update and sleep time to see
				// changes
				if (Model.SHOW_SN) {

					updateSN();

					try {

						Thread.sleep(10);

					} catch (InterruptedException e) {

						e.printStackTrace();
					}
				}

				// plotting and saving additional output information for analysis
				plotSaveAdditionalInfo(currentStep);

			}
		});

	}

	/**
	 * This method wraps all the processes of saving and plotting additional
	 * information to study the dynamics of the simulation (e.g., SN, correlation
	 * between agents, or spatial/temporal correlations in the output)
	 * 
	 * Depending if the static variables of Model (SHOW_SN, OUTPUT_LATTICE,
	 * CALCULATE_SPATIO_TEMP_CORR etc...) are activated or not, the function will do
	 * and save all the required information
	 * 
	 * @param _currentStep is the step of the simulation
	 * 
	 */

	protected void plotSaveAdditionalInfo(int _currentStep) {

		// FIXED PICTURE OF THE LATTICE & FRACTAL CALCULATION:
		// 1) plot the regular lattice of the steps that satisfy the condition in a 2D
		// image
		// there is no need for saving all the MC runs and just for the last step of the
		// simulation
		// 2) also calculate
		if (ModelParameters.OUTPUT_LATTICE_FRACTAL && (_currentStep == (params.maxSteps - 1))) {

			// init matrix
			int n = Math.round((float) Math.sqrt(socialNetwork.getGraph().getNodeCount()));
			int matrixLattice[][] = new int[n][n];

			for (int i = 0; i < n; i++)
				for (int j = 0; j < n; j++)
					matrixLattice[i][j] = -1;

			// get all the agents and find out the position of their associated nodes to set
			// the strategy

			for (int i = 0; i < params.nrAgents; i++) {

				int currStrategy = ((GamerAgent) agents.get(i)).getCurrentStrategy();
				int idNode = ((GamerAgent) agents.get(i)).getGamerAgentId();

				double pos[] = new double[3];
				GraphPosLengthUtils.nodePosition(socialNetwork.getGraph().getNode(idNode), pos);

				matrixLattice[((int) pos[0])][((int) pos[1])] = currStrategy;

			}

			// mass for fractal calculation: calculating if the lattice has a fractal
			// structure or not (= by calculating number of strategies
			// of one type for different boxes)

			int boxSizes[] = new int[n];
			int valuesI[] = new int[n];
			int valuesT[] = new int[n];
			int valuesU[] = new int[n];

			// System.out.println("Number of nodes with strategy " + valueToCount + " in
			// different boxes of the lattice:");

			for (int i = 0; i < n; i++) {
				boxSizes[i] = i + 1;
				valuesI[i] = 0;
				valuesT[i] = 0;
				valuesU[i] = 0;

				for (int k = 0; k < (boxSizes[i]); k++)
					for (int l = 0; l < (boxSizes[i]); l++) {

						if (matrixLattice[k][l] == ModelParameters.TRUSTER)
							valuesI[i]++;

						if (matrixLattice[k][l] == ModelParameters.TRUSTWORTHY_TRUSTEE)
							valuesT[i]++;

						if (matrixLattice[k][l] == ModelParameters.UNTRUSTWORTHY_TRUSTEE)
							valuesU[i]++;
					}

			}

			// save to files (both plots and fractal mass calculation
			try {

				// print the lattice plots into a file for each step
				File file = new File("./logs/plotsLattice/" + "2Dlattice_" + params.getOutputFile() + "_" + _currentStep
						+ "." + this.MC_RUN + ".txt");
				PrintWriter printWriter = new PrintWriter(file);

				String toPrint = "";
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < (n - 1); j++) {
						toPrint = toPrint + matrixLattice[i][j] + ",";
					}
					toPrint = toPrint + matrixLattice[i][(n - 1)] + "\n";
				}
				toPrint = toPrint + "\n";

				printWriter.print(toPrint);
				printWriter.close();

				// print the fractal mass calculation in a file
				file = new File(
						"./logs/fractal/" + "MassFractal_" + params.getOutputFile() + "." + this.MC_RUN + ".txt");
				printWriter = new PrintWriter(file);

				printWriter.write("step;boxSize;#TrustersInBox;#TrustworthiesInBox;#UntrustworthiesInBox;\n");

				for (int i = 0; i < n; i++) {
					printWriter.write(_currentStep + ";" + boxSizes[i] + ";" + valuesI[i] + ";" + valuesT[i] + ";"
							+ valuesU[i] + ";" + "\n");
				}

				printWriter.close();

			} catch (FileNotFoundException e) {

				e.printStackTrace();

				log.log(Level.SEVERE, e.toString(), e);
			}

		}

		// SPATIAL CORRELATION COEFFICIENT: Saving into a file the correlation
		// coefficients between agents at all possible
		// distances in a lattice for 3 timesteps (static picture of the simulation, not
		// a temporal evolution)
		if ((ModelParameters.CALCULATE_SPATIAL_CORR) && (_currentStep == (params.maxSteps - 1))) {

			// calculate G(l) for a given distance l within the regular lattice

			try {

				// save
				File fileCorrCoef = new File("./logs/spatial-corr-coef/" + "CorrCoef_" + params.getOutputFile() + "."
						+ this.MC_RUN + ".txt");
				PrintWriter printWriter = new PrintWriter(fileCorrCoef);

				printWriter.write("step;l;payoffs;strategy;\n");
								
				for (int l = 1; l < (Math.round((float) Math.sqrt(params.nrAgents) / 2) + 1); l++) {

					if (params.typeOfNetwork == GraphStreamer.NetworkType.REGULAR_NETWORK) {

						// set class for calculating spatio temporal correlations for the given distance
						// 'l'
						SpatialCorrelationSN.setParameters(agents, socialNetwork.getGraph(), l);
					} 					

					printWriter.write(_currentStep + ";");

					// calculate difference w.r.t. payoffs for the given l (payoffs)

					if (params.typeOfNetwork == GraphStreamer.NetworkType.REGULAR_NETWORK) {

						corrCoef[_currentStep] = SpatialCorrelationSN.calcSpatialCorrFromLatticeMatrix(true);

					} else {

						corrCoef[_currentStep] = SpatialCorrelationSN.calcSpatialCorrFromSN(agents, l, true);
					}

					printWriter.write(l + ";" + corrCoef[_currentStep] + ";");

					// calculate difference w.r.t. payoffs for the given l (strategy)

					if (params.typeOfNetwork == GraphStreamer.NetworkType.REGULAR_NETWORK) {

						corrCoef[_currentStep] = SpatialCorrelationSN.calcSpatialCorrFromLatticeMatrix(false);

					} else {

						corrCoef[_currentStep] = SpatialCorrelationSN.calcSpatialCorrFromSN(agents, l, false);

					}

					printWriter.write(corrCoef[_currentStep] + ";\n");

				}

				printWriter.close();

			} catch (FileNotFoundException e) {

				e.printStackTrace();
				log.log(Level.SEVERE, e.toString(), e);
			}

		}

		// ALL EVOLUTION: This information is for saving in a file all the evolution of
		// the sim steps to analyze
		// the evolution as a signal (FFT for instance)
		if ((ModelParameters.OUTPUT_WHOLE_EVOLUTION) && (_currentStep == (params.maxSteps - 1))) {

			try {

				// save
				File fileCorrCoef = new File("./logs/evolution_FFT/" + "WholeEvolution_" + params.getOutputFile() + "."
						+ this.MC_RUN + ".txt");
				PrintWriter printWriter = new PrintWriter(fileCorrCoef);

				printWriter.write("step;netWealth;k_I;k_T;k_U;strategyChanges;\n");

				// loop for all the steps
				for (int k = 0; k < (params.maxSteps - 1); k++) {

					// print all info of the step
					printWriter.write(k + ";" + this.globalPayoffs[k] + ";" + this.k_I_Agents[k] + ";"
							+ this.k_T_Agents[k] + ";" + this.k_U_Agents[k] + ";" + this.strategyChanges[k] + ";\n");

				}

				printWriter.close();

			} catch (FileNotFoundException e) {

				e.printStackTrace();
				log.log(Level.SEVERE, e.toString(), e);
			}

		}

		// SPATIO-TEMPORAL CORRELATION: This information is for saving in a file the
		// spatial correlations of an agent
		// with some agents at several distances in the SN for the whole simulation (it
		// is saved just one time in the last step)
		if ((ModelParameters.CALCULATE_SPATIO_TEMPORAL_CORR) && (_currentStep == (params.maxSteps - 1))) {

			// we have to get one node at random and some neighbors of it also at random at
			// different distances
			// after choosing them, we output their evolution in payoffs and strategies

			// set class for calculating matrix of the lattice
			SpatialCorrelationSN.setParameters(agents, socialNetwork.getGraph(), 2);

			// position 3,5 of the lattice
			int _x = 5;
			int _y = 7;
			int idNode = SpatialCorrelationSN.getRandomNeighborAtDistance(_x, _y, 0);
			// System.out.println("distance 0 " + idNode);
			GamerAgent gamerAgent = (GamerAgent) agents.get(idNode);

			// select neighbor at distance l=2
			int idNode_2 = SpatialCorrelationSN.getRandomNeighborAtDistance(_x, _y, 2);
			GamerAgent gamerAgent_2 = (GamerAgent) agents.get(idNode_2);
			// System.out.println("distance 2 " + idNode_2);

			// select neighbor at distance l=4
			int idNode_4 = SpatialCorrelationSN.getRandomNeighborAtDistance(_x, _y, 4);
			GamerAgent gamerAgent_4 = (GamerAgent) agents.get(idNode_4);
			// System.out.println("distance 4 " + idNode_4);

			// select neighbor at distance l=6
			int idNode_6 = SpatialCorrelationSN.getRandomNeighborAtDistance(_x, _y, 6);
			GamerAgent gamerAgent_6 = (GamerAgent) agents.get(idNode_6);
			// System.out.println("distance 6 " + idNode_6);

			// select neighbor at distance l=10
			int idNode_10 = SpatialCorrelationSN.getRandomNeighborAtDistance(_x, _y, 10);
			GamerAgent gamerAgent_10 = (GamerAgent) agents.get(idNode_10);
			// System.out.println("distance 10 " + idNode_10);

			try {

				// save into a file for each MC run
				File fileCorrCoef = new File("./logs/spatio-temporal/" + "EvAgentsAtDistance_" + params.getOutputFile()
						+ "." + this.MC_RUN + ".txt");
				PrintWriter printWriter = new PrintWriter(fileCorrCoef);

				printWriter.write("step;Str-A;Payoff-A;Str-A_2;Payoff-A_2;"
						+ "Str-A_4;Payoff-A_4;Str-A_6;Payoff-A_6;Str-A_10;Payoff-A_10;\n");

				for (int s = 0; s < (params.maxSteps - 1); s++) {

					printWriter.write(s + ";");

					printWriter.write(
							gamerAgent.getEvolutionStrategies(s) + ";" + gamerAgent.getEvolutionPayoffAtStep(s) + ";");
					printWriter.write(gamerAgent_2.getEvolutionStrategies(s) + ";"
							+ gamerAgent_2.getEvolutionPayoffAtStep(s) + ";");
					printWriter.write(gamerAgent_4.getEvolutionStrategies(s) + ";"
							+ gamerAgent_4.getEvolutionPayoffAtStep(s) + ";");
					printWriter.write(gamerAgent_6.getEvolutionStrategies(s) + ";"
							+ gamerAgent_6.getEvolutionPayoffAtStep(s) + ";");
					printWriter.write(gamerAgent_10.getEvolutionStrategies(s) + ";"
							+ gamerAgent_10.getEvolutionPayoffAtStep(s) + ";");

					printWriter.write("\n");

				}

				printWriter.close();

			} catch (FileNotFoundException e) {

				e.printStackTrace();
				log.log(Level.SEVERE, e.toString(), e);
			}
		}

	}

	// ----------------------------- I/O methods -----------------------------//

	/**
	 * Prints simple statistics evolution during the time.
	 */
	public void printStatisticsScreen() {

		GamerAgent gamerAgent;

		int allk_I, allk_T, allk_U;
		int tmp;

		allk_I = allk_T = allk_U = 0;

		for (int i = 0; i < params.nrAgents; i++) {

			gamerAgent = (GamerAgent) agents.get(i);
			tmp = gamerAgent.getCurrentStrategy();

			if (tmp == ModelParameters.TRUSTER)
				allk_I++;

			if (tmp == ModelParameters.TRUSTWORTHY_TRUSTEE)
				allk_T++;

			if (tmp == ModelParameters.UNTRUSTWORTHY_TRUSTEE)
				allk_U++;

			// obtain avg. degree of the agent
			ArrayList<Integer> neighbors = (ArrayList<Integer>) this.socialNetwork
					.getNeighborsOfNode(gamerAgent.gamerAgentId);

			if (ModelParameters.CALCULATE_SPATIO_TEMPORAL_CORR) {
				// obtain number of strategy changes during the simulation
				byte evolution[] = gamerAgent.getEvolutionStrategies();
				int changes = 0;
				for (int j = 1; j < evolution.length; j++) {
					if (evolution[j] != evolution[j - 1]) {
						// there is a change in the strategy
						changes++;
					}
				}

				System.out.println("A-" + gamerAgent.getGamerAgentId() + ";" + +neighbors.size() + ";" + changes + ";"
						+ evolution[0] + ";" + gamerAgent.getCurrentStrategy());
			} else {

				System.out.println("A-" + gamerAgent.getGamerAgentId() + ";" + +neighbors.size() + ";" + ";"
						+ gamerAgent.getCurrentStrategy());
			}

		}

		// Print it out
		System.out.println();
		System.out.print("k_I;" + allk_I);
		System.out.print(";k_T;" + allk_T);
		System.out.print(";k_U;" + allk_U);
		System.out.println();

	}
}
