package model;

import sim.engine.*;

import java.util.*;

//import java.util.Map.Entry;

/**
 * Class of the players of the N-trust game.
 * 
 * @author mchica
 * @date 2016/04/27
 *
 */

public class GamerAgent implements Steppable {

	// ########################################################################
	// Variables
	// ########################################################################

	// LOGGING
	// private static final Logger log = Logger.getLogger( Model.class.getName() );

	private static final long serialVersionUID = 1L;

	// --------------------------------- Fixed -------------------------------//

	int gamerAgentId; // A unique agent Id

	int maxSteps; // max number of steps of the simulation of the agent

	int T_rounds; // rounds of T steps to update the rule

	int currentStep; // the current step of the simulation

	// ------------------------------- Dynamic -------------------------------//

	float currentPayoff = Float.MIN_VALUE; // payoff obtained by the agent at this step
	float previousPayoff = Float.MIN_VALUE; // payoff obtained by the agent previous step

	byte currentStrategy = ModelParameters.UNDEFINED_STRATEGY; // current strategy used by the agent
	byte previousStrategy = ModelParameters.UNDEFINED_STRATEGY; // strategy used by the agent in the previous step

	float evolutionPayoffs[]; // array with the payoffs obtained at each step (in case we need to store the
						// whole evolution)
	byte evolutionStrategies[]; // array with the evolution in the strategies of the player (in case we need to
								// store the whole evolution)

	// ########################################################################
	// Constructors
	// ########################################################################

	/**
	 * Initializes a new instance of the ClientAgent class.
	 * 
	 * @param _gameId   is the id for the agent
	 * @param _strategy is the strategy used at the beginning of the simulation
	 * @param _prob     the probability to act at each step of the simulation
	 * @param _maxSteps the max steps of the simulation
	 * @param _T_rounds the T rounds to use the update rule
	 * 
	 */
	public GamerAgent(int _gamerId, byte _strategy, int _maxSteps, int _T_rounds) {

		this.gamerAgentId = _gamerId;
		this.currentStrategy = _strategy;
		this.maxSteps = _maxSteps;
		this.T_rounds = _T_rounds;

		// if we want to store the whole evolution of the agents, we reserve memory for it
		if (ModelParameters.CALCULATE_SPATIO_TEMPORAL_CORR) {
			
			this.evolutionStrategies = new byte[maxSteps];
			this.evolutionPayoffs = new float[maxSteps];

			for (int i = 0; i < maxSteps; i++) {
				this.evolutionPayoffs[i] = -1;
				this.evolutionStrategies[i] = -1;
			}			
		}		

	}

	// ########################################################################
	// Methods/Functions
	// ########################################################################

	// --------------------------- Get/Set methods ---------------------------//

	/**
	 * Gets the id of the agent
	 * 
	 * @return
	 */
	public int getGamerAgentId() {
		return gamerAgentId;
	}

	/**
	 * Sets the id of the agent
	 * 
	 * @param gamerAgentId
	 */
	public void setGamerAgentId(int _gamerAgentId) {
		this.gamerAgentId = _gamerAgentId;
	}

	/**
	 * Gets the current payoff of the agent
	 * 
	 * @return - the payoff
	 */
	public float getCurrentPayoff() {
		return this.currentPayoff;
	}

	/**
	 * Sets the current payoff of the agent
	 * 
	 * @param _strategy - the current payoff to be set
	 */
	public void setCurrentPayoff(float _p) {
		this.currentPayoff = _p;
	}

	/**
	 * Gets the previous payoff of the agent
	 * 
	 * @return - the payoff
	 */
	public float getPreviousPayoff() {
		return this.previousPayoff;
	}

	/**
	 * Sets the previous payoff of the agent
	 * 
	 * @param _strategy - the current payoff to be set
	 */
	public void setPreviousPayoff(float _strategy) {
		this.previousPayoff = _strategy;
	}

	/**
	 * Gets the current strategy of the agent
	 * 
	 * @return - the strategy
	 */
	public byte getCurrentStrategy() {
		return this.currentStrategy;
	}

	/**
	 * Sets the strategy status of the agent
	 * 
	 * @param _strategy - the current strategy to be set
	 */
	public void setCurrentStrategy(byte _strategy) {
		this.currentStrategy = _strategy;
	}

	/**
	 * Gets the previous strategy of the agent
	 * 
	 * @return - the strategy
	 */
	public byte getPreviousStrategy() {
		return this.previousStrategy;
	}

	/**
	 * Sets the previous strategy of the agent
	 * 
	 * @param _strategy - the current strategy to be set
	 */
	public void setPreviousStrategy(byte _strategy) {
		this.previousStrategy = _strategy;
	}

	/**
	 * Gets the payoff array
	 */
	public float[] getEvolutionPayoffs() {

		if (!ModelParameters.CALCULATE_SPATIO_TEMPORAL_CORR) {

			System.err.println("GamerAgent.getEvolutionPayoffs(): Fatal error!! We cannot return the payoffs evolution "
					+ "if we don't store it (flag STORE_WHOLE_AGENT_STATUS = false).\n");

			return null;

		} else {

			return evolutionPayoffs;
		}
	}

	/**
	 * Sets the payoff array
	 * 
	 * @param _payoffs is the array to set
	 */
	public void setEvolutionPayoffs(float[] _payoffs) {

		if (!ModelParameters.CALCULATE_SPATIO_TEMPORAL_CORR) {

			System.err.println("GamerAgent.setEvolutionPayoffs(): Fatal error!! We cannot set the payoffs evolution "
					+ "if we don't store it (flag STORE_WHOLE_AGENT_STATUS = false).\n");

		} else {

			this.evolutionPayoffs = _payoffs;
		}
	}

	/**
	 * Gets the payoff value for a given step
	 */
	public float getEvolutionPayoffAtStep(int _step) {

		if (!ModelParameters.CALCULATE_SPATIO_TEMPORAL_CORR) {

			System.err.println("GamerAgent.getEvolutionPayoffAtStep(int): Fatal error!! We cannot set the payoffs evolution "
					+ "if we don't store it (flag STORE_WHOLE_AGENT_STATUS = false).\n");

			return Float.MIN_VALUE;

		} else {

			return evolutionPayoffs[_step];
		}

	}
	
	/**
	 * Sets a payoff value to a step
	 * 
	 * @param _payoff is the netwealth value
	 * @param _step   is the step for the value
	 */
	public void setEvolutionPayoffAtStep(float _payoff, int _step) {

		if (!ModelParameters.CALCULATE_SPATIO_TEMPORAL_CORR) {

			System.err.println("GamerAgent.setEvolutionPayoffAtStep(float, int): Fatal error!! We cannot set the payoffs evolution "
					+ "if we don't store it (flag STORE_WHOLE_AGENT_STATUS = false).\n");

		} else {

			this.evolutionPayoffs[_step] = _payoff;
		}

	}
	
	/**
	 * Adds a payoff value to a step but without removing the previous value (i.e.,
	 * adding it to a previous value)
	 * 
	 * @param _addPayoff is the netwealth value
	 * @param _step      is the step for the value
	 */
	public void addEvolutionPayoff(float _addPayoff, int _step) {
		if (!ModelParameters.CALCULATE_SPATIO_TEMPORAL_CORR) {

			System.err.println("GamerAgent.addEvolutionPayoff(int): Fatal error!! We cannot set the payoffs evolution "
					+ "if we don't store it (flag STORE_WHOLE_AGENT_STATUS = false).\n");

		} else {

			this.evolutionPayoffs[_step] += _addPayoff;
		}
	}

	/**
	 * Gets the array with the changing strategies
	 */
	public byte[] getEvolutionStrategies() {

		if (!ModelParameters.CALCULATE_SPATIO_TEMPORAL_CORR) {

			System.err.println(
					"GamerAgent.getEvolutionStrategies(): Fatal error!! We cannot get the strategies evolution "
							+ "if we don't store it (flag STORE_WHOLE_AGENT_STATUS = false).\n");

			return null;

		} else {

			return evolutionStrategies;
		}

	}

	/**
	 * Returns true if the agent has changed its strategy this step. False if it has
	 * the same
	 */
	public boolean hasChangedStrategyAtStep(int _step) {

		if ((_step > 0) && (this.getCurrentStrategy() != this.getPreviousStrategy()) )
			return true;
		else
			return false;
		
	}

	/**
	 * Gets the value of the strategy for a current step
	 */
	public byte getEvolutionStrategies(int _step) {

		if (!ModelParameters.CALCULATE_SPATIO_TEMPORAL_CORR) {

			System.err.println(
					"GamerAgent.getEvolutionStrategies(int): Fatal error!! We cannot get the strategies evolution "
							+ "if we don't store it (flag STORE_WHOLE_AGENT_STATUS = false).\n");

			return Byte.MIN_VALUE;

		} else {

			return evolutionStrategies[_step];
		}
	}

	/**
	 * Sets the array with the evolution in the strategy changes
	 * 
	 * @param _evolutionStrategies is the new array
	 */
	public void setEvolutionStrategies(byte[] _evolutionStrategies) {
		if (!ModelParameters.CALCULATE_SPATIO_TEMPORAL_CORR) {

			System.err.println(
					"GamerAgent.getEvolutionStrategies(int): Fatal error!! We cannot get the strategies evolution "
							+ "if we don't store it (flag STORE_WHOLE_AGENT_STATUS = false).\n");

		} else {

			this.evolutionStrategies = _evolutionStrategies;
		}
	}

	// -------------------------- Cooperation methods --------------------------//

	/**
	 * This function is called to calculate the payoffs of the play of the agent
	 * within its local neighbourhood of the SN. The payoff is calculated following
	 * the formulae of the n-trust game.
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return the payoff of the agent in this step
	 */
	public double calculatePayoffWithNeighbors(SimState state) {

		Model model = (Model) state;

		ArrayList<Integer> neighbors = (ArrayList<Integer>) model.socialNetwork.getNeighborsOfNode(this.gamerAgentId);

		// Iterate over neighbors

		int noOfk_I = 0;
		int noOfk_T = 0;
		int noOfk_U = 0;

		for (int i = 0; i < neighbors.size(); i++) {

			GamerAgent neighbor = (GamerAgent) (model.getAgents()).get(neighbors.get(i));

			// check if the i-th neighbor is active and then count it
			// if (neighbor.isActive(this.currentStep)) {

			if (neighbor.getCurrentStrategy() == ModelParameters.TRUSTER) {
				noOfk_I++;

			} else if (neighbor.getCurrentStrategy() == ModelParameters.TRUSTWORTHY_TRUSTEE) {
				noOfk_T++;

			} else if (neighbor.getCurrentStrategy() == ModelParameters.UNTRUSTWORTHY_TRUSTEE) {
				noOfk_U++;
			}

			// }
		}

		if (this.getCurrentStrategy() == ModelParameters.TRUSTER) {
			noOfk_I++;

		} else if (this.getCurrentStrategy() == ModelParameters.TRUSTWORTHY_TRUSTEE) {
			noOfk_T++;

		} else if (this.getCurrentStrategy() == ModelParameters.UNTRUSTWORTHY_TRUSTEE) {
			noOfk_U++;
		}

		// setting the payoff to the agent according to the utility matrix
		this.currentPayoff = (float) 0.;

		float denom = noOfk_T + noOfk_U;

		if (denom > 0) {

			float tv = model.getParametersObject().getTv();
			float R_T = model.getParametersObject().getR_T();
			float R_U = model.getParametersObject().getR_U();

			// check if this agent is a trustee
			switch (this.getCurrentStrategy()) {

			case ModelParameters.TRUSTER:

				// it is a truster so we apply its utility function: tv * (R_T * (kT/(kTU))- 1)

				this.currentPayoff = tv * ((R_T * (float) (noOfk_T / denom)) - 1);

				break;

			case ModelParameters.TRUSTWORTHY_TRUSTEE:

				// it is a trustworthy so we apply its utility function: R_T * tv * (kI/(kTU))

				this.currentPayoff = R_T * tv * (float) (noOfk_I / denom);

				break;

			case ModelParameters.UNTRUSTWORTHY_TRUSTEE:

				// it is a untrustworthy so we apply its utility function: R_U * tv * (kI/(kTU))

				this.currentPayoff = R_U * tv * (float) (noOfk_I / denom);

				break;

			default:
				System.err.println("Fatal Error!! There is an agent with an unknown strategy different "
						+ "from truster and trust/untrust trustworthies: " + this.getCurrentStrategy() + "\n");

				break;
			}

		}

		/*
		 * System.out.println("A-" + this.gamerAgentId + " was " +
		 * this.getCurrentStratey() + ", payoff: " + this.currentPayoff);
		 */

		// store the payoff of this step in the evolution if needed
		if (ModelParameters.CALCULATE_SPATIO_TEMPORAL_CORR) {
			this.evolutionPayoffs[currentStep] = this.currentPayoff;
		}

		return this.currentPayoff;
	}

	/**
	 * With this function we update the strategy using the voter model strategy
	 * 
	 * This method is as simple as selecting one neighbor at random
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return true if the agent has changed its strategy w.r.t. its previous
	 *         strategy
	 */
	private boolean voterModel(SimState state) {

		Model model = (Model) state;

		ArrayList<Integer> neighbors = (ArrayList<Integer>) model.socialNetwork.getNeighborsOfNode(this.gamerAgentId);

		// first check if the agent has neighbors

		if (neighbors.size() > 0) {

			// this j neighbor is the one to imitate by the focal agent
			int j = model.random.nextInt(neighbors.size());
			GamerAgent neighbor = (GamerAgent) (model.getAgents()).get(neighbors.get(j));

			// change the strategy by the one of the randomly selected neighbor
			this.setCurrentStrategy(neighbor.getPreviousStrategy());

			// TESTING VISUALIZATION IN THE SOCIAL NETWORK
			if (Model.SHOW_SN) {
				model.getSocialNetwork().setAttributeEdge(neighbor.getGamerAgentId(), this.gamerAgentId, "ui.class",
						"important");
			}

			return true;
		}

		return false;
	}

	/**
	 * With this function we update the strategy using the Fermi distribution
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return true if the agent has changed its strategy w.r.t. its previous
	 *         strategy
	 */
	private boolean fermiRule(SimState state) {

		Model model = (Model) state;

		ArrayList<Integer> neighbors = (ArrayList<Integer>) model.socialNetwork.getNeighborsOfNode(this.gamerAgentId);

		// first check if the agent has neighbors

		if (neighbors.size() > 0) {

			// get one neighbor at random
			int j = model.random.nextInt(neighbors.size());
			GamerAgent neighbor = (GamerAgent) (model.getAgents()).get(neighbors.get(j));

			double neighPayOff = 0.;
			double focalAgentPayOff = 0.;

			neighPayOff = neighbor.getPreviousPayoff();
			focalAgentPayOff = this.getPreviousPayoff();

			// calculate the prob using the Fermi distribution and payoffs' difference

			double beta = 1; // TODO Temporal value beta to 1 (minimum noise)

			double prob = 1.0 / (1 + Math.exp(-1 * beta * (neighPayOff - focalAgentPayOff)));

			// Check if the agent adopts the neighbor's strategy

			double r = model.random.nextDouble(true, true);

			if (r < prob) {

				// change the strategy!
				this.setCurrentStrategy(neighbor.getPreviousStrategy());

				return true;
			}
		}

		return false;
	}

	/**
	 * With this function we update the strategy using the Moran rule This rule
	 * consists of selecting one neighbor (including the focal agent) with a
	 * probability given by its payoff. Then, imitate the strategy of this agent
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return true if the agent has changed its strategy w.r.t. its previous
	 *         strategy
	 */
	private boolean moranRule(SimState state) {

		Model model = (Model) state;

		ArrayList<Integer> neighbors = (ArrayList<Integer>) model.socialNetwork.getNeighborsOfNode(this.gamerAgentId);

		// first check if the agent has neighbors

		if (neighbors.size() > 0) {

			double acc = 0;
			int selectedNeighbor = -1;

			double listFitness[] = new double[neighbors.size() + 1];

			for (int i = 0; i < neighbors.size(); i++) {
				GamerAgent neighbor = (GamerAgent) (model.getAgents()).get(neighbors.get(i));

				// obtain the payoff of this neighbor and add its 'fitness' to a hash map
				double fitness = neighbor.getPreviousPayoff() - model.minPayOff;

				// add the acc fitness to this neighbor
				acc += fitness;
				listFitness[i] = acc;

				// System.out.println("neighbor " + i + " has payoff of " + fitness + ". acc is
				// " + listFitness[i]);
			}

			// do the same for the focal agent itself (it will be the 'size' index)
			double fitness = this.getPreviousPayoff() - model.minPayOff;
			acc += fitness;
			listFitness[neighbors.size()] = acc;

			// System.out.println("focal agent has payoff of " + fitness + ". acc is " +
			// listFitness[neighbors.size()]);

			// divide all values by acc value
			for (int i = 0; i < listFitness.length; i++) {
				listFitness[i] /= acc;

				// System.out.println(i + " ==== " + listFitness[i]);
			}

			// now, get a random number and choose one among them using the wheel roulette

			double r = model.random.nextDouble(true, true);

			for (int i = 0; i < listFitness.length; i++) {

				// System.out.println("r is " + r + " and next threshold is " + listFitness[i]
				// );

				// check if the random number is below the normalized fitness of the i-th
				// element
				if (r < listFitness[i]) {
					// it is, so this is the agent to imitate

					selectedNeighbor = i;
					// System.out.println(selectedNeighbor + " is selected");

					break;
				}
			}

			if (selectedNeighbor == neighbors.size()) {

				// it means, it is the same, no change
				return false;

			} else {

				// change the strategy!
				this.setCurrentStrategy(((GamerAgent) (model.getAgents()).get(neighbors.get(selectedNeighbor)))
						.getPreviousStrategy());

				// Model.log.log(Level.FINE, " Strategy changed!! A-" + this.gamerAgentId + " to
				// strategy " +
				// this.currentStrategy + " by imitating A-" + neighbor.getGamerAgentId() +
				// "\n");

				return true;
			}
		}

		return false;
	}

	/**
	 * With this function we update the strategy using the proportional imitation
	 * rule
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return true if the agent has changed its strategy w.r.t. its previous
	 *         strategy
	 */
	private boolean proportionalImitation(SimState state) {

		Model model = (Model) state;

		ArrayList<Integer> neighbors = (ArrayList<Integer>) model.socialNetwork.getNeighborsOfNode(this.gamerAgentId);

		// first check if the agent has neighbors

		if (neighbors.size() > 0) {

			int j = model.random.nextInt(neighbors.size());
			GamerAgent neighbor = (GamerAgent) (model.getAgents()).get(neighbors.get(j));

			double neighPayOff = 0.;
			double focalAgentPayOff = 0.;

			neighPayOff = neighbor.getPreviousPayoff();
			focalAgentPayOff = this.getPreviousPayoff();

			if (neighPayOff > model.maxPayOff) {
				neighPayOff = model.maxPayOff;
			}

			// compare their payoffs and strategies in the previous step
			if (neighPayOff > focalAgentPayOff) {

				// the neighbor's strategy was better so we try to shift the strategy with a
				// prob.

				double prob = (neighPayOff - focalAgentPayOff) / (model.maxPayOff - model.minPayOff);

				double r = model.random.nextDouble(true, true);

				// Check if the agent adopts the neighbor's strategy
				if (r < prob) {

					// change the strategy!
					this.setCurrentStrategy(neighbor.getPreviousStrategy());

					return true;
				}
			}
		}

		return false;
	}

	/**
	 * With this function we update the strategy using the unconditional imitation
	 * This rule [Novak92] is simple and the focal agents adopts the strategy of the
	 * neighbor with the highest payoff if it is higher than her own. Thus, it is
	 * deterministic and rational choice to maximize the own fitness of the agent by
	 * imitating the most successful one.
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return true if the agent has changed its strategy w.r.t. its previous
	 *         strategy
	 */
	private boolean unconditionalImitation(SimState state) {

		Model model = (Model) state;

		// get the list of neighbors
		ArrayList<Integer> neighbors = (ArrayList<Integer>) model.socialNetwork.getNeighborsOfNode(this.gamerAgentId);

		// first check if the agent has neighbors
		if (neighbors.size() > 0) {

			double payoffBest = -Double.MAX_VALUE;
			byte strategyNeighBest = -1;
			int idNeighBest = -1;

			for (int i = 0; i < neighbors.size(); i++) {

				// get i-th neighbor and update best payoff
				GamerAgent neighbor = (GamerAgent) (model.getAgents()).get(neighbors.get(i));

				if (neighbor.getPreviousPayoff() > payoffBest) {
					payoffBest = neighbor.getPreviousPayoff();
					strategyNeighBest = neighbor.getPreviousStrategy();
					//System.out.println(strategyNeighBest);
					idNeighBest = neighbor.getGamerAgentId();
				}
			}

			// we compare the best payoff of the neighborhood w.r.t. the own payoff to
			// update or not
			if (payoffBest > this.getPreviousPayoff()) {

				/*
				 * if (this.getCurrentStratey() != strategyNeighBest) {
				 * System.out.println("**** A-" + this.gamerAgentId + " with " +
				 * neighbors.size() + " neighs, copied A-" + idNeighBest + " (" +
				 * this.getCurrentStratey() + "->" + strategyNeighBest +
				 * ") because neigh had payoff of " + payoffBest + " and focal had payoff of " +
				 * this.getPayoff(currentStep - 1)); }
				 */

				this.setCurrentStrategy(strategyNeighBest);

				// TESTING VISUALIZATION IN THE SOCIAL NETWORK
				if (Model.SHOW_SN) {
					model.getSocialNetwork().setAttributeEdge(idNeighBest, this.gamerAgentId, "ui.class", "important");
				}

				// Model.log.log(Level.FINE, " Strategy changed!! A-" + this.gamerAgentId + " to
				// strategy " +
				// this.currentStrategy + " by imitating A-" + neighbor.getGamerAgentId() +
				// "\n");

				return true;
			}
		}

		return false;

	}

	/**
	 * With this function we update the strategy used by the agent. We use the
	 * defined imitative ev. dynamics rule for calculating the change (if there is a
	 * change)
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return true if the agent has changed its strategy w.r.t. its previous
	 *         strategy
	 */
	public boolean updateRuleForStrategy(SimState state) {

		Model model = (Model) state;

		// it does not make sense to do it for the first step

		switch (model.getParametersObject().getUpdateRule()) {

		case ModelParameters.PROPORTIONAL_UPDATE_RULE:

			return this.proportionalImitation(state);

		case ModelParameters.UI_UPDATE_RULE:

			return this.unconditionalImitation(state);

		case ModelParameters.VOTER_UPDATE_RULE:

			// hybrid VM with UI. VM is used with prob q while UI is used with prob 1-q
			// when q is 1, the VM is always used for the agent

			double r = model.random.nextDouble(true, true);

			if (r < model.getParametersObject().getQ_VM()) {
				// System.out.println("Agent-" + this.getGamerAgentId() + ": VM used");
				return this.voterModel(state);
			} else {
				// System.out.println("Agent-" + this.getGamerAgentId() + ": UI used");
				return this.unconditionalImitation(state);
			}

		case ModelParameters.FERMI_UPDATE_RULE:

			return this.fermiRule(state);

		case ModelParameters.MORAN_UPDATE_RULE:

			return this.moranRule(state);

		}

		return false;

	}

	// --------------------------- Steppable method --------------------------//

	/**
	 * Step of the simulation.
	 * 
	 * @param state - a simulation model object (SimState).
	 */

	// @Override
	public void step(SimState state) {

		Model model = (Model) state;

		currentStep = (int) model.schedule.getSteps();

		// if we have one step at least, we save current payoff and strategy as previous
		// values
		if (currentStep > 0) {
			
			int T_rounds = model.getParametersObject().getT_rounds();

			// check if T rounds has passed to update its rule too
			if ((currentStep % T_rounds) == 0) {
				this.updateRuleForStrategy(state);
			}
		}

		// store the strategy of this step
		if (ModelParameters.CALCULATE_SPATIO_TEMPORAL_CORR) {
			this.evolutionStrategies[currentStep] = this.currentStrategy;
		}

	}

}
