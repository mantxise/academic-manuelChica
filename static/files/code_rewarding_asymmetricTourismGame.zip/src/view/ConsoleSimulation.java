package view;

import java.io.IOException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import controller.Controller;
import model.Model;
import model.ModelParameters;


//----------------------------- MAIN FUNCTION -----------------------------//

/**
 * Main function for EGT for tourists-stakeholders
 * 
 * @author mchica
 * @date 2021/04/15
 * @place Las Palmas GC
 */

public class ConsoleSimulation {		

	// constants to get different options for simple or SA runs
	public final static int NO_SA = 0;
	public final static int SA_INITIAL_POPULATION = 1;
	public final static int SA_TOURIST_COST = 2;
	public final static int SA_STAKEHOLDER_COST = 3;
	public final static int SA_TOURIST_DISCOMFORT = 4;
	public final static int SA_TOURIST_COST_DISCOMFORT = 5;
	public final static int SA_TOURIST_STAKEHOLDER_COSTS = 6;
	public final static int SA_TOURIST_DISCOMFORT_STAKEHOLDER_COST = 7;
	public final static int SA_REWARDING_WEIGHT = 8;
	public final static int SA_PERCAPITA_INCENTIVE_WEIGHT = 9;
	public final static int SA_TOURIST_DISCOMFORT_WEIGHT = 10;
	public final static int SA_TOURIST_COST_WEIGHT = 11;
	public final static int SA_PERCAPITA_INCENTIVE = 12;
	
	
	// LOGGING
	private static final Logger log = Logger.getLogger( Model.class.getName() );
	
	/**
	 * Create an options class to store all the arguments of the command-line call of the program
	 * 
	 * @param options the class containing the options, when returned. It has to be created before calling
	 */
	private static void createArguments (Options options) {
				
		options.addOption("paramsFile", true, "Pathfile with the parameters file");
		options.getOption("paramsFile").setRequired(true);
		
		options.addOption("SNFile", true, "File with the SN to run");
		
		options.addOption("outputFile", true, "File to store all the information about the simulation");
		options.getOption("outputFile").setRequired(true);

		
		options.addOption("touristCost", true, "cost for the touris");
		options.addOption("touristAddedValue", true, "added value for the tourist");
		options.addOption("stakeholderCost", true, "stakeholder cost when tourist is D");
		options.addOption("touristDiscomfort", true, "tourist discomfort when stakeholder is D");
		
		options.addOption("mutProb", true, "Probability for mutating the strategy");		
		options.addOption("speedOfMigration", true, "Speed for players to migrate. 0 is no migration");
		options.addOption("densityPopulation", true, "Density \\rho of the population. 1 means all cells are occupied");

		options.addOption("perCapitaIncentive", true, "value for percapita incentive in rewarding");
		options.addOption("rewardWeight", true, "weight for rewarding");
		options.addOption("adaptiveRewarding", true, "if adaptive rewarding is activated");

		//options.addOption("attract", true, "0 if random migration, 1 if it is biased by the attractiveness of the cells");
		//options.addOption("betaDistrFile", true, "file with the beta distribution values if attract is true");
		
		options.addOption("maxSteps", true, "Max number of steps of the simulation");

		options.addOption("MC", true, "Number of MC simulations");
		options.addOption("seed", true, "Seed for running the MC simulations");

		// parameters for SA
		options.addOption("SA_TOURIST_COST", false, "If running a SA on the tourist cost parameter");	
		options.addOption("SA_STAKEHOLDER_COST", false, "If running a SA on the stakeholder cost parameter");	
		options.addOption("SA_TOURIST_DISCOMFORT", false, "If running a SA on tourist discomfort parameter");	
		options.addOption("SA_TOURIST_STAKEHOLDER_COSTS", false, "If running a SA on the tourist and stakeholder costs");	
		options.addOption("SA_TOURIST_COST_DISCOMFORT", false, "If running a SA on the tourist cost and discomfort");	
		options.addOption("SA_TOURIST_DISCOMFORT_STAKEHOLDER_COST", false, "If running a SA on the tourist discomfort and stakeholder cost");	
		options.addOption("SA_REWARDING_WEIGHT", false, "If running a SA over the rewarding weight");
		options.addOption("SA_PERCAPITA_INCENTIVE_WEIGHT", false, "If running a SA over the percapita incentive and weight for rewarding");
		options.addOption("SA_PERCAPITA_INCENTIVE", false, "If running a SA over the percapita incentive for rewarding");
		options.addOption("SA_TOURIST_DISCOMFORT_WEIGHT", false, "If running a SA over the tau and weight for rewarding");
		options.addOption("SA_TOURIST_COST_WEIGHT", false, "If running a SA over the epsilon (tourist cost) and weight for rewarding");		
		
		// to show help
		options.addOption("help", false, "Show help information");	
				
	}
	
	/**
	 * MAIN CONSOLE-BASED FUNCTION TO RUN A SIMPLE RUN OR A SENSITIVITY ANALYSIS OF THE MODEL PARAMETERS
	 * @param args
	 */
	public static void main (String[] args) {
		
		int SA = NO_SA;
		   	
    	
		String paramsFile = "";
		String outputFile = "";

		ModelParameters params = null;
		
		// parsing the arguments
		Options options = new Options();
		
		createArguments (options);		

		// create the parser
	    CommandLineParser parser = new DefaultParser();
	    
	    try {
	    	
	        // parse the command line arguments for the given options
	        CommandLine line = parser.parse( options, args );

			// get parameters
			params = new ModelParameters();	
			
	        // retrieve the arguments
	        		    
		    if( line.hasOption( "paramsFile" ) )		    
		    	paramsFile = line.getOptionValue("paramsFile");
		    else 		    	
		    	System.err.println( "A parameters file is needed");

		    if( line.hasOption( "outputFile" ) ) 			    
		    	outputFile = line.getOptionValue("outputFile");

		    // read parameters from file
			params.readParameters(paramsFile);

			// set the outputfile
			params.setOutputFile(outputFile);
						
			// once parameters from file are loaded, we modify those read by arguments of command line		

		    // save file for the SN
		    if( line.hasOption( "SNFile" ) ) 
		    	// read again the network apart from setting the name of the file (inside next function)
		    	try {

					params.readGraphFromFile(line.getOptionValue("SNFile"));
					
		    	} catch (IOException e) {

					System.err.println("ConsoleSimulation: Error with SN file when loading parameters for the simulation " + line.getOptionValue("SNFile") + "\n"
							+ e.getMessage());
					e.printStackTrace(new PrintWriter(System.err));
				}
		    			  
		    // MC
		    if( line.hasOption("MC" )) 			    
		    	params.setRunsMC(Integer.parseInt(line.getOptionValue("MC")));
		  
		    // seed
		    if( line.hasOption("seed" )) 			    
		    	params.setSeed(Long.parseLong(line.getOptionValue("seed")));

		    // maxSteps
		    if( line.hasOption("maxSteps" )) 			    
		    	params.setMaxSteps(Integer.parseInt(line.getOptionValue("maxSteps")));		    	 
	
		    // touristCost
		    if( line.hasOption("touristCost")) 			    
		    	params.setTouristCost(Float.parseFloat(line.getOptionValue("touristCost")));
		    	    		
		    // touristAddedValue
		    if( line.hasOption("touristAddedValue")) 			    
		    	params.setTouristAddedValue(Float.parseFloat(line.getOptionValue("touristAddedValue")));

		    // stakeholderCost
		    if( line.hasOption("stakeholderCost")) 			    
		    	params.setStakeholderCost(Float.parseFloat(line.getOptionValue("stakeholderCost")));
		    
		    // touristDiscomfort
		    if( line.hasOption("touristDiscomfort")) 			    
		    	params.setTouristDiscomfort(Float.parseFloat(line.getOptionValue("touristDiscomfort")));

		    // prob mut
		    if( line.hasOption("mutProb" )) 			    
		    	params.setMutProb(Float.parseFloat(line.getOptionValue("mutProb")));

		    // density of population
		    if( line.hasOption("densityPopulation" )) 			    
		    	params.setDensityPopulation(Float.parseFloat(line.getOptionValue("densityPopulation")));

		    // migration speed
		    if( line.hasOption("speedOfMigration" )) 			    
		    	params.setSpeedOfMigration(Float.parseFloat(line.getOptionValue("speedOfMigration")));
		  	    
		    // attractiveness of the cells
		    /*if( line.hasOption("attract" )) 			    
		    	if (Integer.parseInt(line.getOptionValue("attract")) == 1)
		    		params.setCellsAttraction(true);
		    	else
		    		params.setCellsAttraction(false);
		  	    
		    // p of the beta distribution
		    if( line.hasOption("betaDistrFile" )) 			    
		    	params.setBetaDistrFile(line.getOptionValue("betaDistrFile")); 
		    	*/
		  	    
		    // percapita incentive
		    if( line.hasOption("perCapitaIncentive" )) 			    
		    	params.setPerCapitaIncentive(Float.parseFloat(line.getOptionValue("perCapitaIncentive")));

		    // rewardWeight
		    if( line.hasOption("rewardWeight" )) 			    
		    	params.setRewardWeight(Float.parseFloat(line.getOptionValue("rewardWeight")));

		    // adaptive rewarding (if activated, the weight is changing  every timestep depending on Cs for tourists and stks)
		    if( line.hasOption("adaptiveRewarding" )) 			    
		    	params.setAdaptiveRewarding(Boolean.parseBoolean(line.getOptionValue("adaptiveRewarding")));

		     // help information
		    if( line.hasOption("help")) {
			    	
			    // automatically generate the help statement
			    HelpFormatter formatter = new HelpFormatter();
			    formatter.printHelp( "EvoGame4Tourism. Last update April 2021. Manuel Chica", options);			   	
			}	
		  		  
		    // readjust the population from density
		    params.readjustPopFromDensity();
		    
		   
		    // read the file with the values of the beta distribution
		    /*if (params.haveCellsAttraction())
		    	params.loadAttractValuesFile();
		    */
		    
		    // check if we have to store additional information		    
		    if (line.hasOption("output_whole_evolution")) {			    	
		    	ModelParameters.OUTPUT_WHOLE_EVOLUTION  = true;
			}	   	    
		    
		    				
		   if( line.hasOption( "SA_TOURIST_COST" ) ) {
		    	
		    	// we have to run a SA on the tourist cost param		    	
		    	SA = SA_TOURIST_COST;
		    	
		    } else if( line.hasOption( "SA_STAKEHOLDER_COST" ) ) {
		    	
		    	// we have to run a SA on the stakedholder cost param		    	
		    	SA = SA_STAKEHOLDER_COST;
		    	
		    } else if( line.hasOption( "SA_TOURIST_STAKEHOLDER_COSTS" ) ) {
		    	
		    	// we have to run a SA on the tourist and stakeholder costs
		    	
		    	SA = SA_TOURIST_STAKEHOLDER_COSTS;

		    } else if( line.hasOption( "SA_TOURIST_COST_DISCOMFORT" ) ) {
		    	
		    	// we have to run a SA on the tourist cost and discomfort
		    	
		    	SA = SA_TOURIST_COST_DISCOMFORT;

		    } else if( line.hasOption( "SA_TOURIST_DISCOMFORT" ) ) {
		    	
		    	// we have to run a SA on the tourist discomfort
		    	
		    	SA = SA_TOURIST_DISCOMFORT;
		    	
		    }  else if( line.hasOption( "SA_TOURIST_DISCOMFORT_STAKEHOLDER_COST" ) ) {
		    	
		    	// we have to run a SA on the tourist discomfort
		    	
		    	SA = SA_TOURIST_DISCOMFORT_STAKEHOLDER_COST;
		    	
		    } else if( line.hasOption( "SA_REWARDING_WEIGHT" ) ) {
		    	
		    	// we have to run a SA on the rewarding weight
		    	
		    	SA = SA_REWARDING_WEIGHT;	

		    } else if( line.hasOption( "SA_PERCAPITA_INCENTIVE_WEIGHT" ) ) {
		    	
		    	// we have to run a SA on the percapita incentive and weight
		    	
		    	SA = SA_PERCAPITA_INCENTIVE_WEIGHT;	
		    	
		    } else if( line.hasOption( "SA_TOURIST_DISCOMFORT_WEIGHT" ) ) {
		    	
		    	// we have to run a SA on the tau and weight
		    	
		    	SA = SA_TOURIST_DISCOMFORT_WEIGHT;	
		    	
		    } else if( line.hasOption( "SA_TOURIST_COST_WEIGHT" ) ) {
		    	
		    	// we have to run a SA on the epsilon and weight
		    	
		    	SA = SA_TOURIST_COST_WEIGHT;	
		    	
		    } else if( line.hasOption( "SA_PERCAPITA_INCENTIVE" ) ) {
		    	
		    	// we have to run a SA on the percapita incentive
		    	
		    	SA = SA_PERCAPITA_INCENTIVE;	
		    	
		    }
		   		   		   
		   // check the parameters of the model
		   params.checkGameParameters ();
		   
	    }
	    
	    catch (ParseException exp ) {
	    	
	        // oops, something went wrong
	        System.err.println( "Parsing failed.  Reason: " + exp.getMessage() );
			log.log(Level.SEVERE, "Parsing failed.  Reason: " + exp.toString(), exp);
			
	    }	    
	    	
        System.out.println("\n****** STARTING THE RUN OF THE EGT MODEL FOR TOURIST-STAKEHOLDERS (April 2021)******\n");

        Date date = new Date();
        System.out.println("****** " + date.toString() + "******\n");

        File fileAllMC = new File ("./logs/" + "AllMCruns_" + params.getOutputFile() + ".txt");
        File fileSummaryMC = new File ("./logs/" + "SummaryMCruns_" +  params.getOutputFile() + ".txt");
        File fileAllMCLQ = new File ("./logs/" + "AllMCrunsLQ_" + params.getOutputFile() + ".txt");
        File fileSummaryMCLQ = new File ("./logs/" + "SummaryMCrunsLQ_" +  params.getOutputFile() + ".txt");
        File fileTimeSeriesMC = new File ("./logs/" + "TimeSeriesMCruns_" +  params.getOutputFile() + ".txt");
       
        // the SA check    	    			    	
	    if (SA == NO_SA) {
	    	
	    	// no SA, simple run
	    	
	    	RunStats stats;
	    	
	    	// print parameters for double-checking
	    	System.out.println("-> Parameters values:");
		    PrintWriter out = new PrintWriter(System.out, true);
	        params.printParameters(out);
	        
	        log.log(Level.FINE, "\n*** Parameters values of this model:\n" + params.export());
	        
	        
	        // START PREPARING CONTROLLER FOR RUNNING
			long time1 = System.currentTimeMillis ();
		
			Controller controller;
			
			controller = new Controller (params, paramsFile);
			
	        // END PREPARING CONTROLLER FOR RUNNING
	 		
			
			// BEGIN RUNNING MODEL WITH ALL THE MC SIMULATION
	 		stats = controller.runModel();		
	 		// END RUNNING MODEL WITH ALL THE MC SIMULATION
	 		
	 		stats.setExpName(params.getOutputFile());
	 		
	 		long  time2  = System.currentTimeMillis( );
	 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the simulation");
	 		
	 		stats.calcAllStats();
	         
	 		// print the stats in the screen 		
	 		stats.printSummaryStats(out, false);
	 		stats.printSummaryStatsByAveragingLastQuartile(out, false);  // also the last quartile info
	 		System.out.println();
	 		
	 		// print the stats into a file
	        System.out.println("\n****** Stats also saved into a file ******\n");
	         
	        PrintWriter printWriter;
	         
	 		try {
	 			
	 			// print all the runs info into a file
	 			printWriter = new PrintWriter (fileAllMC);
	 			stats.printAllStats (printWriter, false);
	 	        printWriter.close (); 
	 	        
	 	        // print all the runs info (last quartiles of the sims) into a file
	 			printWriter = new PrintWriter (fileAllMCLQ);
	 			stats.printAllStatsByAveragingLastQuartile (printWriter, false);
	 	        printWriter.close ();  
	 	        
	 	        // print the summarized MC runs into a file
	 	        printWriter = new PrintWriter (fileSummaryMC);
	 			stats.printSummaryStats (printWriter, false);
	 	        printWriter.close ();    
	 	        
	 	        // print the summarized MC runs (last quartiles of the sims) into a file
	 	        printWriter = new PrintWriter (fileSummaryMCLQ);
	 			stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);
	 	        printWriter.close ();    

	 	        // print the time series into a file
	 	        printWriter = new PrintWriter (fileTimeSeriesMC);
	 			stats.printTimeSeriesStats (printWriter);
	 	        printWriter.close ();    
	 	        
	 	        
	 		} catch (FileNotFoundException e) {
	 			
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 			
	 		    log.log( Level.SEVERE, e.toString(), e );
	 		} 
	    	
	    } else {
	    	    	
	    	if ( SA == SA_TOURIST_COST) {
	    		
	    		SensitivityAnalysis.runSA_touristCost (params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	} else if ( SA == SA_STAKEHOLDER_COST) {
	    		
	    		SensitivityAnalysis.runSA_stakeholderCost (params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	} else if ( SA == SA_TOURIST_DISCOMFORT) {
	    		
	    		SensitivityAnalysis.runSA_touristDiscomfort (params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	} else if ( SA == SA_TOURIST_COST_DISCOMFORT) {
	    		
	    		SensitivityAnalysis.runSA_touristCost_discomfort (params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	} else if ( SA == SA_TOURIST_STAKEHOLDER_COSTS) {
	    		
	    		SensitivityAnalysis.runSA_touristCost_stakeholderCost (params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	}  else if ( SA == SA_TOURIST_DISCOMFORT_STAKEHOLDER_COST) {
	    		
	    		SensitivityAnalysis.runSA_touristDiscomfort_stakeholderCost (params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	}  else if ( SA == SA_REWARDING_WEIGHT) {
	    		
	    		SensitivityAnalysis.runSA_rewardingWeight(params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    	
	    	} else if ( SA == SA_PERCAPITA_INCENTIVE) {
	    		
	    		SensitivityAnalysis.runSA_perCapitaIncentive(params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    	
	    	} else if ( SA == SA_PERCAPITA_INCENTIVE_WEIGHT) {
	    		
	    		SensitivityAnalysis.runSA_perCapitaIncentive_Reward (params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	} else if ( SA == SA_TOURIST_DISCOMFORT_WEIGHT) {
    		
	    		SensitivityAnalysis.runSA_touristDiscomfort_Reward (params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	} else if ( SA == SA_TOURIST_COST_WEIGHT) {
    	
	    		SensitivityAnalysis.runSA_touristCost_Reward (params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    	}	  	
	    	
	    }								
	}

	
}
