package view;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


import controller.Controller;
import model.Model;
import model.ModelParameters;


/**
 * SA class to run and save results when running the MC model with different parameter configuration
 * from a config base tourists-stakeholders
 * 
 * @author mchica
 * @date 2021/04/15
 * @place Las Palmas GC
 */

public class SensitivityAnalysis {		
	
	// CHANGED TO CONSIDER ABSOLUTE VALUES AND NOT PERCENTAGES!! (BECAUSE OF HAVING DIFFERENCES BETWEEN MACHINES...)

	static int cooperators_min = 0;
	static int cooperators_max = 0;
	static int cooperators_step = 0;
				
	
	// LOGGING
	private static final Logger log = Logger.getLogger( Model.class.getName() );
	
	/**
	 * Static function to run a SA for the TouristCost
	 * 
	 */	
	public static void runSA_touristCost (ModelParameters _params, String _paramsFile, 
			File fileAllMC, File fileSummaryMCRuns, File fileAllMCLQ, File fileSummaryMCRunsLQ) {

		// create output files in case they exist as we will append the simulation contents
		

		if (fileAllMC.exists() && !fileAllMC.isDirectory()) {
			fileAllMC.delete();
		}
		
		if (fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory()) {
			fileSummaryMCRuns.delete();
		}
		
		if (fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory()) {
			fileAllMCLQ.delete();
		}
		
		if (fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory()) {
			fileSummaryMCRunsLQ.delete();
		}
		
		// *********************  Array with the TouristCost values 
		
		// create the arrays with the TouristCost values
		ArrayList<Double> valuesTouristCost = new ArrayList<Double>();
		
		// save the values to the array of ratios
		int minimumValue = 1;								// minimum value for the SA		
		BigDecimal valueParam = new BigDecimal("2");		// maximum value for the SA
		BigDecimal step = new BigDecimal("0.05");			// steo value for the SA	
		
		
		int k = 0;		
		while (valueParam.compareTo(new BigDecimal(minimumValue)) > -1 ){	
				    	
			valuesTouristCost.add(k, valueParam.doubleValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}

	    Controller controller = new Controller (_params, _paramsFile);

	    for (int i = 0; i < valuesTouristCost.size(); i++ ) {
		    		
    		// save the current alpha value	    	
	    	_params.setTouristCost( valuesTouristCost.get(i).floatValue());

	        System.out.println("-> OAT for parameter TouristCost " + valuesTouristCost.get(i));

			log.log(Level.FINE, "\n****** Running Monte-Carlo simulation for OAT configuration: touristCost = " + 
					_params.getTouristCost() + " \n");
		
			RunStats stats;

			long time1 = System.currentTimeMillis ();
			
	 		// running the model with the MC simulations
	 		stats = controller.runModel();		

	 		long  time2  = System.currentTimeMillis( );
	 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the alpha SA simulation");

	 		// calculate the stats for this run and set the name of this experiment
	 		stats.setExpName("touristCostValue;" + _params.getTouristCost());		    	
	 		stats.calcAllStats();

			PrintWriter out = new PrintWriter(System.out, true);
			_params.printParameters(out);
			 
	 		// print the stats in the screen 		
	        System.out.println("\n****** Stats of this OAT configuration ******\n");
	 		stats.printSummaryStats(out, false);
	 		stats.printSummaryStatsByAveragingLastQuartile(out, false);

			// print the stats into a file
			System.out.println("\n****** Stats of this alpha OAT onfiguration also saved into a file ******\n");
			
			PrintWriter printWriter;
	         
	 		try {
	 			
	 			// print all the runs in a file 			
	 			printWriter = new PrintWriter (new FileOutputStream(fileAllMC, true));
	 			
	 			if ( fileAllMC.exists() && !fileAllMC.isDirectory() )
	 		        stats.appendAllStats(printWriter);		 		        
	 		    else
		 			stats.printAllStats(printWriter, false);		 		  
	 		    
	 	        printWriter.close ();       	
	 	        
	 	        // print the summarized MC runs in a file
	 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRuns, true));
	 	        
	 	       if ( fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory() )
	 	    	    stats.appendSummaryStats(printWriter);		 		        
	 		    else		 		    	
	 		    	stats.printSummaryStats(printWriter, false);
	 		    		 				 			
	 	        printWriter.close (); 
	 	        
	 	        // print all the runs in a file 			
	 			printWriter = new PrintWriter (new FileOutputStream(fileAllMCLQ, true));
	 			
	 			if ( fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory() )
		 			stats.printAllStatsByAveragingLastQuartile(printWriter, true);		 		 
	 		    else
		 			stats.printAllStatsByAveragingLastQuartile(printWriter, false);		 		  
	 		    
	 	        printWriter.close ();       	
	 	        
	 	        // print the summarized MC runs in a file
	 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRunsLQ, true));
	 	        
	 	       if ( fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory() )
	 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, true);
	 		    else		 		    	
	 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);
	 		    		 				 			
	 	        printWriter.close ();  
	 	        
	 		} catch (FileNotFoundException e) {
	 			
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 			
	 		    log.log( Level.SEVERE, e.toString(), e );
	 		} 
    	}
    	
    }	
	
	
	/**
	 * Static function to run a SA for the touristDiscomfort value
	 * 
	 */	
	public static void runSA_touristDiscomfort (ModelParameters _params, String _paramsFile, 
			File fileAllMC, File fileSummaryMCRuns, File fileAllMCLQ, File fileSummaryMCRunsLQ) {

		// create output files in case they exist as we will append the simulation contents
		

		if (fileAllMC.exists() && !fileAllMC.isDirectory()) {
			fileAllMC.delete();
		}
		
		if (fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory()) {
			fileSummaryMCRuns.delete();
		}
		
		if (fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory()) {
			fileAllMCLQ.delete();
		}
		
		if (fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory()) {
			fileSummaryMCRunsLQ.delete();
		}
		
		// *********************  Array with the touristDiscomfort values 
		
		// create the arrays with the touristDiscomfort values
		ArrayList<Double> valuesTouristDiscomfort = new ArrayList<Double>();

		// save the values to the array of ratios
		int minimumValue = 0;								// minimum value for the SA		
		BigDecimal valueParam = new BigDecimal("1");		// maximum value for the SA
		BigDecimal step = new BigDecimal("0.05");			// steo value for the SA	
		
		int k = 0;
		while (valueParam.compareTo(new BigDecimal(minimumValue)) > -1 ){	
				    	
			valuesTouristDiscomfort.add(k, 1. + valueParam.doubleValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}

	    Controller controller = new Controller (_params, _paramsFile);

	    for (int i = 0; i < valuesTouristDiscomfort.size(); i++ ) {
		    		
    		// save the current fine value	    	
	    	_params.setTouristDiscomfort( valuesTouristDiscomfort.get(i).floatValue());

	        System.out.println("-> OAT for parameter touristDiscomfort " + valuesTouristDiscomfort.get(i));

			log.log(Level.FINE, "\n****** Running Monte-Carlo simulation for OAT configuration: touristDiscomfort = " + 
					_params.getTouristDiscomfort() + " \n");
		
			RunStats stats;

			long time1 = System.currentTimeMillis ();
			
	 		// running the model with the MC simulations
	 		stats = controller.runModel();		

	 		long  time2  = System.currentTimeMillis( );
	 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the fine SA simulation");

	 		// calculate the stats for this run and set the name of this experiment
	 		stats.setExpName("touristDiscomfortValue;" + _params.getTouristDiscomfort());		    	
	 		stats.calcAllStats();

			PrintWriter out = new PrintWriter(System.out, true);
			_params.printParameters(out);
			 
	 		// print the stats in the screen 		
	        System.out.println("\n****** Stats of this OAT configuration ******\n");
	 		stats.printSummaryStats(out, false);
	 		stats.printSummaryStatsByAveragingLastQuartile(out, false);

			// print the stats into a file
			System.out.println("\n****** Stats of this fine OAT onfiguration also saved into a file ******\n");
			
			PrintWriter printWriter;
	         
	 		try {
	 			
	 			// print all the runs in a file 			
	 			printWriter = new PrintWriter (new FileOutputStream(fileAllMC, true));
	 			
	 			if ( fileAllMC.exists() && !fileAllMC.isDirectory() )
	 		        stats.appendAllStats(printWriter);		 		        
	 		    else
		 			stats.printAllStats(printWriter, false);		 		  
	 		    
	 	        printWriter.close ();       	
	 	        
	 	        // print the summarized MC runs in a file
	 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRuns, true));
	 	        
	 	       if ( fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory() )
	 	    	    stats.appendSummaryStats(printWriter);		 		        
	 		    else		 		    	
	 		    	stats.printSummaryStats(printWriter, false);
	 		    		 				 			
	 	        printWriter.close (); 
	 	        
	 	        // print all the runs in a file 			
	 			printWriter = new PrintWriter (new FileOutputStream(fileAllMCLQ, true));
	 			
	 			if ( fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory() )
		 			stats.printAllStatsByAveragingLastQuartile(printWriter, true);		 		 
	 		    else
		 			stats.printAllStatsByAveragingLastQuartile(printWriter, false);		 		  
	 		    
	 	        printWriter.close ();       	
	 	        
	 	        // print the summarized MC runs in a file
	 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRunsLQ, true));
	 	        
	 	       if ( fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory() )
	 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, true);
	 		    else		 		    	
	 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);
	 		    		 				 			
	 	        printWriter.close ();  
	 	        
	 		} catch (FileNotFoundException e) {
	 			
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 			
	 		    log.log( Level.SEVERE, e.toString(), e );
	 		} 
    	}
    	
    }	
	
	
	/**
	 * Static function to run a SA for the stakeholdercost value
	 * 
	 */	
	public static void runSA_stakeholderCost (ModelParameters _params, String _paramsFile, 
			File fileAllMC, File fileSummaryMCRuns, File fileAllMCLQ, File fileSummaryMCRunsLQ) {

		// create output files in case they exist as we will append the simulation contents
		
		if (fileAllMC.exists() && !fileAllMC.isDirectory()) {
			fileAllMC.delete();
		}
		
		if (fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory()) {
			fileSummaryMCRuns.delete();
		}
		
		if (fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory()) {
			fileAllMCLQ.delete();
		}
		
		if (fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory()) {
			fileSummaryMCRunsLQ.delete();
		}
		
		// *********************  Array with the stakeholderCost values 
		
		// create the arrays with the reward values
		ArrayList<Double> valuesStakeholderCost = new ArrayList<Double>();

		// save the values to the array of ratios
		int minimumValue = 0;								// minimum value for the SA		
		BigDecimal valueParam = new BigDecimal("1");		// maximum value for the SA
		BigDecimal step = new BigDecimal("0.05");			// steo value for the SA	
			
		int k = 0;
		while (valueParam.compareTo(new BigDecimal(minimumValue)) > -1 ){	
				    	
			valuesStakeholderCost.add(k, 1. + valueParam.doubleValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}

	    Controller controller = new Controller (_params, _paramsFile);

	    for (int i = 0; i < valuesStakeholderCost.size(); i++ ) {
		    		
    		// save the current reward value	    	
	    	_params.setStakeholderCost( valuesStakeholderCost.get(i).floatValue());

	        System.out.println("-> OAT for parameter stakeholder cost of " + valuesStakeholderCost.get(i));

			log.log(Level.FINE, "\n****** Running Monte-Carlo simulation for OAT configuration: stakeholderCost = " + 
					_params.getStakeholderCost() + " \n");
		
			RunStats stats;

			long time1 = System.currentTimeMillis ();
			
	 		// running the model with the MC simulations
	 		stats = controller.runModel();		

	 		long  time2  = System.currentTimeMillis( );
	 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the fine SA simulation");

	 		// calculate the stats for this run and set the name of this experiment
	 		stats.setExpName("stakeholderCost;" + _params.getStakeholderCost());		    	
	 		stats.calcAllStats();

			PrintWriter out = new PrintWriter(System.out, true);
			_params.printParameters(out);
			 
	 		// print the stats in the screen 		
	        System.out.println("\n****** Stats of this OAT configuration ******\n");
	 		stats.printSummaryStats(out, false);
	 		stats.printSummaryStatsByAveragingLastQuartile(out, false);

			// print the stats into a file
			System.out.println("\n****** Stats of this fine OAT onfiguration also saved into a file ******\n");
			
			PrintWriter printWriter;
	         
	 		try {
	 			
	 			// print all the runs in a file 			
	 			printWriter = new PrintWriter (new FileOutputStream(fileAllMC, true));
	 			
	 			if ( fileAllMC.exists() && !fileAllMC.isDirectory() )
	 		        stats.appendAllStats(printWriter);		 		        
	 		    else
		 			stats.printAllStats(printWriter, false);		 		  
	 		    
	 	        printWriter.close ();       	
	 	        
	 	        // print the summarized MC runs in a file
	 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRuns, true));
	 	        
	 	       if ( fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory() )
	 	    	    stats.appendSummaryStats(printWriter);		 		        
	 		    else		 		    	
	 		    	stats.printSummaryStats(printWriter, false);
	 		    		 				 			
	 	        printWriter.close (); 
	 	        
	 	        // print all the runs in a file 			
	 			printWriter = new PrintWriter (new FileOutputStream(fileAllMCLQ, true));
	 			
	 			if ( fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory() )
		 			stats.printAllStatsByAveragingLastQuartile(printWriter, true);		 		 
	 		    else
		 			stats.printAllStatsByAveragingLastQuartile(printWriter, false);		 		  
	 		    
	 	        printWriter.close ();       	
	 	        
	 	        // print the summarized MC runs in a file
	 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRunsLQ, true));
	 	        
	 	       if ( fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory() )
	 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, true);
	 		    else		 		    	
	 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);
	 		    		 				 			
	 	        printWriter.close ();  
	 	        
	 		} catch (FileNotFoundException e) {
	 			
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 			
	 		    log.log( Level.SEVERE, e.toString(), e );
	 		} 
    	}
    	
    }	
	
	
	/**
	 * Static function to run a SA (OAT) for tourist discomfort and cost
	 * 
	 */	
	public static void runSA_touristCost_discomfort (ModelParameters _params, String _paramsFile, 
			File fileAllMC, File fileSummaryMCRuns, File fileAllMCLQ, File fileSummaryMCRunsLQ) {

		// create output files in case they exist as we will append the simulation contents
		
		if (fileAllMC.exists() && !fileAllMC.isDirectory()) {
			fileAllMC.delete();
		}
		
		if (fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory()) {
			fileSummaryMCRuns.delete();
		}
		
		if (fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory()) {
			fileAllMCLQ.delete();
		}
		
		if (fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory()) {
			fileSummaryMCRunsLQ.delete();
		}
		
				
		// *********************  Array with the tourist added value 
		
		// create the arrays with the tourist discomfort values
		ArrayList<Float> valuesTouristDiscomfort = new ArrayList<Float>();

		// save the values to the array of ratios
		int minimumValue = 0;								// minimum value for the SA		
		BigDecimal valueParam = new BigDecimal("1");		// maximum value for the SA
		BigDecimal step = new BigDecimal("0.1");			// steo value for the SA	
			
		int k = 0;
		while (valueParam.compareTo(new BigDecimal(minimumValue)) > -1 ){					    	
			valuesTouristDiscomfort.add(k, valueParam.floatValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}
		
		// *********************  Array with the tourist cost values 
		
		// create the arrays with the touristCost values
		ArrayList<Float> valuesTouristCost = new ArrayList<Float>();
		
		
		// save the values to the array of ratios
		minimumValue = 1;						// minimum value for the SA		
		valueParam = new BigDecimal("2");		// maximum value for the SA
		step = new BigDecimal("0.1");			// steo value for the SA	
		
		k = 0;
		while (valueParam.compareTo(new BigDecimal(minimumValue)) > -1 ){					    	
			valuesTouristCost.add(k, valueParam.floatValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}
				
				
	    Controller controller = new Controller (_params, _paramsFile);

	    for (int i = 0; i < valuesTouristDiscomfort.size(); i++ ) {

		    for (int j = 0; j < valuesTouristCost.size(); j++ ) {
	    		    		
	    		// set the values to the params	for the SA	
		    	_params.setTouristDiscomfort(valuesTouristDiscomfort.get(i));
		    	_params.setTouristCost(valuesTouristCost.get(j));

		        System.out.println("-> OAT for touristCost = " + _params.getTouristCost() 
		        + " touristDiscomfort = " + _params.getTouristDiscomfort());

				log.log(Level.FINE, "\n****** Running Monte-Carlo simulation for OAT configuration: touristCost = " + 
						_params.getTouristCost() + " touristDiscomfort = " + _params.getTouristDiscomfort() + " \n");
		
				RunStats stats;

				long time1 = System.currentTimeMillis ();
				
		 		// running the model with the MC simulations
		 		stats = controller.runModel();		

		 		long  time2  = System.currentTimeMillis( );
		 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the OAT simulation");

		 		// calculate the stats for this run and set the name of this experiment
		 		stats.setExpName("touristCost;" + _params.getTouristCost() + ";touristDiscomfort;" + _params.getTouristDiscomfort() );		    	
		 		stats.calcAllStats();

				PrintWriter out = new PrintWriter(System.out, true);
				_params.printParameters(out);
				 
		 		// print the stats in the screen 		
		        System.out.println("\n****** Stats of this OAT configuration ******\n");
		 		stats.printSummaryStats (out, false);
		 		stats.printSummaryStatsByAveragingLastQuartile(out, false);

				// print the stats into a file
				System.out.println("\n****** Stats of this OAT configuration also saved into a file ******\n");
				
				PrintWriter printWriter;
		         
		 		try {
		 			
		 			// print all the runs in a file 			
		 			printWriter = new PrintWriter (new FileOutputStream(fileAllMC, true));
		 			
		 			if ( fileAllMC.exists() && !fileAllMC.isDirectory() )
		 		        stats.appendAllStats (printWriter);		 		        
		 		    else
			 			stats.printAllStats (printWriter, false);	
		 	        printWriter.close ();       	
		 	        
		 	        // print the summarized MC runs in a file
		 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRuns, true));
		 	        
		 	        if ( fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory() )
		 	    	    stats.appendSummaryStats (printWriter);		 		        
		 		    else		 		    	
		 		    	stats.printSummaryStats (printWriter, false);	
		 	        printWriter.close ();    
		 	    
		 	        // print all the runs in a file 			
		 			printWriter = new PrintWriter (new FileOutputStream(fileAllMCLQ, true));
		 			
		 			if ( fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory() )
			 			stats.printAllStatsByAveragingLastQuartile(printWriter, true);	      
		 		    else
			 			stats.printAllStatsByAveragingLastQuartile(printWriter, false);	
		 	        printWriter.close ();       	
		 	        
		 	        // print the summarized MC runs in a file
		 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRunsLQ, true));
		 	        
		 	        if ( fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory() )
		 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, true);	
		 		    else		 		    	
		 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);	
		 	        printWriter.close ();    
		 	        
		 		} catch (FileNotFoundException e) {
		 			
		 			// TODO Auto-generated catch block
		 			e.printStackTrace();
		 			
		 		    log.log( Level.SEVERE, e.toString(), e );
		 		} 
	    	
		    }
	    }	    					
		
	}
					
		
	/**
	 * Static function to run a SA (OAT) for tourist cost and additional cost for the stakeholder
	 * 
	 */	
	public static void runSA_touristCost_stakeholderCost (ModelParameters _params, String _paramsFile, 
			File fileAllMC, File fileSummaryMCRuns, File fileAllMCLQ, File fileSummaryMCRunsLQ) {

		// create output files in case they exist as we will append the simulation contents
		
		if (fileAllMC.exists() && !fileAllMC.isDirectory()) {
			fileAllMC.delete();
		}
		
		if (fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory()) {
			fileSummaryMCRuns.delete();
		}
		
		if (fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory()) {
			fileAllMCLQ.delete();
		}
		
		if (fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory()) {
			fileSummaryMCRunsLQ.delete();
		}
		
				
		// *********************  Arrays
		
		// create the arrays with the stakeholder cost values
		ArrayList<Float> valuesStakeholderCost = new ArrayList<Float>();

		// save the values to the array of ratios
		int minimumValue = 0;								// minimum value for the SA		
		BigDecimal valueParam = new BigDecimal("1");		// maximum value for the SA
		BigDecimal step = new BigDecimal("0.1");			// steo value for the SA	
			
		int k = 0;
		while (valueParam.compareTo(new BigDecimal(minimumValue)) > -1 ){					    	
			valuesStakeholderCost.add(k, valueParam.floatValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}
		
		// *********************  Array with the tourist cost values 
		
		// create the arrays with the touristCost values
		ArrayList<Float> valuesTouristCost = new ArrayList<Float>();
		
		// save the values to the array of ratios
		minimumValue = 1;								// minimum value for the SA		
		valueParam = new BigDecimal("2");		// maximum value for the SA
		step = new BigDecimal("0.1");			// steo value for the SA	
		
		k = 0;
		while (valueParam.compareTo(new BigDecimal(minimumValue)) > -1 ){					    	
			valuesTouristCost.add(k, valueParam.floatValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}
				
				
	    Controller controller = new Controller (_params, _paramsFile);

	    for (int i = 0; i < valuesStakeholderCost.size(); i++ ) {

		    for (int j = 0; j < valuesTouristCost.size(); j++ ) {
	    		    		
	    		// set the values to the params	for the SA	
		    	_params.setStakeholderCost(valuesStakeholderCost.get(i));
		    	_params.setTouristCost(valuesTouristCost.get(j));

		        System.out.println("-> OAT for touristCost = " + _params.getTouristCost() 
		        + " stakeholderCost = " + _params.getStakeholderCost() );

				log.log(Level.FINE, "\n****** Running Monte-Carlo simulation for OAT configuration: touristCost = " + 
						_params.getTouristCost() + " stakeholderCost = " + _params.getStakeholderCost() + " \n");
		
				RunStats stats;

				long time1 = System.currentTimeMillis ();
				
		 		// running the model with the MC simulations
		 		stats = controller.runModel();		

		 		long  time2  = System.currentTimeMillis( );
		 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the OAT simulation");

		 		// calculate the stats for this run and set the name of this experiment
		 		stats.setExpName("touristCost;" + _params.getTouristCost() + ";stakeholderCost;" + _params.getStakeholderCost() );		    	
		 		stats.calcAllStats();

				PrintWriter out = new PrintWriter(System.out, true);
				_params.printParameters(out);
				 
		 		// print the stats in the screen 		
		        System.out.println("\n****** Stats of this OAT configuration ******\n");
		 		stats.printSummaryStats (out, false);
		 		stats.printSummaryStatsByAveragingLastQuartile(out, false);

				// print the stats into a file
				System.out.println("\n****** Stats of this OAT configuration also saved into a file ******\n");
				
				PrintWriter printWriter;
		         
		 		try {
		 			
		 			// print all the runs in a file 			
		 			printWriter = new PrintWriter (new FileOutputStream(fileAllMC, true));
		 			
		 			if ( fileAllMC.exists() && !fileAllMC.isDirectory() )
		 		        stats.appendAllStats (printWriter);		 		        
		 		    else
			 			stats.printAllStats (printWriter, false);	
		 	        printWriter.close ();       	
		 	        
		 	        // print the summarized MC runs in a file
		 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRuns, true));
		 	        
		 	        if ( fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory() )
		 	    	    stats.appendSummaryStats (printWriter);		 		        
		 		    else		 		    	
		 		    	stats.printSummaryStats (printWriter, false);	
		 	        printWriter.close ();    
		 	    
		 	        // print all the runs in a file 			
		 			printWriter = new PrintWriter (new FileOutputStream(fileAllMCLQ, true));
		 			
		 			if ( fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory() )
			 			stats.printAllStatsByAveragingLastQuartile(printWriter, true);	      
		 		    else
			 			stats.printAllStatsByAveragingLastQuartile(printWriter, false);	
		 	        printWriter.close ();       	
		 	        
		 	        // print the summarized MC runs in a file
		 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRunsLQ, true));
		 	        
		 	        if ( fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory() )
		 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, true);	
		 		    else		 		    	
		 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);	
		 	        printWriter.close ();    
		 	        
		 		} catch (FileNotFoundException e) {
		 			
		 			// TODO Auto-generated catch block
		 			e.printStackTrace();
		 			
		 		    log.log( Level.SEVERE, e.toString(), e );
		 		} 
	    	
		    }
	    }	    					
		
	}
	
	
	/**
	 * Static function to run a SA for the rewarding weight
	 * 
	 */	
	public static void runSA_rewardingWeight (ModelParameters _params, String _paramsFile, 
			File fileAllMC, File fileSummaryMCRuns, File fileAllMCLQ, File fileSummaryMCRunsLQ) {

		// create output files in case they exist as we will append the simulation contents
		
		if (fileAllMC.exists() && !fileAllMC.isDirectory()) {
			fileAllMC.delete();
		}
		
		if (fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory()) {
			fileSummaryMCRuns.delete();
		}
		
		if (fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory()) {
			fileAllMCLQ.delete();
		}
		
		if (fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory()) {
			fileSummaryMCRunsLQ.delete();
		}
		
		// *********************  Array with the values 
		
		// create the arrays with the reward weight values
		ArrayList<Float> valuesRewardWeight = new ArrayList<Float>();
		
		// save the values to the array of ratios
		BigDecimal valueParam = new BigDecimal("1");
		BigDecimal step = new BigDecimal("0.1");		
		int k = 0;
		while (valueParam.compareTo(new BigDecimal(0)) > -1 ){	
				    	
			valuesRewardWeight.add(k, valueParam.floatValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}

	    Controller controller = new Controller (_params, _paramsFile);

	    for (int i = 0; i < valuesRewardWeight.size(); i++ ) {
		    		
	    	// set the perCapitaIncentive to 1 to activate the reward-punishment policy
	    	// JIC, it was not activated
	    	if (! (_params.getPerCapitaIncentive() > 0) ) {
		        System.out.println("WARNING: per capita incentive was set to 0. Therefore, we set it to 1 to run the SA analysis");
		    	_params.setPerCapitaIncentive(1);
	    	}
	    	
    		// save the current RewardWeight value	    	
	    	_params.setRewardWeight(valuesRewardWeight.get(i));

	        System.out.println("-> OAT for parameter reward weight of " + valuesRewardWeight.get(i));

			log.log(Level.FINE, "\n****** Running Monte-Carlo simulation for OAT configuration: rewardWeight = " + 
					_params.getRewardWeight() + " \n");
		
			RunStats stats;

			long time1 = System.currentTimeMillis ();
			
	 		// running the model with the MC simulations
	 		stats = controller.runModel();		

	 		long  time2  = System.currentTimeMillis( );
	 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the simulation");

	 		// calculate the stats for this run and set the name of this experiment
	 		stats.setExpName("rewardWeight;" + _params.getRewardWeight());		    	
	 		stats.calcAllStats();

			PrintWriter out = new PrintWriter(System.out, true);
			_params.printParameters(out);
			 
	 		// print the stats in the screen 		
	        System.out.println("\n****** Stats of this OAT configuration ******\n");
	 		stats.printSummaryStats(out, false);
	 		stats.printSummaryStatsByAveragingLastQuartile(out, false);

			// print the stats into a file
			System.out.println("\n****** Stats of this rewardWeight OAT onfiguration also saved into a file ******\n");
			
			PrintWriter printWriter;
	         
	 		try {
	 			
	 			// print all the runs in a file 			
	 			printWriter = new PrintWriter (new FileOutputStream(fileAllMC, true));
	 			
	 			if ( fileAllMC.exists() && !fileAllMC.isDirectory() )
	 		        stats.appendAllStats(printWriter);		 		        
	 		    else
		 			stats.printAllStats(printWriter, false);		 		  
	 		    
	 	        printWriter.close ();       	
	 	        
	 	        // print the summarized MC runs in a file
	 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRuns, true));
	 	        
	 	       if ( fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory() )
	 	    	    stats.appendSummaryStats(printWriter);		 		        
	 		    else		 		    	
	 		    	stats.printSummaryStats(printWriter, false);
	 		    		 				 			
	 	        printWriter.close (); 
	 	        
	 	        // print all the runs in a file 			
	 			printWriter = new PrintWriter (new FileOutputStream(fileAllMCLQ, true));
	 			
	 			if ( fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory() )
		 			stats.printAllStatsByAveragingLastQuartile(printWriter, true);		 		 
	 		    else
		 			stats.printAllStatsByAveragingLastQuartile(printWriter, false);		 		  
	 		    
	 	        printWriter.close ();       	
	 	        
	 	        // print the summarized MC runs in a file
	 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRunsLQ, true));
	 	        
	 	       if ( fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory() )
	 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, true);
	 		    else		 		    	
	 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);
	 		    		 				 			
	 	        printWriter.close ();  
	 	        
	 		} catch (FileNotFoundException e) {
	 			
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 			
	 		    log.log( Level.SEVERE, e.toString(), e );
	 		} 
    	}
    	
    }	
	
	

	/**
	 * Static function to run a SA for the perCapita incentive
	 * 
	 */	
	public static void runSA_perCapitaIncentive (ModelParameters _params, String _paramsFile, 
			File fileAllMC, File fileSummaryMCRuns, File fileAllMCLQ, File fileSummaryMCRunsLQ) {

		// create output files in case they exist as we will append the simulation contents
		
		if (fileAllMC.exists() && !fileAllMC.isDirectory()) {
			fileAllMC.delete();
		}
		
		if (fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory()) {
			fileSummaryMCRuns.delete();
		}
		
		if (fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory()) {
			fileAllMCLQ.delete();
		}
		
		if (fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory()) {
			fileSummaryMCRunsLQ.delete();
		}
		
		// *********************  Array with the values 
		
		// create the arrays with the percapita incentive values
		ArrayList<Float> valuesIncentive = new ArrayList<Float>();
		
		// save the values to the array of incentives
		BigDecimal valueParam = new BigDecimal("1.5");
		BigDecimal step = new BigDecimal("0.1");		
		int k = 0;
		while (valueParam.compareTo(new BigDecimal(0)) > -1 ){	
				    	
			valuesIncentive.add(k, valueParam.floatValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}
		
	    Controller controller = new Controller (_params, _paramsFile);

	    for (int i = 0; i < valuesIncentive.size(); i++ ) {
		   	    	
    		// save the current percapita incentive value	    	
	    	_params.setPerCapitaIncentive (valuesIncentive.get(i));

	        System.out.println("-> OAT for parameter percapita incentive of " + valuesIncentive.get(i));

			log.log(Level.FINE, "\n****** Running Monte-Carlo simulation for OAT configuration: perCapitaIncentive = " + 
					_params.getPerCapitaIncentive() + " \n");
		
			RunStats stats;

			long time1 = System.currentTimeMillis ();
			
	 		// running the model with the MC simulations
	 		stats = controller.runModel();		

	 		long  time2  = System.currentTimeMillis( );
	 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the simulation");

	 		// calculate the stats for this run and set the name of this experiment
	 		stats.setExpName("perCapitaIncentive;" + _params.getPerCapitaIncentive());		    	
	 		stats.calcAllStats();

			PrintWriter out = new PrintWriter(System.out, true);
			_params.printParameters(out);
			 
	 		// print the stats in the screen 		
	        System.out.println("\n****** Stats of this OAT configuration ******\n");
	 		stats.printSummaryStats(out, false);
	 		stats.printSummaryStatsByAveragingLastQuartile(out, false);

			// print the stats into a file
			System.out.println("\n****** Stats of this perCapitaIncentive OAT onfiguration also saved into a file ******\n");
			
			PrintWriter printWriter;
	         
	 		try {
	 			
	 			// print all the runs in a file 			
	 			printWriter = new PrintWriter (new FileOutputStream(fileAllMC, true));
	 			
	 			if ( fileAllMC.exists() && !fileAllMC.isDirectory() )
	 		        stats.appendAllStats(printWriter);		 		        
	 		    else
		 			stats.printAllStats(printWriter, false);		 		  
	 		    
	 	        printWriter.close ();       	
	 	        
	 	        // print the summarized MC runs in a file
	 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRuns, true));
	 	        
	 	       if ( fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory() )
	 	    	    stats.appendSummaryStats(printWriter);		 		        
	 		    else		 		    	
	 		    	stats.printSummaryStats(printWriter, false);
	 		    		 				 			
	 	        printWriter.close (); 
	 	        
	 	        // print all the runs in a file 			
	 			printWriter = new PrintWriter (new FileOutputStream(fileAllMCLQ, true));
	 			
	 			if ( fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory() )
		 			stats.printAllStatsByAveragingLastQuartile(printWriter, true);		 		 
	 		    else
		 			stats.printAllStatsByAveragingLastQuartile(printWriter, false);		 		  
	 		    
	 	        printWriter.close ();       	
	 	        
	 	        // print the summarized MC runs in a file
	 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRunsLQ, true));
	 	        
	 	       if ( fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory() )
	 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, true);
	 		    else		 		    	
	 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);
	 		    		 				 			
	 	        printWriter.close ();  
	 	        
	 		} catch (FileNotFoundException e) {
	 			
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 			
	 		    log.log( Level.SEVERE, e.toString(), e );
	 		} 
    	}
    	
    }	
	
	
	/**
	 * Static function to run a SA (OAT) for per capita incentive and reward weight
	 * 
	 */	
	public static void runSA_perCapitaIncentive_Reward (ModelParameters _params, String _paramsFile, 
			File fileAllMC, File fileSummaryMCRuns, File fileAllMCLQ, File fileSummaryMCRunsLQ) {

		// create output files in case they exist as we will append the simulation contents
		
		if (fileAllMC.exists() && !fileAllMC.isDirectory()) {
			fileAllMC.delete();
		}
		
		if (fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory()) {
			fileSummaryMCRuns.delete();
		}
		
		if (fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory()) {
			fileAllMCLQ.delete();
		}
		
		if (fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory()) {
			fileSummaryMCRunsLQ.delete();
		}
		
				
		// *********************  Arrays
				
		// create the arrays with the percapita incentive values
		ArrayList<Float> valuesIncentive = new ArrayList<Float>();
		
		// save the values to the array of incentives
		BigDecimal valueParam = new BigDecimal("1.5");
		BigDecimal step = new BigDecimal("0.1");		
		int k = 0;
		while (valueParam.compareTo(new BigDecimal(0)) > -1 ){	
				    	
			valuesIncentive.add(k, valueParam.floatValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}
		
		// *********************  Array with the reward weights
			
		// create the arrays with the reward weight values
		ArrayList<Float> valuesRewardWeight = new ArrayList<Float>();
		
		// save the values to the array of ratios
		valueParam = new BigDecimal("1");
		step = new BigDecimal("0.05");		
		k = 0;
		while (valueParam.compareTo(new BigDecimal(0)) > -1 ){	
				    	
			valuesRewardWeight.add(k, valueParam.floatValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}
				
				
	    Controller controller = new Controller (_params, _paramsFile);

	    for (int i = 0; i < valuesIncentive.size(); i++ ) {

		    for (int j = 0; j < valuesRewardWeight.size(); j++ ) {
	    		    		
	    		// set the values to the params	for the SA	
		    	_params.setPerCapitaIncentive (valuesIncentive.get(i));
		    	_params.setRewardWeight (valuesRewardWeight.get(j));

		        System.out.println("-> OAT for perCapitaIncentive = " + _params.getPerCapitaIncentive() 
		        + " rewardWeight = " + _params.getRewardWeight () );

				log.log(Level.FINE, "\n****** Running Monte-Carlo simulation for OAT configuration: perCapitaIncentive = " + 
						_params.getPerCapitaIncentive() + " rewardWeight = " + _params.getRewardWeight() + " \n");
		
				RunStats stats;

				long time1 = System.currentTimeMillis ();
				
		 		// running the model with the MC simulations
		 		stats = controller.runModel();		

		 		long  time2  = System.currentTimeMillis( );
		 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the OAT simulation");

		 		// calculate the stats for this run and set the name of this experiment
		 		stats.setExpName("perCapitaIncentive;" + _params.getPerCapitaIncentive() + ";rewardWeight;" 
		 		+ _params.getRewardWeight() );		    	
		 		
		 		stats.calcAllStats();

				PrintWriter out = new PrintWriter(System.out, true);
				_params.printParameters(out);
				 
		 		// print the stats in the screen 		
		        System.out.println("\n****** Stats of this OAT configuration ******\n");
		 		stats.printSummaryStats (out, false);
		 		stats.printSummaryStatsByAveragingLastQuartile(out, false);

				// print the stats into a file
				System.out.println("\n****** Stats of this OAT configuration also saved into a file ******\n");
				
				PrintWriter printWriter;
		         
		 		try {
		 			
		 			// print all the runs in a file 			
		 			printWriter = new PrintWriter (new FileOutputStream(fileAllMC, true));
		 			
		 			if ( fileAllMC.exists() && !fileAllMC.isDirectory() )
		 		        stats.appendAllStats (printWriter);		 		        
		 		    else
			 			stats.printAllStats (printWriter, false);	
		 	        printWriter.close ();       	
		 	        
		 	        // print the summarized MC runs in a file
		 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRuns, true));
		 	        
		 	        if ( fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory() )
		 	    	    stats.appendSummaryStats (printWriter);		 		        
		 		    else		 		    	
		 		    	stats.printSummaryStats (printWriter, false);	
		 	        printWriter.close ();    
		 	    
		 	        // print all the runs in a file 			
		 			printWriter = new PrintWriter (new FileOutputStream(fileAllMCLQ, true));
		 			
		 			if ( fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory() )
			 			stats.printAllStatsByAveragingLastQuartile(printWriter, true);	      
		 		    else
			 			stats.printAllStatsByAveragingLastQuartile(printWriter, false);	
		 	        printWriter.close ();       	
		 	        
		 	        // print the summarized MC runs in a file
		 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRunsLQ, true));
		 	        
		 	        if ( fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory() )
		 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, true);	
		 		    else		 		    	
		 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);	
		 	        printWriter.close ();    
		 	        
		 		} catch (FileNotFoundException e) {
		 			
		 			// TODO Auto-generated catch block
		 			e.printStackTrace();
		 			
		 		    log.log( Level.SEVERE, e.toString(), e );
		 		} 
	    	
		    }
	    }	    					
		
	}
	
	/**
	 * Static function to run a SA (OAT) for tourist discomfort and additional cost for the stakeholder
	 * 
	 */	
	public static void runSA_touristDiscomfort_stakeholderCost (ModelParameters _params, String _paramsFile, 
			File fileAllMC, File fileSummaryMCRuns, File fileAllMCLQ, File fileSummaryMCRunsLQ) {

		// create output files in case they exist as we will append the simulation contents
		
		if (fileAllMC.exists() && !fileAllMC.isDirectory()) {
			fileAllMC.delete();
		}
		
		if (fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory()) {
			fileSummaryMCRuns.delete();
		}
		
		if (fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory()) {
			fileAllMCLQ.delete();
		}
		
		if (fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory()) {
			fileSummaryMCRunsLQ.delete();
		}
		
				
		// *********************  Arrays
		
		// create the arrays with the stakeholder cost values
		ArrayList<Float> valuesStakeholderCost = new ArrayList<Float>();

		// save the values to the array of ratios
		int minimumValue = 0;								// minimum value for the SA		
		BigDecimal valueParam = new BigDecimal("1");		// maximum value for the SA
		BigDecimal step = new BigDecimal("0.1");			// step value for the SA	
			
		int k = 0;
		while (valueParam.compareTo(new BigDecimal(minimumValue)) > -1 ){					    	
			valuesStakeholderCost.add(k, valueParam.floatValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}
		
		// *********************  Array with the tourist discomfort values 
		
		// create the arrays with the touristDiscomfort values
		ArrayList<Float> valuesTouristDiscomfort = new ArrayList<Float>();
		
		// save the values to the array of ratios
		minimumValue = 0;								// minimum value for the SA		
		valueParam = new BigDecimal("1");			// maximum value for the SA
		step = new BigDecimal("0.1");				// step value for the SA	
		
		k = 0;
		while (valueParam.compareTo(new BigDecimal(minimumValue)) > -1 ){					    	
			valuesTouristDiscomfort.add(k, valueParam.floatValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}
				
				
	    Controller controller = new Controller (_params, _paramsFile);

	    for (int i = 0; i < valuesStakeholderCost.size(); i++ ) {

		    for (int j = 0; j < valuesTouristDiscomfort.size(); j++ ) {
	    		    		
	    		// set the values to the params	for the SA	
		    	_params.setStakeholderCost(valuesStakeholderCost.get(i));
		    	_params.setTouristDiscomfort(valuesTouristDiscomfort.get(j));

		        System.out.println("-> OAT for touristDiscomfort = " + _params.getTouristDiscomfort() 
		        + " stakeholderCost = " + _params.getStakeholderCost() );

				log.log(Level.FINE, "\n****** Running Monte-Carlo simulation for OAT configuration: touristDiscomfort = " + 
						_params.getTouristDiscomfort() + " stakeholderCost = " + _params.getStakeholderCost() + " \n");
		
				RunStats stats;

				long time1 = System.currentTimeMillis ();
				
		 		// running the model with the MC simulations
		 		stats = controller.runModel();		

		 		long  time2  = System.currentTimeMillis( );
		 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the OAT simulation");

		 		// calculate the stats for this run and set the name of this experiment
		 		stats.setExpName("touristDiscomfort;" + _params.getTouristDiscomfort() + ";stakeholderCost;" 
		 		+ _params.getStakeholderCost() );		    	
		 		
		 		stats.calcAllStats();

				PrintWriter out = new PrintWriter(System.out, true);
				_params.printParameters(out);
				 
		 		// print the stats in the screen 		
		        System.out.println("\n****** Stats of this OAT configuration ******\n");
		 		stats.printSummaryStats (out, false);
		 		stats.printSummaryStatsByAveragingLastQuartile(out, false);

				// print the stats into a file
				System.out.println("\n****** Stats of this OAT configuration also saved into a file ******\n");
				
				PrintWriter printWriter;
		         
		 		try {
		 			
		 			// print all the runs in a file 			
		 			printWriter = new PrintWriter (new FileOutputStream(fileAllMC, true));
		 			
		 			if ( fileAllMC.exists() && !fileAllMC.isDirectory() )
		 		        stats.appendAllStats (printWriter);		 		        
		 		    else
			 			stats.printAllStats (printWriter, false);	
		 	        printWriter.close ();       	
		 	        
		 	        // print the summarized MC runs in a file
		 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRuns, true));
		 	        
		 	        if ( fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory() )
		 	    	    stats.appendSummaryStats (printWriter);		 		        
		 		    else		 		    	
		 		    	stats.printSummaryStats (printWriter, false);	
		 	        printWriter.close ();    
		 	    
		 	        // print all the runs in a file 			
		 			printWriter = new PrintWriter (new FileOutputStream(fileAllMCLQ, true));
		 			
		 			if ( fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory() )
			 			stats.printAllStatsByAveragingLastQuartile(printWriter, true);	      
		 		    else
			 			stats.printAllStatsByAveragingLastQuartile(printWriter, false);	
		 	        printWriter.close ();       	
		 	        
		 	        // print the summarized MC runs in a file
		 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRunsLQ, true));
		 	        
		 	        if ( fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory() )
		 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, true);	
		 		    else		 		    	
		 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);	
		 	        printWriter.close ();    
		 	        
		 		} catch (FileNotFoundException e) {
		 			
		 			// TODO Auto-generated catch block
		 			e.printStackTrace();
		 			
		 		    log.log( Level.SEVERE, e.toString(), e );
		 		} 
	    	
		    }
	    }	    					
		
	}
		
	
	/**
	 * Static function to run a SA (OAT) for touristDiscomfort and reward weight
	 * 
	 */	
	public static void runSA_touristDiscomfort_Reward (ModelParameters _params, String _paramsFile, 
			File fileAllMC, File fileSummaryMCRuns, File fileAllMCLQ, File fileSummaryMCRunsLQ) {

		// create output files in case they exist as we will append the simulation contents
		
		if (fileAllMC.exists() && !fileAllMC.isDirectory()) {
			fileAllMC.delete();
		}
		
		if (fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory()) {
			fileSummaryMCRuns.delete();
		}
		
		if (fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory()) {
			fileAllMCLQ.delete();
		}
		
		if (fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory()) {
			fileSummaryMCRunsLQ.delete();
		}
		
				
		// *********************  Arrays
				
		// create the arrays with the touristDiscomfort values
		ArrayList<Float> valuesTau = new ArrayList<Float>();
		
		// save the values to the array of the tau values
		BigDecimal valueParam = new BigDecimal("1");
		BigDecimal step = new BigDecimal("0.1");		
		int k = 0;
		while (valueParam.compareTo(new BigDecimal(0)) > -1 ){	
				    	
			valuesTau.add(k, valueParam.floatValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}
		
		// *********************  Array with the reward weights
			
		// create the arrays with the reward weight values
		ArrayList<Float> valuesRewardWeight = new ArrayList<Float>();
		
		// save the values to the array of ratios
		valueParam = new BigDecimal("1");
		step = new BigDecimal("0.05");		
		k = 0;
		while (valueParam.compareTo(new BigDecimal(0)) > -1 ){	
				    	
			valuesRewardWeight.add(k, valueParam.floatValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}
				
				
	    Controller controller = new Controller (_params, _paramsFile);

	    for (int i = 0; i < valuesTau.size(); i++ ) {

		    for (int j = 0; j < valuesRewardWeight.size(); j++ ) {
	    		    		
	    		// set the values to the params	for the SA	
		    	_params.setTouristDiscomfort (valuesTau.get(i));
		    	_params.setRewardWeight (valuesRewardWeight.get(j));

		        System.out.println("-> OAT for touristDiscomfort = " + _params.getTouristDiscomfort () 
		        + " rewardWeight = " + _params.getRewardWeight () );

				log.log(Level.FINE, "\n****** Running Monte-Carlo simulation for OAT configuration: touristDiscomfort = " + 
						_params.getTouristDiscomfort() + " rewardWeight = " + _params.getRewardWeight() + " \n");
		
				RunStats stats;

				long time1 = System.currentTimeMillis ();
				
		 		// running the model with the MC simulations
		 		stats = controller.runModel();		

		 		long  time2  = System.currentTimeMillis( );
		 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the OAT simulation");

		 		// calculate the stats for this run and set the name of this experiment
		 		stats.setExpName("touristDiscomfort;" + _params.getTouristDiscomfort() + ";rewardWeight;" 
		 		+ _params.getRewardWeight() );		    	
		 		
		 		stats.calcAllStats();

				PrintWriter out = new PrintWriter(System.out, true);
				_params.printParameters(out);
				 
		 		// print the stats in the screen 		
		        System.out.println("\n****** Stats of this OAT configuration ******\n");
		 		stats.printSummaryStats (out, false);
		 		stats.printSummaryStatsByAveragingLastQuartile(out, false);

				// print the stats into a file
				System.out.println("\n****** Stats of this OAT configuration also saved into a file ******\n");
				
				PrintWriter printWriter;
		         
		 		try {
		 			
		 			// print all the runs in a file 			
		 			printWriter = new PrintWriter (new FileOutputStream(fileAllMC, true));
		 			
		 			if ( fileAllMC.exists() && !fileAllMC.isDirectory() )
		 		        stats.appendAllStats (printWriter);		 		        
		 		    else
			 			stats.printAllStats (printWriter, false);	
		 	        printWriter.close ();       	
		 	        
		 	        // print the summarized MC runs in a file
		 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRuns, true));
		 	        
		 	        if ( fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory() )
		 	    	    stats.appendSummaryStats (printWriter);		 		        
		 		    else		 		    	
		 		    	stats.printSummaryStats (printWriter, false);	
		 	        printWriter.close ();    
		 	    
		 	        // print all the runs in a file 			
		 			printWriter = new PrintWriter (new FileOutputStream(fileAllMCLQ, true));
		 			
		 			if ( fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory() )
			 			stats.printAllStatsByAveragingLastQuartile(printWriter, true);	      
		 		    else
			 			stats.printAllStatsByAveragingLastQuartile(printWriter, false);	
		 	        printWriter.close ();       	
		 	        
		 	        // print the summarized MC runs in a file
		 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRunsLQ, true));
		 	        
		 	        if ( fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory() )
		 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, true);	
		 		    else		 		    	
		 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);	
		 	        printWriter.close ();    
		 	        
		 		} catch (FileNotFoundException e) {
		 			
		 			// TODO Auto-generated catch block
		 			e.printStackTrace();
		 			
		 		    log.log( Level.SEVERE, e.toString(), e );
		 		} 
	    	
		    }
	    }	    					
		
	}
	
	/**
	 * Static function to run a SA (OAT) for touristCost or epsilon and reward weight
	 * 
	 */	
	public static void runSA_touristCost_Reward (ModelParameters _params, String _paramsFile, 
			File fileAllMC, File fileSummaryMCRuns, File fileAllMCLQ, File fileSummaryMCRunsLQ) {

		// create output files in case they exist as we will append the simulation contents
		
		if (fileAllMC.exists() && !fileAllMC.isDirectory()) {
			fileAllMC.delete();
		}
		
		if (fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory()) {
			fileSummaryMCRuns.delete();
		}
		
		if (fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory()) {
			fileAllMCLQ.delete();
		}
		
		if (fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory()) {
			fileSummaryMCRunsLQ.delete();
		}
		
				
		// *********************  Arrays
				
		// create the arrays with the touristCost values
		ArrayList<Float> valuesEpsilon = new ArrayList<Float>();
		
		// save the values to the array of the tau values
		BigDecimal valueParam = new BigDecimal("2");
		BigDecimal step = new BigDecimal("0.1");		
		int k = 0;
		while (valueParam.compareTo(new BigDecimal(1)) > -1 ){	
				    	
			valuesEpsilon.add(k, valueParam.floatValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}
		
		// *********************  Array with the reward weights
			
		// create the arrays with the reward weight values
		ArrayList<Float> valuesRewardWeight = new ArrayList<Float>();
		
		// save the values to the array of ratios
		valueParam = new BigDecimal("1");
		step = new BigDecimal("0.05");		
		k = 0;
		while (valueParam.compareTo(new BigDecimal(0)) > -1 ){	
				    	
			valuesRewardWeight.add(k, valueParam.floatValue());
			valueParam = valueParam.subtract(step);
			k ++;
		}
				
				
	    Controller controller = new Controller (_params, _paramsFile);

	    for (int i = 0; i < valuesEpsilon.size(); i++ ) {

		    for (int j = 0; j < valuesRewardWeight.size(); j++ ) {
	    		    		
	    		// set the values to the params	for the SA	
		    	_params.setTouristCost (valuesEpsilon.get(i));
		    	_params.setRewardWeight (valuesRewardWeight.get(j));

		        System.out.println("-> OAT for touristCost = " + _params.getTouristCost () 
		        + " rewardWeight = " + _params.getRewardWeight () );

				log.log(Level.FINE, "\n****** Running Monte-Carlo simulation for OAT configuration: touristCost = " + 
						_params.getTouristCost() + " rewardWeight = " + _params.getRewardWeight() + " \n");
		
				RunStats stats;

				long time1 = System.currentTimeMillis ();
				
		 		// running the model with the MC simulations
		 		stats = controller.runModel();		

		 		long  time2  = System.currentTimeMillis( );
		 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the OAT simulation");

		 		// calculate the stats for this run and set the name of this experiment
		 		stats.setExpName("touristCost;" + _params.getTouristCost() + ";rewardWeight;" 
		 		+ _params.getRewardWeight() );		    	
		 		
		 		stats.calcAllStats();

				PrintWriter out = new PrintWriter(System.out, true);
				_params.printParameters(out);
				 
		 		// print the stats in the screen 		
		        System.out.println("\n****** Stats of this OAT configuration ******\n");
		 		stats.printSummaryStats (out, false);
		 		stats.printSummaryStatsByAveragingLastQuartile(out, false);

				// print the stats into a file
				System.out.println("\n****** Stats of this OAT configuration also saved into a file ******\n");
				
				PrintWriter printWriter;
		         
		 		try {
		 			
		 			// print all the runs in a file 			
		 			printWriter = new PrintWriter (new FileOutputStream(fileAllMC, true));
		 			
		 			if ( fileAllMC.exists() && !fileAllMC.isDirectory() )
		 		        stats.appendAllStats (printWriter);		 		        
		 		    else
			 			stats.printAllStats (printWriter, false);	
		 	        printWriter.close ();       	
		 	        
		 	        // print the summarized MC runs in a file
		 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRuns, true));
		 	        
		 	        if ( fileSummaryMCRuns.exists() && !fileSummaryMCRuns.isDirectory() )
		 	    	    stats.appendSummaryStats (printWriter);		 		        
		 		    else		 		    	
		 		    	stats.printSummaryStats (printWriter, false);	
		 	        printWriter.close ();    
		 	    
		 	        // print all the runs in a file 			
		 			printWriter = new PrintWriter (new FileOutputStream(fileAllMCLQ, true));
		 			
		 			if ( fileAllMCLQ.exists() && !fileAllMCLQ.isDirectory() )
			 			stats.printAllStatsByAveragingLastQuartile(printWriter, true);	      
		 		    else
			 			stats.printAllStatsByAveragingLastQuartile(printWriter, false);	
		 	        printWriter.close ();       	
		 	        
		 	        // print the summarized MC runs in a file
		 			printWriter = new PrintWriter (new FileOutputStream(fileSummaryMCRunsLQ, true));
		 	        
		 	        if ( fileSummaryMCRunsLQ.exists() && !fileSummaryMCRunsLQ.isDirectory() )
		 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, true);	
		 		    else		 		    	
		 		    	stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);	
		 	        printWriter.close ();    
		 	        
		 		} catch (FileNotFoundException e) {
		 			
		 			// TODO Auto-generated catch block
		 			e.printStackTrace();
		 			
		 		    log.log( Level.SEVERE, e.toString(), e );
		 		} 
	    	
		    }
	    }	    					
		
	}
	
	
}
