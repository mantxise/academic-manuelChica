package view;


import java.io.PrintWriter;

import org.apache.commons.math3.stat.descriptive.*;
import java.util.Locale;


/** 
 * StatsRun for the EvoGame for tourists-stakeholders
 * 
 * This class will store all the results for the MonteCarlo simulation.
 * It will also update the stats and error metrics w.r.t. the historical data.
 * 
 * @author mchica
 * @date 2021/04/15
 * @place Las Palmas GC
 *
 */
public class RunStats {

	private int numberRuns;				// number of MC simulations

	private int numberSteps;			// number of steps simulation

	// fields for  Tourist Cooperators members of the population (time series)
	private int TC[][];			// all the TC members (each for run and step)
	private double avgTC[];			// average TC over all the runs for each step
	private double stdTC[];			// std TC over all the runs for each step
	private double[] min_TC;
	private double[] max_TC;
	
	
	// fields for Tourist Defectors members of the population (time series)
	private int TD[][];				// all the TD members (each for run and step)
	private double avgTD[];			// average TD over all the runs for each step
	private double stdTD[];			// std TD over all the runs for each step
	private double[] min_TD;
	private double[] max_TD;
	
	// fields for Stakeholders Cooperators members of the population (time series)
	private int SC[][];			// all the SC members (each for run and step)
	private double avgSC[];			// average SC over all the runs for each step
	private double stdSC[];			// std SC over all the runs for each step
	private double[] min_SC;
	private double[] max_SC;

	// fields for Stakeholders Defectors  members of the population (time series)
	private int SD[][];			// all the SD members (each for run and step)
	private double avgSD[];			// average SD over all the runs for each step
	private double stdSD[];			// std SD over all the runs for each step
	private double[] min_SD;
	private double[] max_SD;
	
	
	
	// fields for netWealth
	private float netWealth[][];			// all the netWealth metrics (each for run and step)
	private double avgnetWealth[];			// average over all the runs for each step
	private double stdnetWealth[];			// std over all the runs for each step
	private double[] min_netWealth;
	private double[] max_netWealth;
	
	// fields for changes in the agents' strategies
	private int strategyChanges[][];			// the number of strategy changes in the agentes (each for run and step)
	private double avgStrategyChanges[];			// average of the number of strategy changes over all the runs for each step
	private double stdStrategyChanges[];			// std of the number of strategy changes over all the runs for each step
	private double[] min_StrategyChanges;		// min of the number of strategy changes over all the runs for each step
	private double[] max_StrategyChanges;		// max of the number of strategy changes over all the runs for each step
				
	private String expName;				// the key name of this experiment (all the MC runs)
	
	
	// ########################################################################	
	// Methods/Functions 	
	// ########################################################################

	//--------------------------- Getters and setters ---------------------------//


	/**
	 * @return the numberRuns
	 */
	public int getNumberRuns() {
		return numberRuns;
	}

	/**
	 * @param numberRuns the numberRuns to set
	 */
	public void setNumberRuns(int _numberRuns) {
		this.numberRuns = _numberRuns;
	}

	/**
	 * @return the stdSD
	 */
	public double[] getStdSD() {
		return stdSD;
	}

	/**
	 * @param stdSD the stdSD to set
	 */
	public void setStdSD(double _stdSD[]) {
		this.stdSD= _stdSD;
	}

	/**
	 * @return the avgSD
	 */
	public double[] getAvgSD() {
		return avgSD;
	}

	/**
	 * @param _avgSD the avgSDP to set
	 */
	public void setAvgSD(double _avgSD[]) {
		this.avgSD = _avgSD;
	}

	/**
	 * @return the SD
	 */
	public int[][] getSD() {
		return SD;
	}

	/**
	 * @param chebyshev the UP to set
	 */
	public void setSD(int _SD[][]) {
		this.SD = _SD;
	}

	/**
	 * @return the stdStrategyChanges
	 */
	public double[] getStdStrategyChanges() {
		return stdStrategyChanges;
	}

	/**
	 * @param stdStrategyChanges the stdStrategyChanges to set
	 */
	public void setStdStrategyChanges(double[] _stdStrategyChanges) {
		this.stdStrategyChanges = _stdStrategyChanges;
	}

	/**
	 * @return the avgStrategyChanges
	 */
	public double[] getAvgStrategyChanges() {
		return avgStrategyChanges;
	}

	/**
	 * @param the avgStrategyChanges to set
	 */
	public void setAvgStrategyChanges(double _avgStrategyChanges[]) {
		this.avgStrategyChanges = _avgStrategyChanges;
	}

	/**
	 * @return the strategyChanges
	 */
	public int[][] getStrategyChanges() {
		return strategyChanges;
	}

	/**
	 * @param _StrategyChanges the StrategyChanges to set
	 */
	public void setStrategyChanges(int _StrategyChanges[][]) {
		this.strategyChanges = _StrategyChanges;
	}
	
	/**
	 * @return the stdTC
	 */
	public double[] getStdTC() {
		return stdTC;
	}

	/**
	 * @param stdTC the stdTC to set
	 */
	public void setStdTC(double[] _stdTC) {
		this.stdTC = _stdTC;
	}

	/**
	 * @return the avgTC
	 */
	public double[] getAvgTC() {
		return avgTC;
	}

	/**
	 * @param avgTC the avgTC to set
	 */
	public void setAvgTC(double _avgTC[]) {
		this.avgTC = _avgTC;
	}

	/**
	 * @return the TC
	 */
	public int[][] getTC() {
		return TC;
	}

	/**
	 * @param _TC the TC to set
	 */
	public void setTC(int _TC[][]) {
		this.TC = _TC;
	}

	/**
	 * @return the stdnetWealth
	 */
	public double[] getStdnetWealth() {
		return stdnetWealth;
	}

	/**
	 * @param stdnetWealth the stdnetWealth to set
	 */
	public void setStdnetWealth(double[] _stdnetWealth) {
		this.stdnetWealth = _stdnetWealth;
	}

	/**
	 * @return the avgnetWealth
	 */
	public double[] getAvgnetWealth() {
		return avgnetWealth;
	}
	
	public String getExpName() {
		return expName;
	}

	public void setExpName(String expName) {
		this.expName = expName;
	}

	/**
	 * @param avgnetWealth the avgnetWealth to set
	 */
	public void setAvgnetWealth(double[] _avgnetWealth) {
		this.avgnetWealth = _avgnetWealth;
	}

	/**
	 * @return the netWealth
	 */
	public float[][] getnetWealth() {
		return netWealth;
	}

	/**
	 * @param netWealth the netWealth to set for run _numberOfRun
	 */
	public void setnetWealthForRun(int _numberOfRun, float _netWealth[]) {
		
		for (int i = 0; i < this.numberSteps; i++)
			this.netWealth[_numberOfRun][i] = _netWealth[i];
	}
	
	/**
	 * @param _TD TD value to set for run _numberOfRun
	 */
	public void setTDForRun(int _numberOfRun, int _TD[]) {
		
		for (int i = 0; i < this.numberSteps; i++)
			this.TD[_numberOfRun][i] = _TD[i];
		
	}

	/**
	 * @param _SD SD value to set for run _numberOfRun
	 */
	public void setSDForRun(int _numberOfRun, int _SD[]) {
		
		for (int i = 0; i < this.numberSteps; i++)
			this.SD[_numberOfRun][i] = _SD[i];
		
	}

	/**
	 * @param _TC TC value to set for run _numberOfRun
	 */
	public void setTCForRun(int _numberOfRun, int _TC[]) {
		
		for (int i = 0; i < this.numberSteps; i++)
			this.TC[_numberOfRun][i] = _TC[i];
		
	}
	
	/**
	 * @param _SC SC value to set for run _numberOfRun
	 */
	public void setSCForRun(int _numberOfRun, int _SC[]) {
		
		for (int i = 0; i < this.numberSteps; i++)
			this.SC[_numberOfRun][i] = _SC[i];
		
	}
	
	/**
	 * @param strategyChanges value to set for run _numberOfRun
	 */
	public void setStrategyChangesForRun(int _numberOfRun, int _strategyChanges[]) {
		
		for (int i = 0; i < this.numberSteps; i++)
			this.strategyChanges[_numberOfRun][i] = _strategyChanges[i];
		
	}
		
	/**
	 * @param netWealth the netWealth to set
	 */
	public void setnetWealth(float _netWealth[][]) {
		
		this.netWealth = _netWealth;
	}
	
	/**
	 * @return the stdTD
	 */
	public double[] getStdTD() {
		return stdTD;
	}

	/**
	 * @param stdTD the stdTD to set
	 */
	public void setStdTD(double[] _stdTD) {
		this.stdTD = _stdTD;
	}

	/**
	 * @return the avgTD
	 */
	public double[] getAvgTD() {
		return avgTD;
	}

	/**
	 * @param avgTD the avgTD to set
	 */
	public void setAvgTD(double _avgTD[]) {
		this.avgTD = _avgTD;
	}

	/**
	 * @return the TD
	 */
	public int[][] getTD() {
		return TD;
	}

	/**
	 * @param TD the TD to set
	 */
	public void setTD(int _TD[][]) {
		this.TD = _TD;
	}
	
	/**
	 * @return the numberSteps
	 */
	public int getNumberSteps() {
		return numberSteps;
	}

	/**
	 * @param numberSteps the numberSteps to set
	 */
	public void setNumberSteps(int _numberSteps) {
		this.numberSteps = _numberSteps;
	}
	
    
	//--------------------------- Constructor ---------------------------//
	/**
	 * constructor of Stats
	 * @param _nRuns
	 */
	public RunStats (int _nRuns, int _nSteps){

		numberRuns = _nRuns;
		numberSteps = _nSteps;
		
		// allocating space for metrics
		this.TD = new int[_nRuns][_nSteps];
		this.SD = new int[_nRuns][_nSteps];
		this.TC = new int[_nRuns][_nSteps];
		this.SC = new int[_nRuns][_nSteps];
		this.netWealth = new float[_nRuns][_nSteps];
		this.strategyChanges = new int[_nRuns][_nSteps];

		this.avgTD = new double[_nSteps];	
		this.stdTD = new double[_nSteps];
		this.min_TD = new double[_nSteps];	
		this.max_TD = new double[_nSteps];

		this.avgSD = new double[_nSteps];	
		this.stdSD = new double[_nSteps];
		this.min_SD = new double[_nSteps];	
		this.max_SD = new double[_nSteps];

		this.avgTC = new double[_nSteps];	
		this.stdTC = new double[_nSteps];
		this.min_TC = new double[_nSteps];	
		this.max_TC = new double[_nSteps];

		this.avgSC = new double[_nSteps];	
		this.stdSC = new double[_nSteps];
		this.min_SC = new double[_nSteps];	
		this.max_SC = new double[_nSteps];
		
		this.avgnetWealth = new double[_nSteps];	
		this.stdnetWealth = new double[_nSteps];
		this.min_netWealth = new double[_nSteps];	
		this.max_netWealth = new double[_nSteps];

		this.avgStrategyChanges = new double[_nSteps];	
		this.stdStrategyChanges = new double[_nSteps];
		this.min_StrategyChanges = new double[_nSteps];	
		this.max_StrategyChanges = new double[_nSteps];
		
	}
		
	/**
	 * This method prints all the steps values (avg and stdev of the MC RUNS) to a stream file 
	 * (or to the console)
	 * @param writer that is opened before calling the function
	 */
	public void printTimeSeriesStats(PrintWriter writer) {
		
		writer.println("step;netWealthAvg;netWealthStd;netWealthMin;netWealthMax;"
				+ "TCAvg;TCStd;TCMin;TCMax;TDAvg;TDStd;TDMin;TDMax;SCAvg;SCStd;SCMin;SCMax;SDAvg;SDStd;SDMin;SDMax;" +
				"strategyChangesAvg;strategyChangesStd;strategyChangesMin;strategyChangesMax;");
		
		for (int i = 0; i < this.numberSteps; i++) {
			
			String toPrint = i + ";" 
					+ String.format(Locale.US, "%.4f", this.avgnetWealth[i]) + ";" + String.format(Locale.US, "%.4f", this.stdnetWealth[i]) + ";" 
					+ String.format(Locale.US, "%.4f", this.min_netWealth[i]) + ";" + String.format(Locale.US, "%.4f", this.max_netWealth[i]) + ";"
					
					+ String.format(Locale.US, "%.4f", this.avgTC[i]) + ";" + String.format(Locale.US, "%.4f", this.stdTC[i]) + ";" 
					+ String.format(Locale.US, "%.4f", this.min_TC[i]) + ";" + String.format(Locale.US, "%.4f", this.max_TC[i]) + ";"
					
					+ String.format(Locale.US, "%.4f", this.avgTD[i]) + ";" + String.format(Locale.US, "%.4f", this.stdTD[i]) + ";" 
					+ String.format(Locale.US, "%.4f", this.min_TD[i]) + ";" + String.format(Locale.US, "%.4f", this.max_TD[i]) + ";"
					
					+ String.format(Locale.US, "%.4f", this.avgSC[i]) + ";" + String.format(Locale.US, "%.4f", this.stdSC[i]) + ";" 
					+ String.format(Locale.US, "%.4f", this.min_SC[i]) + ";"+ String.format(Locale.US, "%.4f", this.max_SC[i]) + ";"
					
					+ String.format(Locale.US, "%.4f", this.avgSD[i]) + ";" + String.format(Locale.US, "%.4f", this.stdSD[i]) + ";" 
					+ String.format(Locale.US, "%.4f", this.min_SD[i]) + ";"+ String.format(Locale.US, "%.4f", this.max_SD[i]) + ";"
					
					+ String.format(Locale.US, "%.4f", this.avgStrategyChanges[i]) + ";" + String.format(Locale.US, "%.4f", this.stdStrategyChanges[i]) + ";" 
					+ String.format(Locale.US, "%.4f", this.min_StrategyChanges[i]) + ";" + String.format(Locale.US, "%.4f", this.max_StrategyChanges[i]) + ";\n";
					
			writer.print (toPrint);
		}
			
	}
		

	/**
	 * This method prints summarized stats (avg and std of MC runs) to a stream file (or to the console)
	 * @append true if we append the line to an existing file, false if we destroy it first
	 * @param writer that is opened before calling the function
	 */
	public void printSummaryStats (PrintWriter writer, boolean append) {
		
		String toPrint = "keyNameExp;" + this.expName + ";netWealth;" 
				+ String.format(Locale.US, "%.4f", this.avgnetWealth[(this.numberSteps - 1)]) + ";" + 
				String.format(Locale.US, "%.4f", this.stdnetWealth[(this.numberSteps - 1)]) + ";TC;" 
				+ String.format(Locale.US, "%.4f", this.avgTC[(this.numberSteps - 1)]) + ";" + 
				String.format(Locale.US, "%.4f", this.stdTC[(this.numberSteps - 1)]) 	+ ";TD;" + 
				String.format(Locale.US, "%.4f", this.avgTD[(this.numberSteps - 1)]) + ";" + 
				String.format(Locale.US, "%.4f", this.stdTD[(this.numberSteps - 1)]) + ";SC;" 
				+ String.format(Locale.US, "%.4f", this.avgSC[(this.numberSteps - 1)]) + ";" + 
				String.format(Locale.US, "%.4f", this.stdSC[(this.numberSteps - 1)]) + ";SD;" 
				+ String.format(Locale.US, "%.4f", this.avgSD[(this.numberSteps - 1)]) + ";" + 
				String.format(Locale.US, "%.4f", this.stdSD[(this.numberSteps - 1)]) + ";strategyChanges;" 
				+ String.format(Locale.US, "%.4f", this.avgStrategyChanges[(this.numberSteps - 1)]) + ";" + 
				String.format(Locale.US, "%.4f", this.stdStrategyChanges[(this.numberSteps - 1)]) + ";";
		
		if (append) {
			writer.append (toPrint);
			writer.append("\n");
		} else {
			writer.println (toPrint);
		}					
	}
	
	/**
	 * This method prints (by appending to an existing file) the 
	 * summarized stats (avg and std of MC runs) to a stream file (or to the console)
	 * @param writer that is opened before calling the function
	 */
	public void appendSummaryStats (PrintWriter writer) {		
		printSummaryStats (writer, true);				
	}
	
	/**
	 * This method prints all the stats of the MC runs (by appending to an existing file) 
	 * to a stream file (or to the console)
	 * @param writer that is opened before calling the function
	 */
	public void appendAllStats (PrintWriter writer) {		
		printAllStats (writer, true);				
	}

	
	/**
	 * This method prints all the stats of the MC runs to a stream file (or to the console)
	 * @param writer that is opened before calling the function
	 * @append true if we append the line to an existing file, false if we destroy it first
	 */
	public void printAllStats (PrintWriter writer, boolean append) {
		 			
		for (int i = 0; i < this.numberRuns; i++) {
			
			String toPrint = "keyNameExp;" + this.expName + ";MCrun;" + i + ";netWealth;" + 
					String.format(Locale.US, "%.4f", this.netWealth[i][(this.numberSteps - 1)]) + ";TC;" 
				+  String.format("%d", this.TC[i][(this.numberSteps - 1)]) 
				+ ";TD;" + String.format("%d", this.TD[i][(this.numberSteps - 1)]) + ";SC;" 
				+ String.format("%d", this.SC[i][(this.numberSteps - 1)]) + ";SD;" 
						+ String.format("%d", this.SD[i][(this.numberSteps - 1)]) + ";strategyChanges;" 
				+ String.format("%d", this.strategyChanges[i][(this.numberSteps - 1)]) + ";\n";
		
			
			if (append) 	
				writer.append (toPrint);				
			else 					
				writer.print (toPrint);					
		}	
	}
	
	/**
	 * This method prints summarized stats of the last quartile of the simulation (avg and std of MC runs) 
	 * to a stream file (or to the console)
	 * @append true if we append the line to an existing file, false if we destroy it first
	 * @param writer that is opened before calling the function
	 */
	public void printSummaryStatsByAveragingLastQuartile (PrintWriter writer, boolean append) {
		
		double lastQuartileNW = 0.;
		double lastQuartileTP = 0.;
		double lastQuartileUP = 0.;
		double lastQuartileTC = 0.;
		double lastQuartileUC = 0.;
		double lastQuartileStrategyChanges = 0.;

		double lastQuartileNWStd = 0.;
		double lastQuartileTPStd = 0.;
		double lastQuartileUPStd = 0.;
		double lastQuartileTCStd = 0.;
		double lastQuartileUCStd = 0.;
		double lastQuartileStrategyChangesStd = 0.;
		
		// check the number of steps which means the last 25% of them
		int quartileSteps = (int) Math.round(0.25*this.numberSteps);
		
		for ( int j = 1; j <= quartileSteps; j++) {
			
			// averaging the MC outputs for the last quartile of the simulation
			lastQuartileNW += this.avgnetWealth[(this.numberSteps - j)];
			lastQuartileTP += this.avgTC[(this.numberSteps - j)];
			lastQuartileUP += this.avgTD[(this.numberSteps - j)];
			lastQuartileTC += this.avgSC[(this.numberSteps - j)];
			lastQuartileUC += this.avgSD[(this.numberSteps - j)];
			lastQuartileStrategyChanges += this.avgStrategyChanges[(this.numberSteps - j)];
			
			// averaging the MC stdev outputs for the last quartile of the simulation
			lastQuartileNWStd += this.stdnetWealth[(this.numberSteps - j)];
			lastQuartileTPStd += this.stdTC[(this.numberSteps - j)];
			lastQuartileUPStd += this.stdTD[(this.numberSteps - j)];
			lastQuartileTCStd += this.stdSC[(this.numberSteps - j)];
			lastQuartileUCStd += this.stdSD[(this.numberSteps - j)];
			lastQuartileStrategyChangesStd += this.stdStrategyChanges[(this.numberSteps - j)];			
			
		}

		lastQuartileNW /= quartileSteps;
		lastQuartileTP /= quartileSteps;
		lastQuartileUP /= quartileSteps;
		lastQuartileTC /= quartileSteps;
		lastQuartileUC /= quartileSteps;
		lastQuartileStrategyChanges /= quartileSteps;
		
		lastQuartileNWStd /= quartileSteps;
		lastQuartileTPStd /= quartileSteps;
		lastQuartileUPStd /= quartileSteps;
		lastQuartileTCStd /= quartileSteps;
		lastQuartileUCStd /= quartileSteps;
		lastQuartileStrategyChangesStd /= quartileSteps;
		
		String toPrint = "LQkeyNameExp;" + this.expName + ";netWealthLQ;" 
				+ String.format(Locale.US, "%.4f", lastQuartileNW) + ";" + String.format(Locale.US, "%.4f", lastQuartileNWStd) + ";TCLQ;" 
				+ String.format(Locale.US, "%.4f", lastQuartileTP) + ";" + String.format(Locale.US, "%.4f", lastQuartileTPStd) 
				+ ";TDLQ;" + String.format(Locale.US, "%.4f", lastQuartileUP) + ";" + String.format(Locale.US, "%.4f", lastQuartileUPStd) + ";SCLQ;" 
				+ String.format(Locale.US, "%.4f", lastQuartileTC) + ";" + String.format(Locale.US, "%.4f", lastQuartileTCStd) + ";SDLQ;" 
						+ String.format(Locale.US, "%.4f", lastQuartileUC) + ";" + String.format(Locale.US, "%.4f", lastQuartileUCStd) + ";strategyChangesLQ;" 
				+ String.format(Locale.US, "%.4f", lastQuartileStrategyChanges) + ";" + String.format(Locale.US, "%.4f", lastQuartileStrategyChangesStd) + ";";
				
		if (append) {
			writer.append (toPrint);
			writer.append("\n");
		} else {
			writer.println (toPrint);
		}	
			
	}
	
	
	/**
	 * This method prints all the averaging stats in the last quartile of the simulation for all 
	 * the MC runs to a stream file (or to the console)
	 * @param writer that is opened before calling the function
	 * @append true if we append the line to an existing file, false if we destroy it first
	 */
	public void printAllStatsByAveragingLastQuartile (PrintWriter writer, boolean append) {
		
		for ( int i = 0; i < this.numberRuns; i++) {
			
			double lastQuartileNW = 0.;
			double lastQuartileTP = 0.;
			double lastQuartileUP = 0.;
			double lastQuartileTC = 0.;
			double lastQuartileUC = 0.;
			double lastQuartileStrategyChanges = 0.;
			
			// check the number of steps which means the last 25% of them
			int quartileSteps = (int)Math.round(0.25*this.numberSteps);
			
			for ( int j = 1; j <= quartileSteps; j++) {
				lastQuartileNW += this.netWealth[i][(this.numberSteps - j)];
				lastQuartileTP += this.TC[i][(this.numberSteps - j)];
				lastQuartileUP += this.TD[i][(this.numberSteps - j)];
				lastQuartileTC += this.SC[i][(this.numberSteps - j)];
				lastQuartileUC += this.SD[i][(this.numberSteps - j)];
				lastQuartileStrategyChanges += this.strategyChanges[i][(this.numberSteps - j)];
			}

			lastQuartileNW /= quartileSteps;
			lastQuartileTP /= quartileSteps;
			lastQuartileUP /= quartileSteps;
			lastQuartileTC /= quartileSteps;
			lastQuartileUC /= quartileSteps;
			lastQuartileStrategyChanges /= quartileSteps;
			
			String toPrint = "LQKeyNameExp;" + this.expName + ";MCrun;" + i + ";netWealthLQ;" + 
					String.format(Locale.US, "%.4f", lastQuartileNW) + ";TCLQ;" 
					+  String.format(Locale.US, "%.4f", lastQuartileTP) 
					+ ";TDLQ;" + String.format(Locale.US, "%.4f", lastQuartileUP) + ";SCLQ;" 
					+ String.format(Locale.US, "%.4f", lastQuartileTC) + ";SDLQ;" 
							+ String.format(Locale.US, "%.4f", lastQuartileUC) + ";strategyChangesLQ;" 
					+ String.format(Locale.US, "%.4f", lastQuartileStrategyChanges) + ";\n";
					
			if (append) 
				writer.append (toPrint);		
			else 
				writer.print (toPrint);					
			
		}	
		
	}
	
	
	/**
	 * This method is for calculating all the statistical information for 
	 * the runs of the metrics
	 * 	 
	 */
	public void calcAllStats () {
					
		for( int j = 0; j < this.numberSteps; j++) {
			
			// Get a DescriptiveStatistics instance
			DescriptiveStatistics statsTP = new DescriptiveStatistics();
			DescriptiveStatistics statsUP = new DescriptiveStatistics();
			DescriptiveStatistics statsTC = new DescriptiveStatistics();
			DescriptiveStatistics statsUC = new DescriptiveStatistics();
			DescriptiveStatistics statsnetWealth = new DescriptiveStatistics();
			DescriptiveStatistics statsStrategyChanges = new DescriptiveStatistics();
			
			// Add the data from the array
			for( int i = 0; i < this.numberRuns; i++) {
				
		        statsTP.addValue(this.TC[i][j]);
		        statsUP.addValue(this.TD[i][j]);
		        statsTC.addValue(this.SC[i][j]);
		        statsUC.addValue(this.SD[i][j]);
		        
		        statsnetWealth.addValue(this.netWealth[i][j]);	  
		        
		        statsStrategyChanges.addValue(this.strategyChanges[i][j]);	 		        
		        
			}

			// calc mean and average for all of them
			
			this.avgTC[j] = statsTP.getMean();	
			this.stdTC[j] = statsTP.getStandardDeviation();
			this.min_TC[j] = statsTP.getMin();	
			this.max_TC[j] = statsTP.getMax();
			
			this.avgTD[j] = statsUP.getMean();	
			this.stdTD[j] = statsUP.getStandardDeviation();
			this.min_TD[j] = statsUP.getMin();	
			this.max_TD[j] = statsUP.getMax();

			this.avgSC[j] = statsTC.getMean();	
			this.stdSC[j] = statsTC.getStandardDeviation();
			this.min_SC[j] = statsTC.getMin();	
			this.max_SC[j] = statsTC.getMax();
			
			this.avgSD[j] = statsUC.getMean();	
			this.stdSD[j] = statsUC.getStandardDeviation();
			this.min_SD[j] = statsUC.getMin();	
			this.max_SD[j] = statsUC.getMax();
			
			this.avgnetWealth[j] = statsnetWealth.getMean();	
			this.stdnetWealth[j] = statsnetWealth.getStandardDeviation();
			this.min_netWealth[j] = statsnetWealth.getMin();	
			this.max_netWealth[j] = statsnetWealth.getMax();

			this.avgStrategyChanges[j] = statsStrategyChanges.getMean();	
			this.stdStrategyChanges[j] = statsStrategyChanges.getStandardDeviation();
			this.min_StrategyChanges[j] = statsStrategyChanges.getMin();	
			this.max_StrategyChanges[j] = statsStrategyChanges.getMax();
		}				
	}

}
