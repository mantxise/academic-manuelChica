package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import util.Functions;

import org.graphstream.ui.graphicGraph.GraphPosLengthUtils;

import sim.engine.*;
import sim.util.*;

import socialnetwork.*;
import util.BriefFormatter;



/**
 * Simulation core, responsible for scheduling agents of the EGT model for tourists-stakeholders
 * 
 * @author mchica
 * @date 2021/04/15
 * @place Las Palmas GC
 * 
 */
public class Model extends SimState {

	// ########################################################################
	// Variables
	// ########################################################################

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	static String CONFIGFILENAME;

	// LOGGING
	public static final Logger log = Logger.getLogger(Model.class.getName());

	// MODEL VARIABLES

	ModelParameters params;

	Bag agents;

	int touristsC_Agents[]; // a counter of the touristsC agents during the simulation
	int touristsD_Agents[]; // a counter of the touristsD agents during the simulation

	int stakeholdersC_Agents[]; // a counter of the stakeholdersC agents during the simulation
	int stakeholdersD_Agents[]; // a counter of the stakeholdersD agents during the simulation

	int strategyChanges[]; // array with the total number of strategy changes during the simulation

	float globalPayoffs[]; // array with the sum of all the payoffs of the population at each step

	// SOCIAL NETWORK
	LatticeGraphStreamer socialNetwork;

	int MC_RUN = -1;

	// --------------------------- Clone method ---------------------------//

	// --------------------------- Get/Set methods ---------------------------//
	//

	public static String getConfigFileName() {
		return CONFIGFILENAME;
	}

	public static void setConfigFileName(String _configFileName) {
		CONFIGFILENAME = _configFileName;
	}

	public LatticeGraphStreamer getSocialNetwork() {
		return socialNetwork;
	}

	/**
	 * 
	 * @return the payoffs of all the agents
	 */
	public float[] getGlobalPayoffs() {
		return globalPayoffs;
	}

	/**
	 * @param _globalPayoffs is the array with the payoffs for all the agents
	 */
	public void setGlobalPayoffs(float[] _globalPayoffs) {
		this.globalPayoffs = _globalPayoffs;
	}

	/**
	 * 
	 * @return the bag of agents.
	 */
	public Bag getAgents() {
		return agents;
	}

	/**
	 * 
	 * @param _agents is the bag (array) of agents
	 */
	public void setAgents(Bag _agents) {
		this.agents = _agents;
	}

	/**
	 * Get the global net-wealth of the population at a given step
	 * 
	 * @return the number of k_T agents
	 */
	public float getGlobalPayoffAtStep(int _position) {
		return this.globalPayoffs[_position];
	}

	/**
	 * Get the number of TouristsC agents at a given step - time
	 * 
	 * @return the number of TouristsC agents
	 */
	public int getTouristsC_AgentsAtStep(int _position) {
		return touristsC_Agents[_position];
	}

	/**
	 * Get the number of TouristsD agents for all the period of time
	 * 
	 * @return an ArrayList with the evolution of the TouristsD agents
	 */
	public int[] getTouristsD_AgentsArray() {
		return touristsD_Agents;
	}


	/**
	 * Get the number of TouristsC agents for all the period of time
	 * 
	 * @return an ArrayList with the evolution of TouristsC agents
	 */
	public int[] getTouristsC_AgentsArray() {
		return touristsC_Agents;
	}

	/**
	 * Get the number of TouristsD agents at a given step - time
	 * 
	 * @return the number of TouristsD agents
	 */
	public int getTouristsD_AgentsAtStep(int _position) {
		return touristsD_Agents[_position];
	}

	/**
	 * Get the number of StakeholdersC agents at a given step - time
	 * 
	 * @return the number of StakeholdersC agents
	 */
	public int getStakeholdersC_AgentsAtStep(int _position) {
		return stakeholdersC_Agents[_position];
	}

	/**
	 * Get the number of StakeholdersD agents for all the period of time
	 * 
	 * @return an ArrayList with the evolution of the StakeholdersD agents
	 */
	public int[] getStakeholdersD_AgentsArray() {
		return stakeholdersD_Agents;
	}


	/**
	 * Get the number of StakeholdersC agents for all the period of time
	 * 
	 * @return an ArrayList with the evolution of StakeholdersC agents
	 */
	public int[] getStakeholdersC_AgentsArray() {
		return stakeholdersC_Agents;
	}

	/**
	 * Get the number of StakeholdersD agents at a given step - time
	 * 
	 * @return the number of StakeholdersD agents
	 */
	public int getStakeholdersD_AgentsAtStep(int _position) {
		return stakeholdersD_Agents[_position];
	}

	/**
	 * Get the number of changes in the strategy of the agents for all the period of
	 * time
	 * 
	 * @return an ArrayList with the evolution of the strategy changes for all the
	 *         agents
	 */
	public int[] getStrategyChanges_AgentsArray() {
		return strategyChanges;
	}

	/**
	 * Get the parameter object with all the input parameters
	 */
	public ModelParameters getParametersObject() {
		return this.params;
	}

	/**
	 * Set the parameters
	 * 
	 * @param _params the object to be assigned
	 */
	public void setParametersObject(ModelParameters _params) {
		this.params = _params;
	}

	// ########################################################################
	// Constructors
	// ########################################################################

	/**
	 * Initializes a new instance of the simulation class.
	 * 
	 * @param _params an object with all the parameters of the model
	 */
	public Model(ModelParameters _params) {

		super(_params.getSeed());

		try {

			// This block configure the logger with handler and formatter
			long millis = System.currentTimeMillis();
			FileHandler fh = new FileHandler("./logs/" + _params.getOutputFile() + "_" + millis + ".log");
			log.addHandler(fh);
			BriefFormatter formatter = new BriefFormatter();
			fh.setFormatter(formatter);

			log.setLevel(Level.FINE);

			log.log(Level.FINE, "Log file created at " + millis + " (System Time Millis)\n");

		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		// get parameters
		params = _params;

		
		// Initialization of the type of strategy counts
		touristsC_Agents = new int[params.getMaxSteps()];
		touristsD_Agents = new int[params.getMaxSteps()];
		stakeholdersC_Agents = new int[params.getMaxSteps()];
		stakeholdersD_Agents = new int[params.getMaxSteps()];

		strategyChanges = new int[params.getMaxSteps()];

		globalPayoffs = new float[params.getMaxSteps()];

		// social network initialization from file

		socialNetwork = new LatticeGraphStreamer(params);
		socialNetwork.setGraph(params);
		
		/*if (params.haveCellsAttraction()) {
			
			// set the values of attractiveness to all the nodes of the lattice
			this.socialNetwork.setAttractivenessAllNods (params.getBetaDistrValues());		
		}*/
			
		
	}

	// --------------------------- SimState methods --------------------------//

	/**
	 * Sets up the simulation. The first method called when the simulation.
	 */
	public void start() {

		super.start();

		this.MC_RUN++;

		int totalAgents = params.getNumStakeholdersC() + params.getNumStakeholdersD() + 
				params.getNumTouristsC() + params.getNumTouristsD();
		if (totalAgents != params.nrAgents) {	
			System.err.println("Error: the number of TouristsC, TouristsD, StakeholderdsD, StakeholdersC ("
					+ totalAgents + ") is different from the total number of agents (" + params.nrAgents + ")");
		}

		final int FIRST_SCHEDULE = 0;
		int scheduleCounter = FIRST_SCHEDULE;

		
		// init variables for controlling number of agents and payoffs and other summary arrays
		for (int i = 0; i < params.getMaxSteps(); i++) {
			
			touristsC_Agents[i] = touristsD_Agents[i] = stakeholdersC_Agents[i] = stakeholdersD_Agents[i] = 0;
			strategyChanges[i] = 0;
			globalPayoffs[i] = (float) 0.;

		}

		// Initialization of the agents
		agents = new Bag();

		for (int i = 0; i < params.getNrAgents(); i++) {


			byte strategy = ModelParameters.UNDEFINED_STRATEGY;

			 if (i < params.numTouristsC) {
				 
                strategy = ModelParameters.COOPERATOR_TOURIST;
                 
            } else if (i < (params.numTouristsC + params.numTouristsD)) {
            	
                strategy = ModelParameters.DEFECTOR_TOURIST;
                 
            } else if (i < (params.numTouristsC + params.numTouristsD + params.numStakeholdersC)) {
                 
                strategy = ModelParameters.COOPERATOR_STAKEHOLDER;
                
            } else if (i < (params.numTouristsC + params.numTouristsD + params.numStakeholdersC + params.numStakeholdersD)) {
                
               strategy = ModelParameters.DEFECTOR_STAKEHOLDER;               
           }
			 
			// generate the agent, push in the bag, and schedule
			GamerAgent cl = generateAgent(i, strategy);

			// Add agent to the list and schedule
			agents.add(cl);

			// Add agent to the schedule
			schedule.scheduleRepeating(Schedule.EPOCH, scheduleCounter, cl);

		}

		// shuffle agents in the Bag and later, reassign the id to the position in the
		// bag to change IDs of the agents from MC run to MC run
		agents.shuffle(this.random);
		
		// for the network, we first initialize the agentIDs attributes of the nodes to value UNASSIGNED_SN_NODE
		
		this.socialNetwork.resetAgentsAssignment();
						
		// later, we set the agentId to a random index of a SN node  
		int [] positionsSN = new int [socialNetwork.getGraph().getNodeCount()];
		for (int i = 0; i < positionsSN.length; i++) 
			positionsSN[i] = i;
		
		Functions.shuffleArray (this.random, positionsSN);

		// Remaining positions, if pop density is lower than 1, are kept to value UNASSIGNED_SN_NODE
				
		for (int i = 0; i < agents.size(); i++) {
			
			// id of the agent
			((GamerAgent) agents.get(i)).setGamerAgentId(i);
			
			// index in the network position 
			((GamerAgent) agents.get(i)).setSocialNetworkIndex(positionsSN[i]);
			
			// assign this ID to the node of the network (from the shuffle array)
			this.socialNetwork.setAgentToNode(i, positionsSN[i]);			
			
		}
													
		
		// Add anonymous agent to calculate statistics
		setAnonymousAgentApriori(scheduleCounter);
		scheduleCounter++;

		setAnonymousAgentAposteriori(scheduleCounter);

	}

	
	// -------------------------- Auxiliary methods --------------------------//

	/**
	 * Generates the agent with its initial strategy, id, probability to act and its
	 * computed activity array (from the latter probability). This is important as
	 * we can save time not to ask at each step if the agent is active or not
	 * 
	 * @param _nodeId   is the id of the agent
	 * @param _strategy is the type of strategy the agent is going to follow
	 * @return the agent created by the method
	 */
	private GamerAgent generateAgent(int _nodeId, byte _strategy) {

		GamerAgent cl = new GamerAgent(_nodeId, _strategy);
		
		return cl;
	}

	
	/**
	 * Adds the anonymous agent to schedule (at the beginning of each step), which
	 * calculates the statistics.
	 * 
	 * @param scheduleCounter
	 */
	private void setAnonymousAgentApriori(int scheduleCounter) {

		// Add to the schedule at the end of each step
		schedule.scheduleRepeating(Schedule.EPOCH, scheduleCounter, new Steppable() {
			/**
			 * 
			 */
			private static final long serialVersionUID = -2837885990121299044L;

			public void step(SimState state) {

			}
		});

	}

	/**
	 * Adds the anonymous agent to schedule (at the end of each step), which
	 * calculates the statistics.
	 * 
	 * @param scheduleCounter
	 */
	private void setAnonymousAgentAposteriori(int scheduleCounter) {

		// Add to the schedule at the end of each step
		schedule.scheduleRepeating(Schedule.EPOCH, scheduleCounter, new Steppable() {

			private static final long serialVersionUID = 3078492735754898981L;

			public void step(SimState state) {

				int currentStep = (int) schedule.getSteps();

				// System.out.println("\n****Step " + currentStep);

				touristsC_Agents[currentStep] = touristsD_Agents[currentStep] = 
						stakeholdersC_Agents[currentStep] = stakeholdersD_Agents[currentStep] = 0;
				
				strategyChanges[currentStep] = 0;

				for (int i = 0; i < params.nrAgents; i++) {

					if (((GamerAgent) agents.get(i)).getCurrentStrategy() == 
							ModelParameters.COOPERATOR_TOURIST)  {
						touristsC_Agents[currentStep] ++;	
					}
					
					if (((GamerAgent) agents.get(i)).getCurrentStrategy() == 
							ModelParameters.DEFECTOR_TOURIST)  {
						touristsD_Agents[currentStep] ++;	
					}
					
					if (((GamerAgent) agents.get(i)).getCurrentStrategy() == 
							ModelParameters.COOPERATOR_STAKEHOLDER)  {
						stakeholdersC_Agents[currentStep] ++;	
					}
					
					if (((GamerAgent) agents.get(i)).getCurrentStrategy() == 
							ModelParameters.DEFECTOR_STAKEHOLDER)  {
						stakeholdersD_Agents[currentStep] ++;	
					}
					
					if (((GamerAgent) agents.get(i)).hasChangedStrategyAtStep(currentStep) )  {
						strategyChanges[currentStep] ++;	
					}		
				}

				// after counting the cooperators in both populations (stakeholders and tourists)
				// we see if we have the adaptive rewarding activated to change the weight
				if (params.getAdaptiveRewarding()) {
					
					// we have adaptive rewarding so depending on cooperators, we change the weight to either 1 or 0
					float fracTouristsC = (float)touristsC_Agents[currentStep] / (params.getNumTouristsC() + params.getNumTouristsD());
					float fracStakeholdersC = (float)stakeholdersC_Agents[currentStep] / (params.getNumStakeholdersC() + params.getNumStakeholdersD());
					
					//System.out.println("we have " + fracTouristsC + " ratio of C_tourists and " + fracStakeholdersC + " ratio of C_stks");
					
					if (fracTouristsC > fracStakeholdersC ) 
						// as we have more Cs in tourists, we set to 0 (all rewarding to Stks)
						params.setRewardWeight((float)0);
					else
						// as we have more Cs in stakeholers, we set to 1 (all rewarding to tourists)
						params.setRewardWeight((float)1);
						
					//System.out.println("w=" + params.getRewardWeight());

				}

				// update the payoffs
				globalPayoffs[currentStep] = (float) 0.;

				// we calculate the payoffs locally (the function itself will see if we have a SN structure or a well-mixed pop)

				for (int i = 0; i < params.nrAgents; i++) {				
					
					double value = ((GamerAgent) agents.get(i)).calculatePayoffWithNeighbors(state);
					
					// check in case the payoff is not valid (- \Inf)
					if (value > -1 * Float.MAX_VALUE)
						globalPayoffs[currentStep] += value;
																					
					// update previous payoff and strategies values

					((GamerAgent) agents.get(i)).setPreviousPayoff(((GamerAgent) agents.get(i)).getCurrentPayoff());
					((GamerAgent) agents.get(i)).setPreviousStrategy(((GamerAgent) agents.get(i)).getCurrentStrategy());						
				}
				
				// show the result of the last step in the console
				if (currentStep == (params.getMaxSteps() - 1)) {
					
					log.log(Level.FINE,
							"Final step;wealth;" + globalPayoffs[currentStep] + ";numStakeholdersC;" + stakeholdersC_Agents[currentStep] 
									+ ";numStakeholdersD;" + stakeholdersD_Agents[currentStep] + ";numTouristsC;" +
									touristsC_Agents[currentStep] + ";numTouristsD;" + touristsD_Agents[currentStep] + ";strategyChanges;" 
									+ strategyChanges[currentStep] + "\n");

				}					
				
				// plotting and saving additional output information for analysis
				plotSaveAdditionalInfo(currentStep);

			}
		});

	}

	/**
	 * This method wraps all the processes of saving and plotting additional
	 * information to study the dynamics of the simulation (e.g., SN, correlation
	 * between agents, or spatial/temporal correlations in the output)
	 * 
	 * Depending if the static variables of Model (SHOW_SN, OUTPUT_LATTICE,
	 * CALCULATE_SPATIO_TEMP_CORR etc...) are activated or not, the function will do
	 * and save all the required information
	 * 
	 * @param _currentStep is the step of the simulation
	 * 
	 */

	protected void plotSaveAdditionalInfo(int _currentStep) {
		
		// FIXED PICTURE OF THE LATTICE:
		// plot the regular lattice every STEP_OUTPUT_LATTICE steps 
		// that satisfy the condition in a 2D image  
		
		if (ModelParameters.OUTPUT_LATTICE && (_currentStep % ModelParameters.STEP_OUTPUT_LATTICE == 0) ) {

			// init matrix
			int n = Math.round((float) Math.sqrt(socialNetwork.getGraph().getNodeCount()));
			int matrixLattice[][] = new int[n][n];

			for (int i = 0; i < n; i++)
				for (int j = 0; j < n; j++)
					
					// this is for migration of tourism dilemma (no strategy for those nodes without agents)
					matrixLattice[i][j] = ModelParameters.UNDEFINED_STRATEGY;

			// get all the agents and find out the position of their associated nodes to set
			// the strategy

			for (int i = 0; i < params.nrAgents; i++) {

				int currStrategy = ((GamerAgent) agents.get(i)).getCurrentStrategy();
				int indexNode = ((GamerAgent) agents.get(i)).getSocialNetworkIndex();

				// System.out.println("agent " +  ((GamerAgent) agents.get(i)).getGamerAgentId() + " (str. " + currStrategy + ") is at " + indexNode );
				
				double pos[] = new double[3];
				GraphPosLengthUtils.nodePosition(socialNetwork.getGraph().getNode(indexNode), pos);

				matrixLattice[((int) pos[0])][((int) pos[1])] = currStrategy;
			}
			
			// save to file for static lattice
			try {

				// print the lattice plots into a file for each step
				File file = new File("./logs/latticeFiles/" + "2Dlattice_" + params.getOutputFile() + "_" + _currentStep
						+ "." + this.MC_RUN + ".txt");
				PrintWriter printWriter = new PrintWriter(file);

				String toPrint = "";
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < (n - 1); j++) {
						toPrint = toPrint + matrixLattice[i][j] + ";";
					}
					toPrint = toPrint + matrixLattice[i][(n - 1)] + "\n";
				}
				toPrint = toPrint + "\n";

				printWriter.print(toPrint);
				printWriter.close();				

			} catch (FileNotFoundException e) {

				e.printStackTrace();

				log.log(Level.SEVERE, e.toString(), e);
			}

		}
		
		// ALL EVOLUTION: This information is for saving in a file all the evolution of the sim steps to analyze
		// the evolution as a signal (FFT for instance)
		if ((ModelParameters.OUTPUT_WHOLE_EVOLUTION) && (_currentStep == (params.maxSteps - 1))) {

			try {

				// save
				File fileCorrCoef = new File("./logs/evolution_FFT/" + "WholeEvolution_" + params.getOutputFile() + "."
						+ this.MC_RUN + ".txt");
				PrintWriter printWriter = new PrintWriter(fileCorrCoef);

				printWriter.write("step;netWealth;numTouristsC;numTouristsD;numStakeholdersC;numStakeholdersD;\n");

				// loop for all the steps
				for (int k = 0; k < (params.maxSteps - 1); k++) {

					// print all info of the step
					printWriter.write(k + ";" + this.globalPayoffs[k] + ";"
							+ this.touristsC_Agents[k] + ";" + this.touristsD_Agents[k] + ";" 
							+ this.stakeholdersC_Agents[k] + ";" + this.stakeholdersD_Agents[k] + ";\n");

				}

				printWriter.close();

			} catch (FileNotFoundException e) {

				e.printStackTrace();
				log.log(Level.SEVERE, e.toString(), e);
			}

		}		
			
	}

	// ----------------------------- I/O methods -----------------------------//

	/**
	 * Prints simple statistics evolution during the time.
	 */
	public void printStatisticsScreen() {

		GamerAgent gamerAgent;

		int allTC, allTD, allSC, allSD;
		int tmp;

		allTC = allTD = allSC = allSD = 0;

		for (int i = 0; i < params.nrAgents; i++) {

			gamerAgent = (GamerAgent) agents.get(i);
			
			tmp = gamerAgent.getCurrentStrategy();

			if(tmp == ModelParameters.COOPERATOR_TOURIST)
				allTC++;
			
			if(tmp == ModelParameters.DEFECTOR_TOURIST)
				allTD++;
			
			if(tmp == ModelParameters.COOPERATOR_STAKEHOLDER)
				allSC++;
			
			if(tmp == ModelParameters.DEFECTOR_STAKEHOLDER)
				allSD++;


			// obtain avg. degree of the agent
			ArrayList<Integer> neighbors = (ArrayList<Integer>) this.socialNetwork
					.getNeighborIndexesOfNode(gamerAgent.socialNetworkIndex);

			System.out.println("A-" + gamerAgent.getGamerAgentId() + ";" + +neighbors.size() + ";" + ";"
					+ gamerAgent.getCurrentStrategy());

		}

		// Print it out
		System.out.println();
		System.out.print("numTouristsC;" + allTC);
		System.out.print(";numTouristsD;" + allTD);
		System.out.print(";numStakeholdersC;" + allSC);
		System.out.print(";numStakeholdersD;" + allSD);
		System.out.println();

	}
}
