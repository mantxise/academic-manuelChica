package model;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.stream.file.FileSourceDGS;

import au.com.bytecode.opencsv.CSVReader;
import socialnetwork.LatticeGraphStreamer.NetworkType;
import util.*;


/**
 * Parameters of the model of evolutionary dynamics for the tourists-stakeholders game
 * 
 * @author mchica
 * @date 2021/04/15
 * @place Las Palmas GC
 *
 */

public class ModelParameters {

	// Read configuration file
	ConfigFileReader config;
	
	// CONFIGURATION TO CALCULATE, STORE STATISTICS	
	public static boolean OUTPUT_WHOLE_EVOLUTION = false; 
	public static boolean OUTPUT_LATTICE = false; 
	public static int STEP_OUTPUT_LATTICE = 100; 
	
	// FOR THE STRATEGY OF THE AGENTS
	// IMPORTANT: INTEGER VALUES ARE NOT ARBITRARY TO COMPARE SAME ROLES
	public final static int UNDEFINED_STRATEGY = 0;
	public final static int COOPERATOR_TOURIST = 1;
	public final static int DEFECTOR_TOURIST = 2;
	public final static int COOPERATOR_STAKEHOLDER = -1;
	public final static int DEFECTOR_STAKEHOLDER = -2;

	public final static int WELL_MIXED_POP = -1;
	public final static int SF_NETWORK = 0;
	public final static int ER_NETWORK = 1;
	public final static int SW_NETWORK = 2;
	public final static int PGP_NETWORK = 3;
	public final static int EMAIL_NETWORK = 4;
	public final static int REGULAR_NETWORK = 5;
	
	public final static int VACANT_NODE = -1;
	

	// TYPE OF UPDATE RULE FOR THE AGENTS
	public final static int PROPORTIONAL_UPDATE_RULE = 1;
	public final static int UI_UPDATE_RULE = 2;
	public final static int VOTER_UPDATE_RULE = 3;
	public final static int FERMI_UPDATE_RULE = 4;
	public final static int WF_UPDATE_RULE = 5;  			 // Wright-Fisher, previously called Moran in other projects

	// AGGREGATION METHOD FOR PAYOFF CALCULATION
	public final static String PAYOFF_AGGREGATION = "ADD";   // MAX, ADD (standard way), AVG are the values
		
	
	// ########################################################################
	// Variables
	// ########################################################################

	String outputFile;

	// modified just to use a static SN from a file

	// FILE_NETWORK ONLY!!
	// Choose between several social networks:
	// SCALE_FREE_NETWORK, scale-free (Barabasi)
	// ER_RANDOM_NETWORK
	// SW_RANDOM_NETWORK
	NetworkType typeOfNetwork;

	String networkFilesPattern;

	// graph read from file
	Graph graphFromFile;

	
	//////////////////////////////////////////////7
		
	// parameters for the payoff calculation 
	float stakeholderCost; 					// cost for the stakeholder to be sustainable
	float touristCost; 						// cost for the tourist to be in a sustainable location
	float touristAddedValue; 				// added value for the tourist
	float touristDiscomfort; 				// discomfort for the tourist when the stakeholder is not C
	
	// population distribution
	int nrAgents;

	float densityPopulation;		// it is a value between 0 and 1. 0 means all the positions of the lattice are empty. 
									// 1 means all the positions are occupied. The number of SC, SD, TC, and TD are calculated 
									// IMPORTANT: This will also change the number of agents (default value is 1 (no empty cells))
		
	float speedMigration;			// speed to migrate (0 means no migration)

	//boolean attract = false;		// attractiveness of the cells is activated or not
	//String betaDistrFile;			// file with the beta distribution values
	//float[] attractValues = null;

	
	int numStakeholdersC; 			// no. of agents to be stakeholders cooperators at the beginning of the sim
	int numStakeholdersD; 			// no. of agents to be stakeholders defectors at the beginning of the sim
	int numTouristsC; 				// no. of agents to be tourists cooperators at the beginning of the sim
	int numTouristsD; 				// no. of agents to be tourists defectors at the beginning of the sim
	
	// for rewarding policies to T or Stakeholders
	float perCapitaIncentive;		// per capita value to incentivize cooperators
	float rewardWeight;				// weight to either reward Cooperating Tourists or Stakeholders (linear combination of both)
	boolean adaptiveRewarding;		// true if rewarding is changing depending on the number of cooperators of tourists and stk

	// update's rule for the ev dynamics game

	int maxSteps; 					// maximum number of steps for the simulation
	int runsMC; 					// number of MC runs
	int updateRule; 				// identifier for the update rule of the agents

	float q_VM = 1;					// q value in [0,1] to either choose the VM or UI. If 1, always VM. 1-q, UI is applied

	long seed; 						// seed to run all the simulations
	
	float mutProb;					// probability to mutate a strategy
	
	// --------------------------- Get/Set methods ---------------------------//
	//
	
	/**
	 * @return the type of rewarding, if adaptive
	 */
	public boolean getAdaptiveRewarding() {
		return this.adaptiveRewarding;
	}

	/** 
	 * 
	 * @param the type of rewarding, if adaptive
	 */
	public void setAdaptiveRewarding(boolean _b) {
		this.adaptiveRewarding = _b;
	}
	/**
	 * 
	 */
	/**
	 * @return the reward weight
	 */
	public float getRewardWeight() {
		return this.rewardWeight;
	}

	/** 
	 * 
	 * @param reward weight
	 */
	public void setRewardWeight(float _r) {
		this.rewardWeight = _r;
	}
	/**
	 * @return the per capita incentive
	 */
	public float getPerCapitaIncentive() {
		return this.perCapitaIncentive;
	}

	/** 
	 * 
	 * @param per capita incentive 
	 */
	public void setPerCapitaIncentive(float _per) {
		this.perCapitaIncentive = _per;
	}
	
	/**
	 * @return the file with the beta distr values
	 */
	/*public String getpBetaDistrFile() {
		return this.betaDistrFile;
	}*/

	/**
	 * @return the array with the beta distr values
	 */
	/*public float [] getBetaDistrValues() {
		return this.attractValues;
	}*/

	
	/**
	 * @param _file file with the Beta distribution values
	 */
	/*public void setBetaDistrFile(String _file) {
		this.betaDistrFile = _file;
	}*/
	
	/**
	 * @return if attractiveness is activated
	 */
	/*public boolean haveCellsAttraction() {
		return attract;
	}*/

	/**
	 * @param attract if the cells have attraction
	 */
	/*public void setCellsAttraction(boolean attract) {
		this.attract = attract;
	}*/
	
	/**
	 * @return the mutProb
	 */
	public double getMutProb() {
		return mutProb;
	}

	/** 
	 * 
	 * @param SpeedMigration 
	 */
	public void setSpeedOfMigration(float _speed) {
		this.speedMigration = _speed;
	}
	
	/**
	 * @return the SpeedMigration
	 */
	public float getSpeedOfMigration() {
		return this.speedMigration;
	}

	/** 
	 * 
	 * @param mutProb 
	 */
	public void setMutProb(float _mutProb) {
		this.mutProb = _mutProb;
	}

	/**
	 * @return the q value for choosing between VM or UI
	 */
	public float getQ_VM() {
		return q_VM;
	}

	/** 
	 * 
	 * @param q_VM THE q value for choosing between VM or UI
	 */
	public void setQ_VM(float q_VM) {
		this.q_VM = q_VM;
	}
	
	/**
	 * @return the seed for running all the simulations
	 */
	public long getSeed() {
		return seed;
	}

	/**
	 * @param the
	 *            seed to run all the simulation
	 */
	public void setSeed(long _seed) {
		this.seed = _seed;
	}

	/**
	 * @return the max number of steps of the simulation
	 */
	public int getMaxSteps() {
		return maxSteps;
	}

	/**
	 * @param the max number of steps of the simulation
	 */
	public void setMaxSteps(int _maxSteps) {
		this.maxSteps = _maxSteps;
	}

	public String getOutputFile() {
		return outputFile;
	}

	public void setOutputFile(String outputFile) {
		this.outputFile = outputFile;
	}

	/**
	 * @return the alpha value (defection rate from the total amount to be declared)
	 */
	public float getTouristCost() {
		return this.touristCost;
	}

	/**
	 * @param _a the value for alpha
	 */
	public void setTouristCost(float _a) {
		this.touristCost = _a;
	}

	
	/**
	 * @return the typeOfNetwork
	 */
	public NetworkType getTypeOfNetwork() {
		return typeOfNetwork;
	}

	/**
	 * @param typeOfNetwork
	 *            the typeOfNetwork to set
	 */
	public void setTypeOfNetwork(NetworkType typeOfNetwork) {
		this.typeOfNetwork = typeOfNetwork;
	}

	/**
	 * @return the graph
	 */
	public Graph getGraph() {
		return graphFromFile;
	}

	/**
	 * @param _graph
	 *            to set
	 */
	public void setGraph(Graph _graph) {
		this.graphFromFile = _graph;
	}

	public String getNetworkFilesPattern() {
		return networkFilesPattern;
	}

	public void setNetworkFilesPattern(String networkFilesPattern) {
		this.networkFilesPattern = networkFilesPattern;
	}

		
	/**
	 * @param _graph
	 *            to set
	 * @throws IOException
	 */
	public void readGraphFromFile(String fileNameGraph) throws IOException {

		setNetworkFilesPattern(fileNameGraph);

		FileSourceDGS fileSource = new FileSourceDGS();
		graphFromFile = new SingleGraph("SNFromFile");

		fileSource.addSink(graphFromFile);
		fileSource.readAll(fileNameGraph);

		fileSource.removeSink(graphFromFile);
		
	}

	/**
	 * Display the graph
	 * 
	 * @return
	 */
	public void displayGraph (Set<Integer> k_I, Set <Integer> k_T, Set<Integer> k_U) {
	
		for (Node node : graphFromFile) {
			

			node.addAttribute("ui.color",3);
			node.setAttribute("size", "medium");
			//node.setAttribute("ui:fill-color", "blue");
			node.addAttribute("ui.label", node.getId());
			
			if (k_I.contains(Integer.getInteger(node.getId()))) {

				node.setAttribute("ui.color", 0); // The node will be green.
				
			} else if (k_T.contains(Integer.getInteger(node.getId()))) {

				node.setAttribute("ui.color", 0.5); // The node will be a mix of green and red.
				
			} else if (k_U.contains(Integer.getInteger(node.getId()))) {

				node.setAttribute("ui.color", 1); // The node will be red.
			}
			
		}
	
		graphFromFile.display();	
	}
	
	
	/**
	 * Gets the number of agents.
	 * 
	 * @return
	 */
	public int getNrAgents() {
		return nrAgents;
	}

	/**
	 * Sets the number of agents
	 * 
	 * @param nrAgents
	 */
	public void setNrAgents(int nrAgents) {
		if (nrAgents > 0)
			this.nrAgents = nrAgents;
	}

	/**
	 * Gets the type of update rule for the agents.
	 * 
	 * @return
	 */
	public int getUpdateRule() {
		return this.updateRule;
	}

	/**
	 * Sets the update rule.
	 * 
	 * @param updateRule
	 */
	public void setUpdateRule(int _updateRule) {
		this.updateRule = _updateRule;
	}

	/**
	 * Gets inspection cost
	 * 
	 * @return
	 */
	public float getTouristAddedValue() {
		return this.touristAddedValue;
	}

	/**
	 * Sets inspection cost
	 * 
	 * @param _ins the value for the inspection ost
	 */
	public void setTouristAddedValue(float _ins) {
		this.touristAddedValue = _ins;
	}

	/**
	 * Gets reputational reward
	 * 
	 * @return
	 */
	public float getTouristDiscomfort() {
		return this.touristDiscomfort;
	}

	/**
	 * Sets reputational reward
	 * 
	 * @param _rep is the reward for Cs
	 */
	public void setTouristDiscomfort(float _rep) {
		this.touristDiscomfort = _rep;
	}

	/**
	 * Gets fine for Ds
	 * 
	 * @return
	 */
	public float getStakeholderCost() {
		return this.stakeholderCost;
	}

	/**
	 * Sets fine for Ds
	 * 
	 * @param _fine
	 */
	public void setStakeholderCost(float _fine) {
		this.stakeholderCost = _fine;
	}

	/**
	 * Gets DensitPopulation
	 * 
	 * @return the density of the population
	 */
	public float getDensityPopulation() {
		return this.densityPopulation;
	}

	/**
	 * Sets DensitPopulation
	 * 
	 * @param the density of the population
	 */
	public void setDensityPopulation(float _per) {
		this.densityPopulation = _per;
	}

	/**
	 * Gets numStakeholdersC (number of Cs).
	 * 
	 * @return
	 */
	public int getNumStakeholdersC() {
		return this.numStakeholdersC;
	}

	/**
	 * Sets numStakeholdersC (number of Cs).
	 * 
	 * @param _NumStakeholdersC
	 */
	public void setNumStakeholdersC(int _NumStakeholdersC) {
		this.numStakeholdersC = _NumStakeholdersC;
	}

	/**
	 * Gets numStakeholdersD (number of Ds).
	 * 
	 * @return
	 */
	public int getNumStakeholdersD() {
		return this.numStakeholdersD;
	}

	/**
	 * Sets numStakeholdersD (number of Ds).
	 * 
	 * @param _NumStakeholdersD
	 */
	public void setNumStakeholdersD(int _NumStakeholdersD) {
		this.numStakeholdersD = _NumStakeholdersD;
	}
	
	/**
	 * Gets numTouristsC (number of Cs).
	 * 
	 * @return
	 */
	public int getNumTouristsC() {
		return this.numTouristsC;
	}

	/**
	 * Sets numTouristsC (number of Cs).
	 * 
	 * @param _NumTouristsC
	 */
	public void setNumTouristsC(int _NumTouristsC) {
		this.numTouristsC = _NumTouristsC;
	}

	/**
	 * Gets numTouristsD (number of Ds).
	 * 
	 * @return
	 */
	public int getNumTouristsD() {
		return this.numTouristsD;
	}

	/**
	 * Sets numTouristsD (number of Ds).
	 * 
	 * @param _NumTouristsD
	 */
	public void setNumTouristsD(int _NumTouristsD) {
		this.numTouristsD = _NumTouristsD;
	}


	/**
	 * @return number of MC runs
	 */
	public int getRunsMC() {
		return runsMC;
	}

	/**
	 * Sets number of MC runs
	 * 
	 * @param _runsMC
	 */
	public void setRunsMC(int _runsMC) {
		this.runsMC = _runsMC;
	}

	// ########################################################################
	// Constructors
	// ########################################################################

	/**
	 * 
	 */
	public ModelParameters() {

	}

	// ########################################################################
	// Export methods
	// ########################################################################

	public String export() {

		String values = "";

		values += exportGeneral();

		values += exportSN();

		return values;
	}

	private String exportSN() {

		String result = "";

		result += "SNFile = " + this.networkFilesPattern + "\n";
		result += "typeOfSN = " + this.typeOfNetwork + "\n";

		return result;

	}

	private String exportGeneral() {

		String result = "";

		result += "\n***General and population: \n";
		result += "MC_runs = " + this.runsMC + "\n";
		result += "seed = " + this.seed + "\n";
		result += "nrAgents = " + this.nrAgents + "\n";
		result += "maxSteps = " + this.maxSteps + "\n";

		result += "numTouristsC = " + this.numTouristsC + "\n";
		result += "numTouristsD = " + this.numTouristsD + "\n";
		result += "numStakeholdersC = " + this.numStakeholdersC + "\n";
		result += "numStakeholdersD = " + this.numStakeholdersD + "\n";
		

		result += "\n***Game payoff and strategies: \n";

		result += "touristCost = " + this.touristCost + "\n";
		result += "touristDiscomfort = " + this.touristDiscomfort + "\n";
		result += "stakeholderCost = " + this.stakeholderCost + "\n";
		result += "touristAddedValue = " + this.touristAddedValue + "\n";
		
		result += "mutProb = " + this.mutProb + "\n";

		if (this.updateRule == ModelParameters.PROPORTIONAL_UPDATE_RULE)
			result += "updateRule = PROPORTIONAL_UPDATE_RULE\n";
		
		else if (this.updateRule == ModelParameters.UI_UPDATE_RULE)
			result += "updateRule = UI_UPDATE_RULE\n";
		
		else if (this.updateRule == ModelParameters.VOTER_UPDATE_RULE) {
			result += "updateRule = VOTER_UPDATE_RULE\n";
			result += "q_VM = " + this.q_VM + "\n";
		}
					
		else if (this.updateRule == ModelParameters.FERMI_UPDATE_RULE)
			result += "updateRule = FERMI_UPDATE_RULE\n";
		
		else if (this.updateRule == ModelParameters.WF_UPDATE_RULE)
			result += "updateRule = WF_UPDATE_RULE\n";
		

		result += "\n***Rewarding: \n";
		
		result += "perCapitaIncentive = " + this.perCapitaIncentive + "\n";
		result += "rewardWeight = " + this.rewardWeight + "\n";
		result += "adaptiveRewarding = " + this.adaptiveRewarding + "\n";
					

		result += "\n***Network and migration dependent: \n";
			
		
		result += "densityPopulation = " + this.densityPopulation + "\n";
		result += "speedOfMigration = " + this.speedMigration + "\n";
		/*result += "attract = " + this.attract + "\n";
		result += "betaDistrFile = " + this.betaDistrFile + "\n";*/
		
		return result;
	}
	
		
	/**
	 * From a given density, we change the agents pop distribution
	 * @throws IOException 
	 */
	public void readjustPopFromDensity() {
		
		// readjust the number of agents 
		if (this.densityPopulation < 1.0) {
			
			// initial number of players if there are empty cells	
			this.numTouristsC = Math.round(this.densityPopulation * this.nrAgents * (float) config.getParameterDouble("rateTouristsC"));
			this.numTouristsD = Math.round(this.densityPopulation *  this.nrAgents * (float) config.getParameterDouble("rateTouristsD"));
			this.numStakeholdersC = Math.round(this.densityPopulation *  this.nrAgents * (float) config.getParameterDouble("rateStakeholdersC"));
			this.numStakeholdersD = Math.round(this.densityPopulation *  this.nrAgents * (float) config.getParameterDouble("rateStakeholdersD"));	
			this.nrAgents = this.numTouristsC + this.numTouristsD + this.numStakeholdersC + this.numStakeholdersD; 
	
		} else {
			
			// initial number of players when the lattice is full	
			this.numTouristsC = Math.round( this.nrAgents * (float) config.getParameterDouble("rateTouristsC"));
			this.numTouristsD = Math.round( this.nrAgents * (float) config.getParameterDouble("rateTouristsD"));
			this.numStakeholdersC = Math.round( this.nrAgents * (float) config.getParameterDouble("rateStakeholdersC"));
			this.numStakeholdersD = this.nrAgents - (this.numTouristsC + this.numTouristsD +
							this.numStakeholdersC); 
		}
						
		if ((this.numTouristsC +  this.numTouristsD + this.numStakeholdersC + this.numStakeholdersD) != this.nrAgents) {
			System.err.println("Error when defining players' strategies. They do not sum the total no. of agents."
					+ "Check params for TouristsC, TouristsD, StakeholdersC, and StakeholderdsD\n");
		}
		
	}
	
	/**
	 * Load the CSV file for beta distr values (just one column with the values)
	 * 
	 * We check we have the same values as cells
	 * 
	 */
	public void loadAttractValuesFile () {
	
	/*	try {
	
			//Read CSV values
			CSVReader reader = new CSVReader(new FileReader(new File(this.betaDistrFile)), ';');
			
			List<String[]> csvValues = reader.readAll();
			Iterator<String []> csvIterator = csvValues.iterator();
			
			int rows = csvValues.size();
			int cols = csvValues.get(0).length;
			
			if (rows == 0 || cols == 0 || csvValues.isEmpty()) {
				reader.close();
				
				throw new IllegalArgumentException("Incorrect CSV file: " + this.betaDistrFile);				
			}
			
			if (rows != this.graphFromFile.getNodeCount()) {
				reader.close();
				
				throw new IOException("The number of rows (i.e., lines, one for each player) must be equal to " +
							"the number of agents in the model (" + this.nrAgents + ").\n");
			}
	
			this.attractValues = new float[rows];
	
			for (int i = 0; csvIterator.hasNext(); i++) {
				String[] csvLine = csvIterator.next();
				
				assert(csvLine.length == cols);
	
				this.attractValues[i] = Float.valueOf(csvLine[0]);
				
				assert(csvIterator.hasNext() || i == rows);
			}			
	
			reader.close();
			
		} catch (IOException e){
			
			System.err.println("Error when loading attract file\n" + e.getMessage());
			e.printStackTrace(new PrintWriter(System.err));
			
		} catch (IllegalArgumentException e){
	
			System.err.println("Error when loading attract file\n" + e.getMessage());
			e.printStackTrace(new PrintWriter(System.err));
			    
		} 
		*/
		
	}
	
	/**
	 * Reads parameters from the configuration file.
	 */
	public void readParameters(String CONFIGFILENAME) {

		try {

			// Read parameters from the file
			config = new ConfigFileReader(CONFIGFILENAME);

			config.readConfigFile();

			// Get global parameters
			this.maxSteps = config.getParameterInteger("maxSteps");
			this.runsMC = config.getParameterInteger("MCRuns");
			this.seed = config.getParameterInteger("seed");

			this.nrAgents = config.getParameterInteger("nrAgents");
			this.densityPopulation = (float) config.getParameterDouble("densityPopulation");
			this.speedMigration = (float) config.getParameterDouble("speedOfMigration");
			
			/*if ((int) config.getParameterDouble("attract") == 0)
				this.attract = false;
			else 
				this.attract = true;
			 */
			
			if ( this.densityPopulation > 1.0 ) {
				throw new IOException("Error when defining density. It must be equal or lower than 1\n");
			}
			
			//this.readjustPopFromDensity();

			this.updateRule = config.getParameterInteger("updateRule");

			if (this.updateRule == ModelParameters.VOTER_UPDATE_RULE) {
				
				try {
					this.q_VM = (float) config.getParameterDouble("q_VM");
				} catch (Exception e) {
					
					// if it is not defined, q by default (= 1). Always VM
					this.q_VM = (float) 1.;
				}					
				
			} else {
				this.q_VM = -1;
			}
			
			this.touristCost = (float) config.getParameterDouble("touristCost");
			this.touristDiscomfort = (float) config.getParameterDouble("touristDiscomfort");
			this.stakeholderCost = (float) config.getParameterDouble("stakeholderCost");
			this.touristAddedValue = (float) config.getParameterDouble("touristAddedValue");

			// mut prob is directly set to 1/Z, being Z the population 
			//this.mutProb = config.getParameterDouble("mutProb");
			this.mutProb = (float) 1. / this.nrAgents;
				
			// reward-punishment policies
			this.perCapitaIncentive = (float) config.getParameterDouble("perCapitaIncentive");
			this.rewardWeight = (float) config.getParameterDouble("rewardWeight");
			this.adaptiveRewarding = (boolean) config.getParameterBoolean("adaptiveRewarding");
			
			
			// Read social network file but this file can be SF, Random,			
			// RW or regular

			this.readGraphFromFile(config.getParameterString("SNFile"));
			
			// set type of network

			if (config.getParameterInteger("typeOfNetwork") == SW_NETWORK) {

				typeOfNetwork = NetworkType.SW_NETWORK;
			}
			if (config.getParameterInteger("typeOfNetwork") == ER_NETWORK) {

				typeOfNetwork = NetworkType.RANDOM_NETWORK;
			}
			if (config.getParameterInteger("typeOfNetwork") == SF_NETWORK) {

				typeOfNetwork = NetworkType.SCALE_FREE_NETWORK;
			}
			if (config.getParameterInteger("typeOfNetwork") == WELL_MIXED_POP) {

				typeOfNetwork = NetworkType.WELL_MIXED_POP;
			}
			if (config.getParameterInteger("typeOfNetwork") == PGP_NETWORK) {

				typeOfNetwork = NetworkType.PGP_NETWORK;
			}
			if (config.getParameterInteger("typeOfNetwork") == EMAIL_NETWORK) {

				typeOfNetwork = NetworkType.EMAIL_NETWORK;
			}
			if (config.getParameterInteger("typeOfNetwork") == REGULAR_NETWORK) {

				typeOfNetwork = NetworkType.REGULAR_NETWORK;
			}

		} catch (IOException e) {

			System.err.println("ModelParameters: Error with SN file when loading parameters for the simulation " + CONFIGFILENAME + "\n"
					+ e.getMessage());
			e.printStackTrace(new PrintWriter(System.err));
		}
	}

	

	/**
	 * Prints simple statistics evolution during the time.
	 */
	public void printParameters(PrintWriter writer) {

		// printing general params
		writer.println(this.export());

	}

	/**
	 * Check game's payoffs parameter
	 */
	public void checkGameParameters () {

		if (touristCost < 1 || touristCost > 2) {
			System.err.println("ModelParameters: Error with parameter touristCost (\\epsilon). "
					+ "It must be between 1 and 2. Current value is " + touristCost);
		}
		
		if (touristDiscomfort < 0 || touristDiscomfort > 1) {
			System.err.println("ModelParameters: Error with parameter touristDiscomfort (\\tau). "
					+ "It must be between 0 and 1. Current value is " + touristDiscomfort);
		}
		
		if (stakeholderCost < 0 || stakeholderCost > 1) {
			System.err.println("ModelParameters: Error with parameter stakeholderCost (\\gamma). "
					+ "It must be between 0 and 1. Current value is " + stakeholderCost);
		}
		
		/*if ((touristAddedValue - touristCost) <= 0 ) {
			System.err.println("ModelParameters: Error with parameters \\nu and \\epsilon. "
					+ "\\nu - \\epsilon must be greater than 0 and it is " + (touristAddedValue - touristCost));
		}
		
		if ((touristCost - stakeholderCost) >= 1 ) {
			System.err.println("ModelParameters: Error with parameters \\epsilon - \\gamma. "
					+ "\\epsilon - c must be lower than 0 and it is " + (touristCost - stakeholderCost));
		}*/
		
	}


}
