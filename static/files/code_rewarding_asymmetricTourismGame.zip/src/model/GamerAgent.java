package model;

import sim.engine.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;


/**
 * Class of the players of the tourists-stakeholders dilemma

 * @author mchica
 * @date 2021/04/15
 * @place Las Palmas GC
 *
 */

public class GamerAgent implements Steppable {

	// ########################################################################
	// Variables
	// ########################################################################


	private static final long serialVersionUID = 1L;

	// --------------------------------- Fixed -------------------------------//

	int gamerAgentId; 	// A unique agent Id

	int currentStep; 	// the current step of the simulation


	// ------------------------------- Dynamic -------------------------------//

	int socialNetworkIndex; 			// A unique index of the position of the agent in the network
	
	float currentPayoff = Float.MIN_VALUE; // payoff obtained by the agent at this step
	float previousPayoff = Float.MIN_VALUE; // payoff obtained by the agent previous step

	byte currentStrategy = ModelParameters.UNDEFINED_STRATEGY; // current strategy used by the agent
	byte previousStrategy = ModelParameters.UNDEFINED_STRATEGY; // strategy used by the agent in the previous step

	// ########################################################################
	// Constructors
	// ########################################################################

	/**
	 * Initializes a new instance of the GamerAgent class.
	 * 
	 * @param _gameId   is the id for the agent
	 * @param _strategy is the strategy used at the beginning of the simulation
	 * 
	 */
	public GamerAgent(int _gamerId, byte _strategy) {

		this.gamerAgentId = _gamerId;
		this.currentStrategy = _strategy;
		
		this.socialNetworkIndex = ModelParameters.VACANT_NODE;  // unassigned yet
		
	}

	// ########################################################################
	// Methods/Functions
	// ########################################################################

	// --------------------------- Get/Set methods ---------------------------//

	/**
	 * Gets the id of the agent
	 * 
	 * @return
	 */
	public int getGamerAgentId() {
		return gamerAgentId;
	}

	/**
	 * Sets the id of the agent
	 * 
	 * @param gamerAgentId
	 */
	public void setGamerAgentId(int _gamerAgentId) {
		this.gamerAgentId = _gamerAgentId;
	}

	/**
	 * Gets the index of the agent in the social netwokr
	 * 
	 * @return the index of the node of the network where the agent is set
	 */
	public int getSocialNetworkIndex () {
		return this.socialNetworkIndex;
	}

	/**
	 * Sets the id of the agent
	 * 
	 * @param _indexNetwork the index of the node of the network where the agent is set
	 */
	public void setSocialNetworkIndex (int _indexNetwork) {
		this.socialNetworkIndex = _indexNetwork;
	}

	/**
	 * Gets the current payoff of the agent
	 * 
	 * @return - the payoff
	 */
	public float getCurrentPayoff() {
		return this.currentPayoff;
	}

	/**
	 * Sets the current payoff of the agent
	 * 
	 * @param _strategy - the current payoff to be set
	 */
	public void setCurrentPayoff(float _p) {
		this.currentPayoff = _p;
	}

	/**
	 * Gets the previous payoff of the agent
	 * 
	 * @return - the payoff
	 */
	public float getPreviousPayoff() {
		return this.previousPayoff;
	}

	/**
	 * Sets the previous payoff of the agent
	 * 
	 * @param _strategy - the current payoff to be set
	 */
	public void setPreviousPayoff(float _strategy) {
		this.previousPayoff = _strategy;
	}

	/**
	 * Gets the current strategy of the agent
	 * 
	 * @return - the strategy
	 */
	public byte getCurrentStrategy() {
		return this.currentStrategy;
	}

	/**
	 * Sets the strategy status of the agent
	 * 
	 * @param _strategy - the current strategy to be set
	 */
	public void setCurrentStrategy(byte _strategy) {
		this.currentStrategy = _strategy;
	}

	/**
	 * Gets the previous strategy of the agent
	 * 
	 * @return - the strategy
	 */
	public byte getPreviousStrategy() {
		return this.previousStrategy;
	}

	/**
	 * Sets the previous strategy of the agent
	 * 
	 * @param _strategy - the current strategy to be set
	 */
	public void setPreviousStrategy(byte _strategy) {
		this.previousStrategy = _strategy;
	}

	/**
	 * Returns true if the agent has changed its strategy this step. False if it has
	 * the same
	 */
	public boolean hasChangedStrategyAtStep(int _step) {

		if ((_step > 0) && (this.getCurrentStrategy() != this.getPreviousStrategy()) )
			return true;
		else
			return false;
		
	}
	
	/**
	 * Returns true if the agent passed as argument has the same role on the previous step (either tourist or stakeholder)
	 */
	public boolean hasSameRoleOnPreviousStep (GamerAgent _contactAgent) {

		if ( (this.previousStrategy < 0 &&  _contactAgent.previousStrategy < 0) ||
				(this.previousStrategy > 0 &&  _contactAgent.previousStrategy > 0) )
			return true;
		else
			return false;
		
	}
	
	/**
	 * Returns true if the agent passed as argument has the same role on the current step (either tourist or stakeholder)
	 */
	public boolean hasSameRoleOnCurrentStep (GamerAgent _contactAgent) {

		if ( (this.currentStrategy < 0 &&  _contactAgent.currentStrategy < 0) ||
				(this.currentStrategy > 0 &&  _contactAgent.currentStrategy > 0) )
			return true;
		else
			return false;
		
	}
	
	
	// -------------------------- Cooperation methods --------------------------//

	/**
	 * This function is called to calculate the payoffs of the play of the agent
	 * within its local neighbourhood of the SN or lattice. The payoff is calculated following
	 * the payoff matrix of the defined game (see corresponding paper).
	 * 
	 * It is a pairwise game. Depending on the configuration, we average/add/max 
	 * all the interactions of the focal agent to set its payoff value
	 * 
	 * Only players with opposite roles can play. The other interactions are 0
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return the payoff of the agent in this step
	 */
	public double calculatePayoffWithNeighbors(SimState state) {

		Model model = (Model) state;
		
		ArrayList<Integer> neighbors;
					
		// if we have a SN structure, we get all the neighbors of the agent in the SN
		neighbors = (ArrayList<Integer>) model.socialNetwork.returnNeighboringAgentIdsOfNode(this.socialNetworkIndex);		
		
		// setting the payoff to the agent according to the utility matrix

		if (ModelParameters.PAYOFF_AGGREGATION.compareTo("MAX") == 0)
			this.currentPayoff = (float) -1 * Float.MAX_VALUE;
		else 
			this.currentPayoff = (float) 0;
		

		// retrieve parameters of the payoff matrix
		float nu = model.getParametersObject().getTouristAddedValue();
		float tau = model.getParametersObject().getTouristDiscomfort();
		float epsilon = model.getParametersObject().getTouristCost();
		float c = model.getParametersObject().getStakeholderCost();
		
		// rewarding policies
		float rewardTourist = model.getParametersObject().getRewardWeight() * model.getParametersObject().getPerCapitaIncentive();
		float rewardStk = (1 - model.getParametersObject().getRewardWeight()) * model.getParametersObject().getPerCapitaIncentive();
		
		
		// Iterate over neighbors
		boolean allSameRole = true;
		
		// System.out.println("\nFocal-" + this.gamerAgentId + " (str. " + this.getCurrentStrategy() + ")");		 

		for (int i = 0; i < neighbors.size(); i++) {

			GamerAgent neighbor = (GamerAgent) (model.getAgents()).get(neighbors.get(i));
			
			// System.out.print("\n -Neigh-" + neighbor.gamerAgentId + " (str. " + neighbor.getCurrentStrategy() + ")");		 

			float payoffWithNeighbor = 0;
			
			// check if they have opposite roles
			if ( this.hasSameRoleOnCurrentStep(neighbor) ) {
				
				// null payoff if they have the same role
				payoffWithNeighbor = 0;
				
			} else {
				
				// at least, there is one neighbor having an opposite role
				
				allSameRole = false;
				
				// check the i-th neighbor strategy and the focal agent's strategy to calculate payoffs

				if (this.currentStrategy == ModelParameters.COOPERATOR_TOURIST) {
					
					if (neighbor.currentStrategy == ModelParameters.COOPERATOR_STAKEHOLDER) {
						
						// CASE Tourist C VS. Stakeholder C (= \nu - \epsilon)			
						payoffWithNeighbor = nu - epsilon + rewardTourist;

					} else if (neighbor.currentStrategy == ModelParameters.DEFECTOR_STAKEHOLDER) {
																
						// CASE Tourist C VS. Stakeholder D (= -1 - \tau)			
						payoffWithNeighbor = -1 - tau + rewardTourist;
					
					}

				} else if (this.currentStrategy == ModelParameters.DEFECTOR_TOURIST) {
					
					if (neighbor.currentStrategy == ModelParameters.COOPERATOR_STAKEHOLDER) {
						
						/* // CASE Tourist D VS. Stakeholder C (= - \epsilon)			
						payoffWithNeighbor = -1 * epsilon;*/
						
						// CASE Tourist C VS. Stakeholder C (= \nu - \epsilon)			
						payoffWithNeighbor = nu - epsilon;

					} else if (neighbor.currentStrategy == ModelParameters.DEFECTOR_STAKEHOLDER) {
																
						// CASE Tourist D VS. Stakeholder D (= -1 )			
						payoffWithNeighbor = -1;
					
					}					

				} else if (this.currentStrategy == ModelParameters.COOPERATOR_STAKEHOLDER) {
					
					if (neighbor.currentStrategy == ModelParameters.COOPERATOR_TOURIST) {
						
						// CASE Stakeholder C vS. Tourist C (=  \epsilon)			
						payoffWithNeighbor = epsilon + rewardStk;

					} else if (neighbor.currentStrategy == ModelParameters.DEFECTOR_TOURIST) {
																
						// CASE Stakeholder C Vs. Tourist D (= \epsilon - c)			
						payoffWithNeighbor = epsilon - c + rewardStk;
					
					}					

				} else if (this.currentStrategy == ModelParameters.DEFECTOR_STAKEHOLDER) {
					
					if (neighbor.currentStrategy == ModelParameters.COOPERATOR_TOURIST) {
						
						// CASE Stakeholder D vS. Tourist C(=  1)			
						payoffWithNeighbor = 1;

					} else if (neighbor.currentStrategy == ModelParameters.DEFECTOR_TOURIST) {
																
						// CASE Stakeholder D Vs. Tourist D (= 1)			
						payoffWithNeighbor = 1;					
					}			
				} 
				
				// CUSTOMIZE WAY OF AGGREGATION
				if (ModelParameters.PAYOFF_AGGREGATION.compareTo("MAX") == 0) {
					
					// assign if value is higher than previous saved payoff (MAX value)
					if (payoffWithNeighbor > this.currentPayoff)
						this.currentPayoff = payoffWithNeighbor;
					
				} else {

					// add to the global payoff as we are adding values
					this.currentPayoff += payoffWithNeighbor;
				}			 

			}						 

		}
		
		// CUSTOMIZE WAY OF AGGREGATION
		if (ModelParameters.PAYOFF_AGGREGATION.compareTo("AVG") == 0) {
			this.currentPayoff /= neighbors.size();
		}
		
		// in case no opposite neighbors, we set the payoff to the minimum possible float value
		if (allSameRole)
			this.currentPayoff = -1 * Float.MAX_VALUE;
		
		//System.out.println("\n**Total payoff for A-" + this.gamerAgentId + ": " + this.currentPayoff);		 

		return this.currentPayoff;
	}



	/**
	 * With this function we update the strategy using the Fermi distribution
	 * from the neighbors of the agent (having the same role)
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return true if the agent has changed its strategy w.r.t. its previous
	 *         strategy
	 */
	private boolean fermiRule(SimState state) {

		Model model = (Model) state;
		
		ArrayList<Integer> neighbors;
		
		// IMPORTANT: These agents must be different from the agent itself and having the same role 
		// (we have two roles, tourists and stakeholders)
		
		// if we have a SN structure, we get all the neighbors of the agent in the SN
		neighbors = (ArrayList<Integer>) model.socialNetwork.returnNeighboringAgentIdsOfNode(this.socialNetworkIndex);

		// iterate to only add those neighbors having the same role	to be imitated
		ArrayList<Integer> valuesIdNeighbors = new ArrayList<Integer>();
		for (int pos = 0; pos < neighbors.size(); pos++) {
			
			GamerAgent neighbor = (GamerAgent) (model.getAgents()).get(neighbors.get(pos));
			
			if (this.hasSameRoleOnPreviousStep(neighbor)) 
				
				// add its agentID as they have the same role
				valuesIdNeighbors.add(neighbor.getGamerAgentId());			
														
		}				
		
		// first check if the agent has neighbors
		if (valuesIdNeighbors.size() > 0) {

			// get one neighbor at random 
			int j = model.random.nextInt(valuesIdNeighbors.size());
			GamerAgent neighbor = (GamerAgent) (model.getAgents()).get(valuesIdNeighbors.get(j));

			double neighPayOff = 0.;
			double focalAgentPayOff = 0.;

			neighPayOff = neighbor.getPreviousPayoff();
			focalAgentPayOff = this.getPreviousPayoff();

			// calculate the prob using the Fermi distribution and payoffs' difference

			double kappa = 0.1; // Wang/Perc 2021 and WangPRE 2021 set this \kappa to 0.1

			double prob = 1.0 / (1 + Math.exp(-1 * (neighPayOff - focalAgentPayOff) / kappa ));

			// Check if the agent adopts the neighbor's strategy

			double r = model.random.nextDouble(true, true);

			if (r < prob) {

				// change the strategy!
				this.setCurrentStrategy(neighbor.getPreviousStrategy());

				//System.out.println("\n** Fermi: A-" + this.gamerAgentId + " (payoff ) " + focalAgentPayOff 
				//		+ " imitates A-" + neighbor.gamerAgentId + " and payoff " + neighPayOff + " with a prob of " + prob);		 

				return true;
				
			} else  {

				//System.out.println("\n** Fermi: A-" + this.gamerAgentId + " (payoff ) " + focalAgentPayOff 
				//		+ " DO NOT imitate A-" + neighbor.gamerAgentId + " and payoff " + neighPayOff + " with a prob of " + prob);		 

			}
		}

		return false;
	}

	
	/**
	 * Mutate the strategy (preserving the role: tourist is always a tourist, and stakeholder is always a stakeholder)
	 * @return if it is mutated
	 * @param state
	 */
	public boolean mutateStrategy (SimState state) {

		Model model = (Model) state;
		
		double r = model.random.nextDouble (true, true);
				
		if (r < model.getParametersObject().getMutProb()) {
			
			//System.out.print("\n ** Mutation: A-" + this.gamerAgentId + " from " + this.previousStrategy);
			
			// mutate to the new strategy (it can be the current one)
			// IMPORTANT: we cannot mutate to a different role
			// nextInt() returns a random integer drawn from between 0 to n - 1 inclusive

			if (this.previousStrategy > 0)				
				
				// it is a tourist, so positive values (either 1 or 2)
				this.currentStrategy = (byte) (1 + model.random.nextInt(2));		
			
			else if (this.previousStrategy < 0)
				
				// it is a stakeholder, so negative values (either -1 or -2)
				this.currentStrategy = (byte) (-1 * (1 + model.random.nextInt(2)));			

			
			//System.out.println(" to " + this.currentStrategy);
			
			return true;	
			
		} else 
			
			return false;					
	}
	

	/**
	 * Migrate if the strategy is being tourist to an empty cell, given a speed
	 * @return if the agent moved
	 * @param state
	 */
	public boolean migrate (SimState state) {
				
		Model model = (Model) state;
					
		ArrayList<Integer> vacantPositions = 
				(ArrayList<Integer>) model.socialNetwork.returnVacantNeighboringPositions(this.socialNetworkIndex);
		
		if (vacantPositions.size() > 0) {
			
			int posToMove;
			
			//if (! model.params.haveCellsAttraction()) 
				
			// no particular attraction, so just one position at random
			posToMove = vacantPositions.get(model.random.nextInt(vacantPositions.size()));	
			
			/*else {
				
				// there is attraction for every cell so we migrate with a prob depending on this attractiveness
				// we also include the agent position as well
				
				double vecProbs[] = new double[vacantPositions.size() + 1];  // +1 because we include the agent's position
				vecProbs[0] = model.socialNetwork.getAttractOfNode(this.socialNetworkIndex);
				//System.out.println(vecProbs[0]);

				for (int k = 1; k < (vacantPositions.size() + 1); k++) {
					vecProbs[k] = model.socialNetwork.getAttractOfNode(vacantPositions.get(k - 1));
					//System.out.println(vecProbs[k]);
				}
				
				int posVecProbs = util.Functions.randomWeightedSelection(vecProbs, model.random.nextDouble());
				
				if (posVecProbs == 0) {
					// we do not move as the current position is the chosen one so we leave the function
					return false;	
					
				} else {
					// we move to another vacant cell around
					posToMove = vacantPositions.get(posVecProbs - 1);
				}
								
				//System.out.println("posVecProbs is " + posVecProbs + ", moved to pos " + posToMove);
			}*/
						
			// swap positions for the agent
			//System.out.println(model.socialNetwork.getAttractOfNode(posToMove));
			
			//System.out.println("Step " + (int) model.schedule.getSteps() + ": Agent " + this.gamerAgentId + " with str. " + this.currentStrategy + " from " + this.socialNetworkIndex
			//		+ " to " + posToMove);
			
			
			model.socialNetwork.setAgentToNode(ModelParameters.VACANT_NODE, this.socialNetworkIndex);
			this.socialNetworkIndex = posToMove;
			model.socialNetwork.setAgentToNode(this.gamerAgentId, posToMove);
			return true;				
							
		} else			
			return false;				
		
	}
	
	
	/**
	 * With this function we update the strategy used by the agent. We use the
	 * defined imitative ev. dynamics rule for calculating the change (if there is a
	 * change)
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return true if the agent has changed its strategy w.r.t. its previous
	 *         strategy
	 */
	public boolean updateRuleForStrategy(SimState state) {

		Model model = (Model) state;

		// it does not make sense to do it for the first step

		try {
			
			switch (model.getParametersObject().getUpdateRule()) {

			case ModelParameters.PROPORTIONAL_UPDATE_RULE:
				throw new IOException("Only the Fermi rule is implented\n");

			case ModelParameters.UI_UPDATE_RULE:
				throw new IOException("Only the Fermi rule is implented\n");

			case ModelParameters.VOTER_UPDATE_RULE:
				throw new IOException("Only the Fermi rule is implented\n");

			case ModelParameters.FERMI_UPDATE_RULE:
				return this.fermiRule(state);

			case ModelParameters.WF_UPDATE_RULE:
				throw new IOException("Only the Fermi rule is implented\n");

			}
		} catch (IOException e) {

			System.err.println("GamerAgent rule: Error when selecting the update rule: " + e.getMessage());
			e.printStackTrace(new PrintWriter(System.err));
		}
		
		return false;

	}

	// --------------------------- Steppable method --------------------------//

	/**
	 * Step of the simulation.
	 * 
	 * @param state - a simulation model object (SimState).
	 */

	// @Override
	public void step(SimState state) {

		Model model = (Model) state;

		currentStep = (int) model.schedule.getSteps();

		if (currentStep > 0) {
			
			// mutate the strategy or not	
			if (!this.mutateStrategy (state)) 
				
				// if we are not mutating, we imitate by applying the update rule
				this.updateRuleForStrategy(state);		
			
			// migrate if active and it is a tourist
			if ( (model.params.speedMigration > 0) && 
					(currentStrategy == ModelParameters.COOPERATOR_TOURIST || currentStrategy == ModelParameters.DEFECTOR_TOURIST)) 
				
				this.migrate(state);
						
		}

	}
}
