package socialnetwork;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.TreeMap;

import model.ModelParameters;

import org.graphstream.algorithm.Toolkit;
import org.graphstream.graph.Edge;
import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.implementations.Graphs;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.algorithm.ConnectedComponents;

import util.Colors;


/**
 * Incorporates a social network graph (lattice) from the GraphStream framework.
 * 
 * CREATE A WRAPPER JUST FOR A STATIC LATTICE NETWORK... 
 * 
 * @author mchica
 * 
 */


public class LatticeGraphStreamer {

	// ########################################################################
	// Static
	// ########################################################################
		
	// types of Social Networks
	public static enum NetworkType { 
		SCALE_FREE_NETWORK, RANDOM_NETWORK, SW_NETWORK, WELL_MIXED_POP, EMAIL_NETWORK, PGP_NETWORK, REGULAR_NETWORK
	}
	
	// ########################################################################
	// Variables
	// ########################################################################	
	
	private Graph graph;	
	
	// treemap with the neighbours of the nodes 
	private TreeMap<Integer, ArrayList<Integer>> mapNeighbours;	

	// we calculate avgDegree and save here when loading the graph 
	double avgDegreeGraph = 0.;
	
	// we calculate density and save here when loading the graph 
	double densityGraph = 0.;
	
	     
	// ########################################################################
	// Constructors
	// ######################################################################## 	
	
	/**
	 * Constructor for getting the DSG file (static SN)
	 * 
	 * @param nrNodes
	 * @param _graph
	 * 
	 */
	public LatticeGraphStreamer(ModelParameters params) {
					
		
		graph = new SingleGraph("SNFromFile");
		
		/*if (graph != null)
			graph.clear();
		else 
			graph = new SingleGraph("SNFromFile");
		
		FileSourceDGS fileSource = new FileSourceDGS();
						
		fileSource.addSink(graph);
		
		try {
			
			fileSource.readAll(params.getNetworkFilesPattern());
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.err.println("Error when reading SN file");
			e.printStackTrace();
		}

		fileSource.removeSink(graph);*/
		
		graph.addAttribute("ui.antialias");
		graph.addAttribute("stylesheet", "graph {padding : 20px;}" 
				+ "node {fill-mode: dyn-plain; fill-color: black;}"
				+ "node.company "
				+ "{fill-mode: dyn-plain; fill-color: red, green, blue;}");					
				
	}
	

	/** 
	 * with this function we copy the initial network read from a file
	 * in order not to have edges removed and added
	 * 
	 * @param params
	 */
	public void setGraph (ModelParameters params) {

		graph.clear();
		
		Graphs.mergeIn(graph, params.getGraph());		
		
		this.avgDegreeGraph = Toolkit.averageDegree(graph);
		this.densityGraph = Toolkit.density(graph);
		
		// while read we create a hash map with the neighbours
		this.mapNeighbours = new TreeMap <Integer, ArrayList<Integer>> ();

		for (int i = 0; i < graph.getNodeCount(); i++) {

			// get neighbours of the i-th node
			ArrayList<Integer> neighbors = getNeighborsOfNodeFromGS(i);			
			this.mapNeighbours.put(i, neighbors);						
		}
	}
	
		
	// ########################################################################	
	// Methods/Functions
	// ########################################################################
	
	
	public Graph getGraph() {
		return graph;
	}

	public void setGraph(Graph graph) {
		this.graph = graph;
	}

	/**
	 * to free the object of the graph and all their structures we unset the graph�
	 * 
	 */
	public void removeGraph() {
		this.graph = null;
	}

	/**
	 * return a list of the nodes' indexes of a node which are neighbors
	 * 
	 * @param _index - index of the node.
	 * @return - the neighbors indexes in the ArrayList.
	 */
	public ArrayList<Integer> getNeighborIndexesOfNode(int _index) {
						
		return this.mapNeighbours.get(_index);
			
	}	
	
	/**
	 * return a list of the nodes' indexes of a node which are neighbors
	 * 
	 * @param _index - index of the node.
	 * @return - the neighbors indexes in the ArrayList.
	 */
	public ArrayList<Integer> returnNeighboringAgentIdsOfNode (int _index) {
						
		ArrayList<Integer> indexesNeighborsOfNode = this.mapNeighbours.get(_index);
		ArrayList<Integer> returningAgentIDsNeighbors = new ArrayList<Integer>();
		
        for (Integer indexNeighbor : indexesNeighborsOfNode) {

        	int agentIdNeighbor = (graph.getNode(indexNeighbor)).getAttribute("agentID");
        	
        	if ( agentIdNeighbor != ModelParameters.VACANT_NODE) 
        		returningAgentIDsNeighbors.add(agentIdNeighbor);        	      	
        	
        }
		
		return returningAgentIDsNeighbors;			
	}	
	
	/**
	 * return a list of possible neighboring nodes of the network to move for a given position
	 * 
	 * @param _index - index of the node.
	 * @return - the neighboring empty indexes in the ArrayList.
	 */
	public ArrayList<Integer> returnVacantNeighboringPositions (int _index) {
						
		ArrayList<Integer> indexesNeighborsOfNode = this.mapNeighbours.get(_index);
		ArrayList<Integer> vacantPositions = new ArrayList<Integer>();
		
        for (Integer indexNeighbor : indexesNeighborsOfNode) {
        	
        	int agentIdNeighbor = (graph.getNode(indexNeighbor)).getAttribute("agentID");

        	//System.out.print ("agent id " +  agentIdNeighbor + " is a neighbor at index node " + indexNeighbor + " of focal"
        	//		+ " at index " + _index);
        	
        	if ( agentIdNeighbor == ModelParameters.VACANT_NODE )  {
        		//System.out.println(". WE ADDED IT AS VACANT");
        		vacantPositions.add(indexNeighbor);   
        	} else {
        		//System.out.println(". WE DO NOT ADD IT AS VACANT");
        	}
        	
        	
        }
		
		return vacantPositions;			
	}	
	
	/**
	 * TODO BOTTLENECK Gets the neighbors of the given node. 
	 * @param ind - index of the node.
	 * @return - the neighbors in the ArrayList.
	 */
	private ArrayList<Integer> getNeighborsOfNodeFromGS (int ind) {
		
		ArrayList<Integer> neighbors = new ArrayList<Integer>();
		
		Iterator<Node> it = graph.getNode(ind).getNeighborNodeIterator();
		
		//int posValue = -1, value = -1;
		while(it.hasNext()) {
			
			int tmpInd = it.next().getIndex();
			neighbors.add(tmpInd);
			
			/*
			// insert in the correct position to have an ordered list
			if (neighbors.size() > 0) {
				posValue = neighbors.size();
				value = neighbors.get(posValue - 1);

				while (posValue > 0 && tmpInd < value) {
					posValue --;
					if (posValue > 0)
						value = neighbors.get(posValue - 1);
				}
									
				// System.out.println("to insert " + tmpInd + ", trying to put in pos " + posValue 
				//	+ ". Previous element is " + value);
								
			} else {
				posValue = 0;
			}
						
			neighbors.add(posValue, tmpInd);
			
			//System.out.println("printing neighbors: " + neighbors.toString()); */
			
		}
		
		// Sort the neighbors as their ids are returned in the arbitrary order.
		Collections.sort(neighbors);
		
		return neighbors;
	} 

	/**
	 * set a value to the attribute of an edge given by two nodes
	 * (it creates it if it doesn't exist)
	 * 
	 * @param index1 - index of the first node.
	 * @param index2 - index of the second node.
	 * @param key - the string key of the attribute of the edge
	 * @param value - the object value to be set for the attribute of the edge
	 */
	public void setAttributeEdge(int index1, int index2, String key, Object value ) {
		
		Edge edgeNodes = (graph.getNode(index1)).getEdgeBetween(index2);
		
		if (edgeNodes == null) {
			System.err.println("Error (setAttributeEdge) when getting an edge between node "+
						index1 + " and node " + index2);
		}
		
		edgeNodes.setAttribute(key, value);		
	}
	
	/**
	 * set a an agent (agentId) to a node of the network
	 * 
	 * @param agentId - agent Id to set
	 * @param indexOfTheNode - index of the node.
	 */
	public void setAgentToNode (int agentId, int indexOfTheNode) {
		
		(graph.getNode(indexOfTheNode)).setAttribute("agentID", agentId);
		
	}
	
	/**
	 * set the attractiveness to node
	 * 
	 * @param value - the value of attractiveness
	 * @param indexOfTheNode - index of the node.
	 */
	public void setAttractToNode (int indexOfTheNode, float value) {
		
		(graph.getNode(indexOfTheNode)).setAttribute("attract", value);
		
	}
	
	/**
	 * set the attractiveness to node
	 * 
	 * @param indexOfTheNode - index of the node.
	 */
	public float getAttractOfNode (int indexOfTheNode) {
		
		return (graph.getNode(indexOfTheNode)).getAttribute("attract");
		
	}
	
	/**
	 * get the agent (agentId) of a node of the network (-1 if empty or unassigned node)
	 * 
	 * @param indexOfTheNode - index of the node.
	 * @return the agentId of the node (-1 if no agent is assigned)
	 */
	public int getAgentFromNode (int indexOfTheNode) {
		
		return (graph.getNode(indexOfTheNode)).getAttribute("agentID");
		
	}
	
	/**
	 * reset all the nodes of the lattice to ModelParameters.UNASSIGNED_SN_NODE for the agents' assignment
	 * 
	 */
	public void resetAgentsAssignment () {		
	
		Iterator<Node> it = graph.getNodeIterator();
		
		while(it.hasNext()) {
			it.next().setAttribute ("agentID", ModelParameters.VACANT_NODE);
		}
				
	}
	
	/**
	 * set all the attractiveness values of the nodes of the lattice
	 * 
	 */
	public void setAttractivenessAllNods (float _attractValues[]) {		
	
		Iterator<Node> it = graph.getNodeIterator();
		
		int k = 0;
		while(it.hasNext()) {
			
			float value = _attractValues[k];
			k++;
			
			it.next().setAttribute ("attract", value);
			//System.out.println("node " + k + " with att " +  value);
		}
				
	}
	
	/**
	 * set the same value to the attributes of the edges
	 * of all the neighbors of the given node
	 * (it creates it if it doesn't exist)
	 * 
	 * @param index - index of the first node.
	 * @param key - the string key of the attribute of the edges
	 * @param value - the object value to be set for the attribute of the edges
	 */
	public void setAttributeEdgeAllNeighbours(int index, String key, Object value ) {
				
		Iterator<Node> it = graph.getNode(index).getNeighborNodeIterator();
		
		while(it.hasNext()) {
			
			// get the edge 
			int indNeighbor = it.next().getIndex();			
			Edge edgeNodes = (graph.getNode(index)).getEdgeBetween(indNeighbor );
			
			if (edgeNodes == null) {
				System.err.println("Error (setAttributeEdgeAllNeighbours) when getting an "
						+ "edge between node " +	index + " and node " + indNeighbor);
			}
			
			// set the attribute value
			edgeNodes.setAttribute(key, value);								
		}		
	}
	

	/**
	 * get a value of the attribute of an edge given by two nodes
	 * (it creates it if it doesn't exist)
	 * 
	 * @param index1 - index of the first node.
	 * @param index2 - index of the second node.
	 * @param key - the string key of the attribute of the edge
	 * @return the object value of the attribute of the edge
	 */
	public Object getAttributeEdge(int index1, int index2, String key) {

		Edge edgeNodes = (graph.getNode(index1)).getEdgeBetween(index2);
		
		if (edgeNodes == null) {
			System.err.println("Error (getAttributeEdge) when getting an edge between node "+
						index1 + " and node " + index2);
		}
		
		return edgeNodes.getAttribute(key);	
		
	}		
	
	
	/**
	 * Sets node's color in case of buying a product 
	 * or changing the company (product).
	 * @param ind - the index of the node.
	 * @param val - the current index of the company.
	 * @param tot - the total nr of companes.
	 */
	public void setNodeColor(int ind, int val, int tot) {
		
		Node n = graph.getNode(ind);
		// Colors vary between 0 and 1; we have to normalize the value: val/tot
		double tmp = (double) val/tot;
		n.setAttribute("ui.class", "company");
		n.setAttribute("ui.color", tmp );
	}
	
	

	/**
	 * Sets node's color in case of buying a product or changing the brand.
	 * @param ind - the index of the node.
	 * @param val - the current index of the company.
	 * @param col - the color to be set.
	 */
	public void setNodeColor(int ind, int val, Colors col) {
		Node n = graph.getNode(ind);
		
		// Use directly rgb function
		n.addAttribute("ui.style", "fill-color: rgb(" 
				+ col.getPaletteColorRed(val) + "," 
				+ col.getPaletteColorGreen(val) + "," 
				+ col.getPaletteColorBlue(val) + ");");
		// Example usage of rgb
		//n.addAttribute("ui.style", "fill-color: rgb(0,100,255);");
	}

	/**
	 * Removes node's color in case of not buying anything.
	 * @param ind - the index of the node.
	 */
	public void removeNodeColor(int ind) {
		
		Node n = graph.getNode(ind);
		// PREVIOUS IMPLEMENTATION
		//n.removeAttribute("ui.class");
		// Set to black
		n.addAttribute("ui.style", "fill-color: rgb(0, 0, 0);");
	}
	
	public void cleanGraph () {
		this.graph = null;
	}
	
	public double getAvgDegree() {
		return avgDegreeGraph;
	}
	
	public double getDensity() {
		return densityGraph;
	}
	
	public int getConnectedComponents() {
		ConnectedComponents cc = new ConnectedComponents();
		cc.init(this.graph);
		return cc.getConnectedComponentsCount();
	}	
	
}
