package util;

import java.awt.Point;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.graphstream.graph.Graph;
import org.graphstream.ui.graphicGraph.GraphPosLengthUtils;

import model.GamerAgent;
import sim.util.Bag;

/**
 * Static class to calculate the spatio-temporal correlation of a lattice
 * This is done in a similar way than in the paper 'Is the Voter Model a model for voters?' 
 * from Fernadez-Gracia et al. published in Ph. Rev. Letters
 *
 * @author mchica
 */
public class SpatialCorrelationSN {   

	static int l;  			///  the distance between cells/nodes for calculating the values
 
	static Graph socialNetwork;    // the SN (initially just a lattice)

	static int matrixLattice [][];

	static Set<java.awt.Point> listPairsPositions;

	static ArrayList<GamerAgent> listAgents_i;
	static ArrayList<GamerAgent> listAgents_j;
	
	static int numNodes;
	
	
	/**
	 * Set social network, distance 'l' to calculate correlations, and calculate pairs of agents which are at a distance 'l'
	 * @param _socialNetwork
	 * @param _l the distance to define the bin of neighbors
	 */

	public static void setParameters (Bag _agents, Graph _socialNetwork, int _l) { 

		// distance
		l = _l;

		// check that this is a lattice SN
		
		socialNetwork = _socialNetwork;
		numNodes = socialNetwork.getNodeCount();
		
		// create lattice matrix

		int n = Math.round((float)Math.sqrt(numNodes));
		matrixLattice = new int[n][n];
		
		// get all the agents and find out the position of their associated nodes to set the strategy
		
		for (int i = 0; i < numNodes; i++) {					
			
			// get position 
			int idNode = ((GamerAgent) _agents.get(i)).getGamerAgentId();
									
			double pos[] = new double[3];								
			GraphPosLengthUtils.nodePosition(socialNetwork.getNode(idNode), pos);

			matrixLattice[((int)pos[0])][((int)pos[1])] = idNode;								
		}

		// calculate pairs of points at distance 'l' and put in the list
		
		listPairsPositions = new HashSet <java.awt.Point>();
		listAgents_i = new ArrayList <GamerAgent> ();
		listAgents_j = new ArrayList <GamerAgent> ();
		 
		for (int i = 0; i < numNodes; i++) {	
			// get position 
			int idNode = ((GamerAgent) _agents.get(i)).getGamerAgentId();
									
			double pos[] = new double[3];								
			GraphPosLengthUtils.nodePosition(socialNetwork.getNode(idNode), pos);
			
			// from x,y of point 'i' we calculate the 4 possible neighbors at distance 'l' 
			// with periodic conditions in the lattice
				
			int x = (int)pos[0];
			int y = (int)pos[1];

			// System.out.println("\nx is " + x + " y is: " + y);
			
			// calculate coordinates at a distance
			int x_plus_l = x + l;
			int x_minus_l = x - l;
			int y_plus_l = y + l;
			int y_minus_l = y - l;

			//System.out.println("x+l: " + x_plus_l +", x-l:"+ x_minus_l + " y+l: " + y_plus_l + ", y-l:" + y_minus_l);
			
			if (x_plus_l >= n) 
				x_plus_l = x_plus_l - n;
			if (x_minus_l < 0) 
				x_minus_l = n + x_minus_l;  
			if (y_plus_l >= n) 
				y_plus_l = y_plus_l - n;
			if (y_minus_l < 0) 
				y_minus_l = n + y_minus_l; 

			//System.out.println("After calcs: x+l: " + x_plus_l +", x-l:"+ x_minus_l + " y+l: " + y_plus_l + ",y-l:" + y_minus_l);
			
			// j = (x + l, y)
			if ( !(listPairsPositions.contains((new Point (matrixLattice[x_plus_l][y], matrixLattice[x][y]))))) {			
				listPairsPositions.add(new Point (matrixLattice[x][y], matrixLattice[x_plus_l][y]));
			}
			  
			// j = (x, y + l
			if ( !(listPairsPositions.contains((new Point (matrixLattice[x][y_plus_l], matrixLattice[x][y] ))))) {
				listPairsPositions.add(new Point (matrixLattice[x][y], matrixLattice[x][y_plus_l]));
			}
			
			// j = (x - l, y)
			if ( !(listPairsPositions.contains((new Point (matrixLattice[x_minus_l][y], matrixLattice[x][y]))))) {				
				listPairsPositions.add(new Point (matrixLattice[x][y], matrixLattice[x_minus_l][y]));
			}
			
			// j = (x, y - l)
			if ( !(listPairsPositions.contains((new Point (matrixLattice[x][y_minus_l], matrixLattice[x][y]))))) {								
				listPairsPositions.add(new Point (matrixLattice[x][y], matrixLattice[x][y_minus_l]));
			}					
		}
		
		//System.out.println("Totally we have added " + listPairsPositions.size() + " elements");
			
			
		/*for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++)
					
				System.out.print(matrixLattice[i][j] + ", ");

			System.out.println("");
		}
			    
		    
		while (iterator.hasNext()){
			System.out.println("Value: " + iterator.next() + " ");  
		}*/
		
		
		Iterator<Point> iterator = listPairsPositions.iterator(); 
		
		iterator  = listPairsPositions.iterator(); 
		while (iterator.hasNext()){
			
			Point p = iterator.next();
			int id_agent_i = (int)p.getX();
			int id_agent_j = (int)p.getY();
			
			boolean encontrado_i = false;
			boolean encontrado_j = false;
			
			for (int k = 0; k < _agents.size() && (!encontrado_i || !encontrado_j); k++) {
				
				if (((GamerAgent) _agents.get(k)).getGamerAgentId() == id_agent_i) {
					listAgents_i.add(((GamerAgent) _agents.get(k)));
					encontrado_i = true;
				}
				
				if (((GamerAgent) _agents.get(k)).getGamerAgentId() == id_agent_j) {
					listAgents_j.add(((GamerAgent) _agents.get(k)));
					encontrado_j = true;
				}	
			}	
			
		}		

	}

	/**
	 * 
	 * Returns, from a given node, a neighbor at distance 'l' at random 
	 * 
	 * @param _x coordiante x of the node origin
	 * @param _y coordiante y of the node origin
	 * @param _l
	 * @return the id of the agent who is a neighbor at distance 'l' from the agent passed as an argument
	 */
	public static int getRandomeNeighborAtDistance (int _x, int _y, int _l) {
		
		// locate the node in the matrix and add _l

		// calculate coordinates at a distance l
		int x_plus_l = _x + _l;
		//int y_plus_l = _y + _l;
		int y_plus_l = _y ;
		
		
		if (x_plus_l >= matrixLattice.length) 
			x_plus_l = x_plus_l - matrixLattice.length;
		if (y_plus_l >= matrixLattice.length) 
			y_plus_l = y_plus_l - matrixLattice.length;
	
		return matrixLattice[x_plus_l][y_plus_l];
				
	}
	
	
	/**
	 * 
	 * Calculate the correlation coefficient for the given step
	 * 
	 * @param _step the current step for getting the payoffs and calculate difference 
	 * @param _payoff if this parameter is true, we calculate temporal correlation w.r.t. to payoffs of the agents. If false, strategy difference
	 * @return the correlation coefficient for that step
	 */
	public static double calcSpatioTempCorr (int _step, boolean _payoff) {
		
		if (listAgents_i.size() != listAgents_j.size()) {

			 System.err.println( "Fatal Error!! Different number of paired agents to calculate differences in payoffs.\n");
						
		}
		
		// calculate for each pair (i,j) / d(i,j)=l, the difference in the payoffs/strategies (v_i-v_j)^2
		// (v_i -v_j)^2 where  d(i,j)=l
		
		double value = 0;
		
		for (int k = 0; k < listAgents_i.size(); k++) {
			
			if (_payoff == true) {

				// calculate the difference w.r.t. payoff value
				
				double payoff_i = ((GamerAgent) listAgents_i.get(k)).getPayoff(_step);
				double payoff_j = ((GamerAgent) listAgents_j.get(k)).getPayoff(_step);

				value +=  (payoff_i - payoff_j) * (payoff_i - payoff_j) ; 
			
				//System.out.println("k=" + k + " payoff_i is " + payoff_i + ", payoff_j is " + payoff_j + ". Value is " + value);
				
			} else {
				
				// calculate the difference w.r.t. strategy (1,2,3)
				
				double strategy_i = ((GamerAgent) listAgents_i.get(k)).getEvolutionStrategies(_step);
				double strategy_j = ((GamerAgent) listAgents_j.get(k)).getEvolutionStrategies(_step);

				// changed: instead of calculating a distance, we compute 0 if equal, 1 is different 
				// value +=  (strategy_i - strategy_j) * (strategy_i - strategy_j); 
				
				// g(l) = \sum (1 if different strategies)
				if (strategy_i != strategy_j)
					value +=  1; 
				else
					value +=  0; 
				
				//System.out.println("k=" + k + " strategy_i is " + strategy_i + ", strategy_j is " + strategy_j + ". Value is " + value);
			}
			
		}
		
		// third, average the accumulated value
		
		value = value / listAgents_i.size();

		// System.out.println("Final value is " + value);
		
		return value;
	}
	

}
