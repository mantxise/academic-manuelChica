package util;

import java.util.Locale;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

/**
 * Class to save arrays of the KPIs of the simulation for max/min/stdev and other stats
 * 
 * @author mchica
 * @date 2022/04/25
 * @place Oeiras, Lisboa
 */

public class StatsArrayData {		

	private int numberRuns;				// number of MC simulations
	private int numberSteps;			// number of steps simulation
	
	// fields for storing the data
	private double dataMatrix[][];			// all the KPI information from the simulation(each for run and step)
	private double avgDataMatrix[];			
	private double stdDataMatrix[];			
	private double[] minDataMatrix;
	private double[] maxDataMatrix;

	private double lastQuartileValue;
	private double lastQuartileValueAvg;
	private double lastQuartileValueStd;

	private String keyString;		// the key to show or print together with the value
	
	
	
	/**
	 * @param _data the data to set for run _numberOfRun
	 */
	public void setDataMatrixForRun (int _numberOfRun, double _data[]) {

		for (int i = 0; i < this.numberSteps; i++)
			this.dataMatrix[_numberOfRun][i] = _data[i];
	}

	/**
	 * @return the numberRuns
	 */
	public int getNumberRuns() {
		return numberRuns;
	}

	/**
	 * @param _numberRuns the numberRuns to set
	 */
	public void setNumberRuns(int _numberRuns) {
		this.numberRuns = _numberRuns;
	}
	
	/**
	 * @return the numberSteps
	 */
	public int getNumberSteps() {
		return numberSteps;
	}

	/**
	 * @param _numberSteps the numberSteps to set
	 */
	public void setNumberSteps(int _numberSteps) {
		this.numberSteps = _numberSteps;
	}

	/**
	 * 
	 */
	public String getKeyString () {
		return this.keyString;
	}
	
	/**
	 * 
	 */
	public void setKeyString (String _v) {
		this.keyString = _v;
	}
	
	/**
	 * @param 
	 */
	public void computeLastQuartile () {

		for ( int i = 0; i < this.numberRuns; i++) {
			
			this.lastQuartileValue = 0.;
			
			// check the number of steps which means the last 25% of them
			int quartileSteps = (int) Math.round(0.25 * this.numberSteps);
			
			for ( int j = 1; j <= quartileSteps; j++) 
				lastQuartileValue += this.dataMatrix[i][(this.numberSteps - j)];
			
			lastQuartileValue /= quartileSteps;
			
		}
		
	}
	
	//--------------------------- Constructor ---------------------------//
	/**
	 * constructor of StatsArrayData
	 * @param _nRuns
	 */
	public StatsArrayData (String _key, int _nRuns, int _nSteps){

		this.keyString = _key;
		this.numberRuns = _nRuns;
		this.numberSteps = _nSteps;
		
		this.avgDataMatrix = new double[_nSteps];	
		this.stdDataMatrix = new double[_nSteps];
		this.minDataMatrix = new double[_nSteps];	
		this.maxDataMatrix = new double[_nSteps];
	}
			
	/**
	 * 
	 */
	public String returnTimeSeriesStatsAtStep(int _step) {
		
		return String.format(Locale.US,"%.4f", this.minDataMatrix[_step]) + ";" + String.format(Locale.US,"%.4f", this.maxDataMatrix[_step]) + ";\n";

	}
	
	/**
	 * 
	 */
	public String returnSummaryStatsAtFinalStep() {
		
		return String.format(Locale.US,"%.4f", this.avgDataMatrix[(this.numberSteps - 1)]) + ";" + 
				String.format(Locale.US,"%.4f", this.stdDataMatrix[(this.numberSteps - 1)]) + ";";

	}
	
	/**
	 * 
	 */
	public String returnAllStatsLQ () {
		
		return this.keyString + ";" + String.format(Locale.US,"%.4f", this.lastQuartileValue) + ";";

	}
	
	/**
	 * 
	 */
	public String returnSummaryStatsByAveragingLQ () {
				
		return this.keyString + ";"	+ String.format(Locale.US,"%.4f", lastQuartileValueAvg) + ";" + String.format(Locale.US,"%.4f", lastQuartileValueStd) + ";";

	}
	
	
	/** 
	 * function to calculate the basic stats of the data and store it
	 */
	public void calcAllStats () {
		
		for( int j = 0; j < this.numberSteps; j++) {
			
			// Get a DescriptiveStatistics instance
			DescriptiveStatistics stats= new DescriptiveStatistics();
			
			// Add the data from the array
			for( int i = 0; i < this.numberRuns; i++) 				        
		        stats.addValue(this.dataMatrix[i][j]);	        
		       
			// calc mean and average for all of them
			
			this.avgDataMatrix[j] = stats.getMean();	
			this.stdDataMatrix[j] = stats.getStandardDeviation();
			this.minDataMatrix[j] = stats.getMin();	
			this.maxDataMatrix[j] = stats.getMax();
	
		}
	}
	
}

