package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import sim.engine.*;
import sim.util.*;

import socialnetwork.*;
import util.BriefFormatter;
import util.Functions;

// https://github.com/eclipse/eclipse-collections/blob/master/docs/guide.md#eclipse-collections-reference-guide
import org.eclipse.collections.impl.list.mutable.FastList;
import org.eclipse.collections.impl.list.mutable.primitive.IntArrayList;
import org.eclipse.collections.impl.set.mutable.primitive.IntHashSet;
import org.graphstream.algorithm.Toolkit;
import org.graphstream.graph.Node;

// random generator from DSI of Milano
import it.unimi.dsi.util.*;



/**
 * Simulation core, responsible for scheduling agents of the evolutionary game
 * 
 * @author mchica
 * @date 2022/04/25
 * 
 */
public class Model extends SimState {

	// ########################################################################
	// Variables
	// ########################################################################
			
	private static final long serialVersionUID = -8094551352549697295L;

	static String CONFIGFILENAME;
				
	// LOGGING
	public static final Logger log = Logger.getLogger( Model.class.getName() );
			
	// MODEL VARIABLES
	
	it.unimi.dsi.util.XoRoShiRo128PlusRandom random;
	
	ModelParameters params;
	
	Bag agents;	
	int listOfGroups[][];			// list of IDs of the agents for each group
	int numberOfGroups;			
	
	int k_C_Agents [][]; 			// a counter of the k_C agents during the simulation (by group)
	int k_D_Agents [][]; 			// a counter of the k_D agents during the simulation (by group)
	int k_P_Agents [][];			// a counter of the k_P agents during the simulation (by group)
	
	//double globalPayoffs[][];			// array with the sum of all the payoffs of the population at each step (by group)
	//double globalPayoffsWholePop[];		// array with the sum of all the payoffs of the population at each step

	double groupAchievement[];			// array with the ratio of group achievement (groups with minimum n_{pg})
	double institutionPrevalence[];		// array with the ratio of institutionPrevalence (groups with minimum n_{p})
	
	double costSeeding;
	
	// SOCIAL NETWORK
	GraphStreamer socialNetwork;
	
	FastList<org.graphstream.graph.Node> degreeMap;   // in this arrayList we will store the needed most connected nodes for a SA on Ps	
	
	int MC_RUN = -1;
	
	//--------------------------- Clone method ---------------------------//	
	
		
	//--------------------------- Get/Set methods ---------------------------//	
	//
	
	public static String getConfigFileName() {
		return CONFIGFILENAME;
	}
	
	public static void setConfigFileName(String _configFileName) {
		CONFIGFILENAME = _configFileName;
	}

	public GraphStreamer getSocialNetwork() {	
		return socialNetwork;	
	}	
		
	/**
	 * 
	 * @return the bag of agents.
	 */
	public Bag getAgents() {
		return agents;
	}

	/**
	 *  
	 * @param _agents is the bag (array) of agents
	 */
	public void setAgents(Bag _agents) {
		this.agents = _agents;
	}		
			
	/**
	 * Get the number of k_D agents at a given step - time
	 * @return the number of k_D agents
	 */
	public int getk_D_AgentsAtStep (int _position, int _group) {
		return k_D_Agents[_position][_group];
	}
	
	/**
	 * Get the number of k_C agents at a given step - time
	 * @return the number of k_C agents
	 */
	public int getk_C_AgentsAtStep (int _position, int _group) {
		return  k_C_Agents[_position][_group];
	}

	/**
	 * Get the number of k_D agents for all the period of time for the whole pop
	 * @return an ArrayList with the evolution of the k_D agents
	 */
	public int[] getk_D_WholePopArray () {
		int [] k_Ds = new int[(int) params.getIntParameter("maxSteps")];

		for (int i=0; i < (int) params.getIntParameter("maxSteps"); i++) {
			k_Ds[i] = 0;
			for (int k=0; k < this.numberOfGroups; k++) {
				k_Ds[i] += this.k_D_Agents[i][k]; 
			}				
		}
						
		return k_Ds;
	}
	
	/**
	 * Get the number of k_C agents for all the period of time and whole population
	 * @return an ArrayList with the evolution of k_C agents
	 */
	public int[] getk_C_WholePopArray () {
		int [] k_Cs = new int[(int) params.getIntParameter("maxSteps")];

		for (int i=0; i < (int) params.getIntParameter("maxSteps"); i++) {
			k_Cs[i] = 0;
			for (int k=0; k < this.numberOfGroups; k++) {
				k_Cs[i] += this.k_C_Agents[i][k]; 
			}				
		}
						
		return k_Cs;
	}

	/**
	 * Get the number of k_P agents for all the period of time and whole population
	 * @return an ArrayList with the evolution of the k_P agents
	 */
	public int[] getk_P_WholePopArray () {
		int [] k_Ps = new int[(int) params.getIntParameter("maxSteps")];

		for (int i=0; i < (int) params.getIntParameter("maxSteps"); i++) {
			k_Ps[i] = 0;
			for (int k=0; k < this.numberOfGroups; k++) {
				k_Ps[i] += this.k_P_Agents[i][k]; 
			}				
		}
						
		return k_Ps;
	}
	
	/**
	 * Get the number of k_P agents at a given step - time
	 * @return the number of k_P agents
	 */
	public int getk_P_AgentsAtStep (int _position, int _group) {
		return k_P_Agents[_position][_group];
	}
		
	/**
	 * Get the ratio of group achievement (groups with minimum Cs & Ps) for all the period of time
	 * @return an array with the group achievement
	 */
	public double[] getGroupAchievement () {
		return this.groupAchievement;
	}
		
	/**
	 * Get the ratio of institution prevalence (groups with minimum Ps to fine Ds) for all the period of time
	 * @return an array with the institution prevalence
	 */
	public double[] getInstitutionPrevalence () {
		return this.institutionPrevalence;
	}
		
		
	/**
	 * Get the parameter object with all the input parameters
	 */
	public ModelParameters getParametersObject () {
		return  this.params;
	}

	/**
	 * Set the parameters
	 * @param _params the object to be assigned
	 */
	public void setParametersObject (ModelParameters _params) {
		this.params = _params;
	}

	public double getCostSeeding() {
		return costSeeding;
	}

	public void setCostSeeding(double costSeeding) {
		this.costSeeding = costSeeding;
	}
			
	// ########################################################################
	// Constructors
	// ########################################################################

	/**
	 * Initializes a new instance of the simulation ToC class
	 * @param _params an object with all the parameters of the model
	 */
	public Model(ModelParameters _params) {
	    
		super( (long)_params.getIntParameter("seed") );	
		
		// use our specific class for random generator
		this.random = new XoRoShiRo128PlusRandom();
		this.random.setSeed((long)_params.getIntParameter("seed"));
		 
		
		try {  

	        // This block configure the logger with handler and formatter  
			long millis = System.currentTimeMillis();
			FileHandler fh = new FileHandler("./logs/" + _params.getStringParameter("outputFile") + "_" + millis + ".log");  
	        log.addHandler(fh);
	        BriefFormatter formatter = new BriefFormatter();  
	        fh.setFormatter(formatter);  
	        
	        log.setLevel(Level.FINE);

	        log.log(Level.FINE, "Log file created at " + millis +" (System Time Millis)\n");  

	    } catch (SecurityException e) {  
	        e.printStackTrace(); 	        
	    } catch (IOException e) {  
	        e.printStackTrace();  
	    }  

		// get parameters
		params = _params;	
		
		int _maxSteps =(int) params.getIntParameter("maxSteps");
		int _nrAgents =(int) params.getIntParameter("nrAgents");
	
		// creating the list of groups with IDs at random
		if (!params.getNetworkOption()) {
			
	        this.numberOfGroups = _nrAgents / (int) params.getIntParameter("groupSize");
	        this.listOfGroups = new int [this.numberOfGroups][(int) params.getIntParameter("groupSize")]; 
	        
		} else {
			
			// groups are determined by the network
			this.numberOfGroups = _nrAgents;
			this.listOfGroups = null;
			
		}
		
		// store an IDs array with the agents to be k_C, k_D, and k_P at the beginning of the simulation
		// This is done according to the parameters of their k_C, k_D, and k_P distribution
				
		// Initialization of the type of strategy counts (by group)
		k_C_Agents = new int [_maxSteps][this.numberOfGroups];
		k_D_Agents = new int [_maxSteps][this.numberOfGroups];
		k_P_Agents = new int [_maxSteps][this.numberOfGroups];
		
		// Initialization of the global payoffs by group and whole pop
		// globalPayoffs = new double [_maxSteps][this.numberOfGroups];
		institutionPrevalence = new double [_maxSteps];
		groupAchievement = new double [_maxSteps];
				
		// social network initialization from file				
		if (params.getNetworkOption()) {
			
			socialNetwork = new GraphStreamer(_nrAgents, params);
			socialNetwork.setGraph(params);		
			
			if (params.getIntParameter("SA_type") == ModelParameters.SA_targetingPsByDegree || 
					params.getIntParameter("SA_type") == ModelParameters.SA_targetingPsAtRandom || 
					params.getIntParameter("SA_type") == ModelParameters.SA_targetingCsAtRandom || 
					params.getIntParameter("SA_type") == ModelParameters.SA_targetingCsByDegree) {
				
				this.degreeMap = new FastList<Node>();
														
				// we have to obtain a tree map with the nodes ordered by degree if having SA on Ps
				this.degreeMap.addAll(Toolkit.degreeMap(socialNetwork.getGraph()));		
					
			}
			
		} else {
			
			socialNetwork = null;
		}			
	}
	
	/** 
	 * Dirty temporal method to use different SF networks from file not to use the same network always.
	 * We use 10 SFs for every 10th of the MC runs
	 * 
	 */
		
	private void loadDiffSFs () {
				
		String path = "./networks/SF-5knodes_m_3.dgs";

		int bin = this.params.getIntParameter("MCRuns") / 10;
		
		if (this.MC_RUN > bin) {
			
			if (this.MC_RUN < bin * 2) {
				
				path = "./networks/SF-5knodes_m_3_0.dgs";				
				
			} else if (this.MC_RUN < bin * 3) {
				
				path = "./networks/SF-5knodes_m_3_1.dgs";
			
			} else if (this.MC_RUN < bin * 4) {
							
				path = "./networks/SF-5knodes_m_3_2.dgs";
				
			} else if (this.MC_RUN < bin * 5) {
				
				path = "./networks/SF-5knodes_m_3_3.dgs";
				
			} else if (this.MC_RUN < bin * 6) {
				
				path = "./networks/SF-5knodes_m_3_4.dgs";
			
			} else if (this.MC_RUN < bin * 7) {
										
				path = "./networks/SF-5knodes_m_3_5.dgs";
				
			} else 	if (this.MC_RUN < bin * 8) {
				
				path = "./networks/SF-5knodes_m_3_6.dgs";
			
			} else 	if (this.MC_RUN < bin * 9) {
				
				path = "./networks/SF-5knodes_m_3_7.dgs";	
				
			} else {

				path = "./networks/SF-5knodes_m_3_8.dgs";
				
			}
		}
		
		if(path.compareTo(this.params.getStringParameter("SNFile")) != 0 ) {
			
			// the network has changed, load a new one
			try {
				this.params.setParameterValue("SNFile", path);				
				this.params.readGraphFromFile(path);
				
				socialNetwork.setGraph(params);		
				
				if (params.getIntParameter("SA_type") == ModelParameters.SA_targetingPsByDegree || 
						params.getIntParameter("SA_type") == ModelParameters.SA_targetingPsAtRandom || 
						params.getIntParameter("SA_type") == ModelParameters.SA_targetingCsAtRandom || 
						params.getIntParameter("SA_type") == ModelParameters.SA_targetingCsByDegree) {
					
					this.degreeMap = new FastList<Node>();
															
					// we have to obtain a tree map with the nodes ordered by degree if having SA on Ps
					this.degreeMap.addAll(Toolkit.degreeMap(socialNetwork.getGraph()));		
						
				}
			
			} catch (IOException e) {

				System.err.println("ModelParameters: Error when handling or opening the properties file " + CONFIGFILENAME + "\n"
						+ e.getMessage());
				e.printStackTrace(new PrintWriter(System.err));
				
			}
			
			//System.out.println("MC run " + this.MC_RUN + ". New network file read at " + path  + " with density " + socialNetwork.getDensity());
		}
		
	
	}
	//--------------------------- SimState methods --------------------------//

	/**
	 * Sets up the simulation. The first method called when the simulation.
	 */
	public void start() {

		super.start();
		
		this.MC_RUN ++;
		
		// HARDCODE TO USE DIFFERENT NETWORKS
		if (this.params.getIntParameter("typeOfNetwork") == ModelParameters.NETWORK ) 
			this.loadDiffSFs();
				
		
		if (((int) params.getIntParameter("k_C") + (int) params.getIntParameter("k_D") + (int) params.getIntParameter("k_P")) != 
				(int)params.getIntParameter("nrAgents")) {			
			System.err.println(	"Error with the k_C, k_D, k_P distribution. "
					+ "Check k_C + k_D + k_P is equal to the total number of agents \n");
		}

        final int FIRST_SCHEDULE = 0;
        int scheduleCounter = FIRST_SCHEDULE;
        
        
		// at random, create an array with the IDs unsorted. 
		// In this way we can randomly distribute the agents are going to be k_C, k_D, and k_P 
		// this is done here to change every MC simulation without changing the SN
		// IMPORTANT! IDs of the SN nodes and agents must be the same to avoid BUGS!!
		       
      
		// init variables for controlling number of agents and payoffs and other summary arrays
		for (int i = 0; i < (int) params.getIntParameter("maxSteps"); i++) {		
			
			for (int j = 0; j < this.numberOfGroups; j++) {
				k_C_Agents[i][j] = k_D_Agents[i][j] = k_P_Agents[i][j] = 0;
				//globalPayoffs[i][j] = 0.;			
			}
						
			institutionPrevalence[i] = 0.;	
			groupAchievement[i] = 0.;			
		}
						                         
        // Initialization of the agents
        agents = new Bag();
        
		IntHashSet nodesByDegree =  new IntHashSet();

		// select the nodes at random when having seeding Ps (at random)
		if (params.getIntParameter("SA_type") == ModelParameters.SA_targetingPsAtRandom || params.getIntParameter("SA_type") == ModelParameters.SA_targetingCsAtRandom ) {
			
			// shuffle map
			this.degreeMap.shuffleThis();	
		}
		
		// select the nodes by degree when having seeding Ps
		if (params.getIntParameter("SA_type") == ModelParameters.SA_targetingPsByDegree ||
				params.getIntParameter("SA_type") == ModelParameters.SA_targetingPsAtRandom) {
		
			this.costSeeding = 0;
			
			for(int k = 0; k < params.getIntParameter("initialSeedsPs"); k++) {
				
				nodesByDegree.add(this.degreeMap.get(k).getIndex());
								
				//System.out.println("node " + this.degreeMap.get(k).getIndex() + " added as seed with degree " + this.degreeMap.get(k).getDegree());
			}
		}
		
		// select the nodes by degree when having seeding Ps
		if (params.getIntParameter("SA_type") == ModelParameters.SA_targetingCsByDegree ||
				params.getIntParameter("SA_type") == ModelParameters.SA_targetingCsAtRandom) {
		
			this.costSeeding = 0;
			
			for(int k = 0; k < params.getIntParameter("initialSeedsCs"); k++) {
				
				nodesByDegree.add(this.degreeMap.get(k).getIndex());
								
				//System.out.println("node " + this.degreeMap.get(k).getIndex() + " added as seed with degree " + this.degreeMap.get(k).getDegree());
			}
		}
							
        for (int i = 0; i < (int) params.getIntParameter("nrAgents"); i++) {
        	   
        	boolean isInitialSeed = false;
        	
            char strategy = ModelParameters.UNDEFINED_STRATEGY;
             
            // if we have a SA on Ps or Cs, we have to set Ps as the most connected or random K seed nodes
            if (params.getIntParameter("SA_type") == ModelParameters.SA_targetingPsByDegree || 
					params.getIntParameter("SA_type") == ModelParameters.SA_targetingPsAtRandom || 
					params.getIntParameter("SA_type") == ModelParameters.SA_targetingCsAtRandom || 
					params.getIntParameter("SA_type") == ModelParameters.SA_targetingCsByDegree) {
    		
    			// check if it is a well-connected node
    			if (nodesByDegree.contains(i)) {
    				
    				if (params.getIntParameter("SA_type") == ModelParameters.SA_targetingPsByDegree || 
    						params.getIntParameter("SA_type") == ModelParameters.SA_targetingPsAtRandom) {
	    				// it has to be a P
	    				strategy = ModelParameters.PUNISHER;
    				}
    				
    				if (params.getIntParameter("SA_type") == ModelParameters.SA_targetingCsAtRandom || 
    						params.getIntParameter("SA_type") == ModelParameters.SA_targetingCsByDegree) {
    					// it has to be a C
	    				strategy = ModelParameters.COOPERATOR;
    				}
    				
    				// check the flag as initial seed
    				isInitialSeed = true;
    				
    				// add the cost of seeding this P by counting the number of groups it is involved (because tax * nGroups)
    				costSeeding += ((this.socialNetwork.getNeighborsOfNode(i)).size() + 1);
    				
    				//System.out.println("id = " + i + ", degree of this node is " + (this.socialNetwork.getNeighborsOfNode(i)).size() + "\n. Cost is "+ costSeeding);
    				
    				    				
    			} else {
    				
    				if (params.getIntParameter("SA_type") == ModelParameters.SA_targetingPsByDegree || 
    						params.getIntParameter("SA_type") == ModelParameters.SA_targetingPsAtRandom) {
    					
	    				 if (i < ((int) params.getIntParameter("k_C"))) 
	    		            strategy = ModelParameters.COOPERATOR;        
	    				 else if (i < ((int) params.getIntParameter("k_C") + (int) params.getIntParameter("k_D")))
			                strategy = ModelParameters.DEFECTOR;
	    				 else 
	    	    			// it is a remaining P who is not an initial seed
	    					strategy = ModelParameters.PUNISHER;     
	    				 
    				} else if (params.getIntParameter("SA_type") == ModelParameters.SA_targetingCsAtRandom || 
    						params.getIntParameter("SA_type") == ModelParameters.SA_targetingCsByDegree) {
    					
    					 if (i < ((int) params.getIntParameter("k_P"))) 
 	    		            strategy = ModelParameters.PUNISHER;        
 	    				 else if (i < ((int) params.getIntParameter("k_P") + (int) params.getIntParameter("k_D")))
 			                strategy = ModelParameters.DEFECTOR;
 	    				 else 
 	    	    			// it is a remaining c who is not an initial seed
 	    					strategy = ModelParameters.COOPERATOR; 
    					
    				}
    			}
    			
    		} else {
    			
	            if (i < (int) params.getIntParameter("k_C")) {
	                // we need to add it as k_C strategy
	                strategy = ModelParameters.COOPERATOR;
	                 
	            } else if (i < ((int) params.getIntParameter("k_C") + (int) params.getIntParameter("k_D"))) {
	                // it is a k_D strategy
	                strategy = ModelParameters.DEFECTOR;
	                 
	            } else if (i < ((int) params.getIntParameter("k_C") + (int) params.getIntParameter("k_D") + (int) params.getIntParameter("k_P"))) {                 
	                // it is a k_P strategy
	                strategy = ModelParameters.PUNISHER;
	            }
	    	}
    		
            // generate the agent, push in the bag, and schedule
            GamerAgent cl = generateAgent (i, strategy);  
            
            // set the flag as initial seed
            cl.setInitialSeed(isInitialSeed);
            
            // Add agent to the list and schedule
            agents.add(cl);
            
            // Add agent to the schedule
            schedule.scheduleRepeating(Schedule.EPOCH, scheduleCounter, cl);             
        }       
         
        // shuffle agents in the Bag and later, reassign the id to the position in the bag        
        agents.shuffle(this.random);
        
          	
        int capacity[] = new int [this.numberOfGroups];
        for (int i = 0; i < this.numberOfGroups ; i++) 
        	capacity [i] = 0;
        
        // assign agents to groups and set their parameters
        for (int agentId = 0; agentId < agents.size(); agentId++) {

        	((GamerAgent) agents.get(agentId)).setGamerAgentId(agentId);
        	
        	// set the initial endowment
        	((GamerAgent) agents.get(agentId)).setB((float) params.getIntParameter("b"));
        	
        	if (!params.getNetworkOption()) {         		
        	
	        	// at random, locate each ID in a group    
	        	int k = -1;
	        	do {
	       		
	    			// get one group at random
	    			k = this.random.nextInt(this.numberOfGroups);
	    			
	    		} while (capacity[k] >= (int) params.getIntParameter("groupSize"));
	        	
	        	this.listOfGroups[k][(capacity[k])] = agentId;
	        	
	        	// increase the members of the group	
				capacity[k] ++;			
				
				// set the number of the group to the agent
				((GamerAgent) agents.get(agentId)).setGroupId(k);
				
        	} else {
        		
        		// set the a id of the group to the id of the agent as it is the focal agent of the group
        		// (groups are determined by the network)
				((GamerAgent) agents.get(agentId)).setGroupId(agentId);
        	}
        	
        	/*if (agentId == 100 || agentId == 233)
        		System.out.println("agent id " + agentId + " with str. " + ((GamerAgent) agents.get(agentId)).getCurrentStrategy()
        				+ " has neighbors " + this.socialNetwork.getNeighborsOfNode(agentId));    
        	*/
        }	          
        
        // Add anonymous agent to calculate statistics
        setAnonymousAgentApriori(scheduleCounter);
        scheduleCounter++;    
                           
        setAnonymousAgentAposteriori(scheduleCounter);               
					
	}


	//-------------------------- Auxiliary methods --------------------------//	
	
	/**
	 * Generates the agent with its initial strategy, id, probability to act and 
	 * its computed activity array (from the latter probability).
	 * This is important as we can save time not to ask at each step if the agent is active or not
	 * 
	 * @param _nodeId is the id of the agent
	 * @param _strategy is the type of strategy the agent is going to follow
	 * @return the agent created by the method
	 */
	private GamerAgent generateAgent(int _nodeId, char _strategy) {

		GamerAgent  cl = new GamerAgent (_nodeId, _strategy, (int) params.getIntParameter("maxSteps"));


		/*System.out.println("--> IDAgent " + _nodeId + " with " 
		+ this.socialNetwork.getNeighborsOfNode(_nodeId).size() + " neighbors.");*/
				
					
		return cl;
	}	

	/**
	 * This function calculates the payoffs of the members of the population in a well-mixed setting without any network structure. 
	 * It counts the number of k_C, k_D, and k_P of each group and apply the payoffs equations
	 * 
	 * Also, this function updates the individual payoffs for each agent depending on its strategy
	 *  
	 * @return the global payoff of this step
	 * 
	 */
	private void calculatePayoffWithNeighborsGlobally () {
		
		// Iterate over all the agents to update their payoff from the utility matrix 
				
		int currentStep = (int) schedule.getSteps();
		
		float c = (float) params.getFloatParameter("c");
		double riskParam = (float) params.getFloatParameter("riskParam");
		double punishmentTax = (float) params.getFloatParameter("punishmentTax");
		double punishmentFine = (float) params.getFloatParameter("punishmentFine");
		double thrContributors = (float) params.getFloatParameter("thresholdContributors");
		double thrCoordination = (float) params.getFloatParameter("thresholdCoordination");
		
		double agentWealth;

		//System.out.println("\nStep: " + currentStep + ": k_C: " + k_C_Agents[currentStep] + ", k_D: " + k_D_Agents[currentStep] 
		//		+ ", k_P: " + k_P_Agents[currentStep]);
		
				
		// for all the groups we check the number of contributors and punishers to calculate the payoff
		
		for (int k = 0; k < this.numberOfGroups; k++) {
			
			// first, as we have several groups with local institutions, we calculate if there is enough funding (n_p)
			// for punishing Ds with a punishment fine (\pi_f)
			if (k_P_Agents[currentStep][k] < (thrContributors * (int) params.getIntParameter("groupSize"))) {
				
				punishmentFine = 0.;
								
			} else {

				// otherwise, the punishmentFine (\pi_f) set as parameter and
				// update the institutions prevalence KPI
				this.institutionPrevalence[currentStep] += 1.;
				
				// reset to the fine of the input parameter
				punishmentFine = (float) params.getFloatParameter("punishmentFine");
			}
			
			// check if we get the minimum number of contributors and udpate the group achievement KPI
			double valueCoordination = k_C_Agents[currentStep][k] + k_P_Agents[currentStep][k] - (thrCoordination * (int) params.getIntParameter("groupSize"));
			
			if (valueCoordination >= 0) {
				
				// there are enough Cs and Ps (n_{pg})
				this.groupAchievement[currentStep] += 1.;		

				/*System.out.println("gAch: "+ this.groupAchievement[currentStep]  + ". valueCoordination: " + valueCoordination 
						+ ". k_C_Agents[currentStep][k]: " + k_C_Agents[currentStep][k]  + " + k_P_Agents[currentStep][k]: " + k_P_Agents[currentStep][k]  
								+ "- (thrCoordination*(double)params.groupSize): " + (thrCoordination*(double)params.groupSize));*/
			}
			

			for (int j = 0; j < (int) params.getIntParameter("groupSize"); j++) {

				agentWealth = 0.;
				
				// get the id of the agent in the j-th position of group k
				int agentId = this.listOfGroups[k][j];
				
				// we include the n_{pg} and riskParam 'r' in the payoffs calculation						
				double payoffCs = ((GamerAgent) agents.get(agentId)).getB() * (-c + Functions.heaviside(valueCoordination) 
				+ (1 - riskParam)*(1 - Functions.heaviside(valueCoordination)));
				
				// check if the strategy of the agent
				switch (((GamerAgent) agents.get(agentId)).getCurrentStrategy()) {
				
					case ModelParameters.COOPERATOR:
						
						// it is a C					
						agentWealth = payoffCs;
						
						// add to this variable to calculate the average payoff of all the individuals of the pop being C
						/*avgNWCooperators += agentWealth;
						numCs++;*/
						
						break;
									
					case ModelParameters.DEFECTOR:
						
						// it is a D, its payoff is payoff_Cs - delta (punishment) + the fraction of benefit	
						agentWealth = payoffCs - punishmentFine + c*((GamerAgent) agents.get(agentId)).getB();
						
						// add to this variable to calculate the average payoff of all the individuals of the pop being C
						/*avgNWDefectors += agentWealth;
						numDs++;*/
						
						break;
																			
					case ModelParameters.PUNISHER:	
	
						// it is a P, its payoff is payoff_Cs - delta (punishment)	
						agentWealth = payoffCs - punishmentTax;
						
						// add to this variable to calculate the average payoff of all the individuals of the pop being C
						/*avgNWPunishers += agentWealth;
						numPs++;*/
						
						break;	
					 
					default: System.err.println( "Fatal Error!! There is an agent with an unknown strategy different "
							+ "from being C, D or P.\n");
							
						break;			
				}						
							
				// save it to the agent's array
				((GamerAgent) agents.get(agentId)).setPayoff(agentWealth, currentStep);
					
				/*System.out.println("A-" + ((GamerAgent) agents.get(agentId)).gamerAgentId + 
						 " of group " + ((GamerAgent) agents.get(agentId)).groupId + " has str. " + 
						((GamerAgent) agents.get(agentId)).getCurrentStratey() + ". Payoff: " + agentWealth); */
					
			}						
					
		}
					
		// update the ratios of the KPIs and global payoff of the step
		this.institutionPrevalence[currentStep] /= (double) this.numberOfGroups ;
		this.groupAchievement[currentStep] /= (double) this.numberOfGroups;
		
	}
	
	
	/**
	 * By considering agent i as a focal agent for the group, the group is built by the direct contacts in the network.
	 * We compute the payoff of the groups formed by all the agents (as focal)
	 * Important, we ALSO SET THE PAYOFF to each one of the group (additionally to other payoffs from other groups each player can have)
	 * 
	 */
	public void calculatePayoffWithNeighborsFromNetwork () {
		
		int currentStep = (int) schedule.getSteps();
		
		float c = (float) params.getFloatParameter("c");
		double riskParam = (float) params.getFloatParameter("riskParam");
		double punishmentTax = (float) params.getFloatParameter("punishmentTax");
		double punishmentFine = (float) params.getFloatParameter("punishmentFine");
		double thrContributors = (float) params.getFloatParameter("thresholdContributors");
		double thrCoordination = (float) params.getFloatParameter("thresholdCoordination");
		
		double agentWealth = 0;

		// as each agent of the pop generates a group, we loop for each focal agent (k is the focal agent and the group)
		for (int k = 0; k < (int)params.getIntParameter("nrAgents"); k++) {
			
			GamerAgent focal = (GamerAgent) agents.get(k);
					
			// get the neighbors of focal to form the group k
			//ArrayList<Integer> neighbors = (ArrayList<Integer>) this.socialNetwork.getNeighborsOfNode(focal.getGamerAgentId());	
			
			IntArrayList neighbors = this.socialNetwork.getNeighborsOfNode(focal.getGamerAgentId());
			
			// Check focal agent' strategy and iterate over neighbors to see how many of each strategy 
			int k_Cs = 0;
			int k_Ps = 0;

			if (focal.getCurrentStrategy() == ModelParameters.COOPERATOR) 
				k_Cs++;

			else if (focal.getCurrentStrategy() == ModelParameters.PUNISHER) 
				k_Ps++;	
			
			for (int i = 0; i < neighbors.size(); i++) {

				GamerAgent neighbor = (GamerAgent) agents.get(neighbors.get(i));

				if (neighbor.getCurrentStrategy() == ModelParameters.COOPERATOR) 
					k_Cs++;

				else if (neighbor.getCurrentStrategy() == ModelParameters.PUNISHER) 
					k_Ps++;		

			}
			
			// first, we calculate if there is enough funding (n_p) for punishing players D
			// of the group with a punishment fine (\pi_f)
			
			// in the case of a network, the size is given by the degree + 1
			int groupSizeFromNeighborhood = neighbors.size() + 1; 
			
			if (k_Ps < (thrContributors * groupSizeFromNeighborhood)) {
							
				punishmentFine = 0.;
											
			} else {

				// otherwise, the punishmentFine (\pi_f) set as parameter and
				// update the institutions prevalence KPI
				this.institutionPrevalence[currentStep] += 1.;
				
				// reset to the fine of the input parameter
				punishmentFine = (float) params.getFloatParameter("punishmentFine");
			}
			
			// check if we get the minimum number of contributors and udpate the group achievement KPI
			double valueCoordination = k_Cs + k_Ps - (thrCoordination * groupSizeFromNeighborhood);
						
			if (valueCoordination >= 0) {
							
				// there are enough Cs and Ps (n_{pg})
				this.groupAchievement[currentStep] += 1.;		

			}		
			
			/*if (focal.getGamerAgentId() == 10)
				System.out.println("gAch: "+ this.groupAchievement[currentStep]  + ". valueCoordination: " + valueCoordination 
					+ ". k_C: " + k_Cs  + " + k_Ps: " + k_Ps + " k_Ds: " + k_Ds
							+ "- (thrCoordination*groupSize) = (" + thrCoordination +" * " + (double)groupSizeFromNeighborhood + ") = " + (thrCoordination *  (double)groupSizeFromNeighborhood));*/
			
			// once we have the institutional values, we set the payoffs for each member of the group depending on the strategy
			
			// we first do it for focal agent
			
			// n_{pg} and riskParam 'r' in the payoffs calculation						
			double payoffCs = focal.getB() * (-c + Functions.heaviside(valueCoordination) 
			+ (1 - riskParam)*(1 - Functions.heaviside(valueCoordination)));
			
			// check the strategy of the focal agent
			switch (focal.getCurrentStrategy()) {
			
				case ModelParameters.COOPERATOR:
					
					// it is a C					
					agentWealth = payoffCs;
											
					break;
								
				case ModelParameters.DEFECTOR:
					
					// it is a D, its payoff is payoff_Cs - delta (punishment) + the fraction of benefit	
					agentWealth = payoffCs - punishmentFine + c * focal.getB();
											
					break;
																		
				case ModelParameters.PUNISHER:	

					// it is a P, its payoff is payoff_Cs - delta (punishment)	
					agentWealth = payoffCs - punishmentTax;
											
					break;	
				 
				default: System.err.println( "Fatal Error!! There is an agent with an unknown strategy different "
						+ "from being C, D or P.\n");
						
					break;			
			}						
						
			// add the payoff to the agent's value (the agent can be in more than one group)
			focal.addPayoff(agentWealth, currentStep);
			
			/*if (focal.getGamerAgentId() == 10)
				System.out.println("Adding payoff: " + agentWealth);*/
			
			// do the same for the neighbors
			for (int j = 0; j < neighbors.size(); j++) {

				GamerAgent neighbor = (GamerAgent) agents.get(neighbors.get(j));
				
				// n_{pg} and riskParam 'r' in the payoffs calculation						
				payoffCs = neighbor.getB() * (-c + Functions.heaviside(valueCoordination) 
				+ (1 - riskParam)*(1 - Functions.heaviside(valueCoordination)));
				
				// check the strategy of the agent
				switch (neighbor.getCurrentStrategy()) {
				
					case ModelParameters.COOPERATOR:
						
						// it is a C					
						agentWealth = payoffCs;
												
						break;
									
					case ModelParameters.DEFECTOR:
						
						// it is a D, its payoff is payoff_Cs - delta (punishment) + the fraction of benefit	
						agentWealth = payoffCs - punishmentFine + c* neighbor.getB();
												
						break;
																			
					case ModelParameters.PUNISHER:	
	
						// it is a P, its payoff is payoff_Cs - delta (punishment)	
						agentWealth = payoffCs - punishmentTax;
												
						break;	
					 
					default: System.err.println( "Fatal Error!! There is an agent with an unknown strategy different "
							+ "from being C, D or P.\n");
							
						break;			
				}						
							
				// add the payoff to the agent's value (the agent can be in more than one group)
				neighbor.addPayoff(agentWealth, currentStep);
					
				/*if (focal.getGamerAgentId() == 10)
					System.out.println("Agent A-10 Has neighbor A-" + neighbor.gamerAgentId + 
						 " has str. " + neighbor.getCurrentStrategy() + ". Adding payoff: " + agentWealth);*/
					
			}			
		}	        	
		
		// update the ratios of the KPIs by dividing 
		this.institutionPrevalence[currentStep] /= (double) this.numberOfGroups ;
		this.groupAchievement[currentStep] /= (double) this.numberOfGroups;
						
	}
	
	
	
	/**
	 * Adds the anonymous agent to schedule (at the beginning of each step), 
	 * which calculates the statistics.
	 * @param scheduleCounter
	 */
	private void setAnonymousAgentApriori(int scheduleCounter) {
				
		// Add to the schedule at the end of each step
		schedule.scheduleRepeating(Schedule.EPOCH, scheduleCounter, new Steppable()
		{ 
			/**
			 * 
			 */
			private static final long serialVersionUID = -2837885990121299044L;

			public void step(SimState state) {
	    			    							
				// log.log(Level.FINE, "Step " + schedule.getSteps() + "\n");	
			}			
		});
				
	}
	

	/**
	 * Counts the number of players with C, D, and P strategies to update the data structures 
	 * If there is a network, we only count the strategy of the focal agent to use this structure to track
	 * how many Cs, Ds, and Ps we have in the population
	 * 
	 */
	private void updateNumberStrategiesForGroups (int _currentStep) {
				
			
		for (int i = 0; i < (int)params.getIntParameter("nrAgents"); i++) {
			
			// get the group of the agent
			int groupId = ((GamerAgent) agents.get(i)).getGroupId();
			
			if (((GamerAgent) agents.get(i)).getCurrentStrategy() == 
					ModelParameters.COOPERATOR)  {
				k_C_Agents[_currentStep][groupId] ++;	
			}
			
			if (((GamerAgent) agents.get(i)).getCurrentStrategy() == 
					ModelParameters.DEFECTOR)  {
				k_D_Agents[_currentStep][groupId] ++;	
			}
			
			if (((GamerAgent) agents.get(i)).getCurrentStrategy() == 
					ModelParameters.PUNISHER)  {
				k_P_Agents[_currentStep][groupId] ++;	
			}			
			
		}
		
	}
	/**
	 * Adds the anonymous agent to schedule (at the end of each step), 
	 * which calculates the statistics.
	 * @param scheduleCounter
	 */
	private void setAnonymousAgentAposteriori(int scheduleCounter) {
				
		// Add to the schedule at the end of each step
		schedule.scheduleRepeating(Schedule.EPOCH, scheduleCounter, new Steppable()
		{ 
			
			private static final long serialVersionUID = 3078492735754898981L;

			public void step(SimState state) { 
				
				int currentStep = (int) schedule.getSteps();
									
				updateNumberStrategiesForGroups(currentStep);									
				
				// we decide whether to apply a well-mixed population (no SN to calculate payoffs so 
				// they are calculated locally) or locally by the SN structure
				
				if (! params.getNetworkOption ()) {
										
					// calculate payoffs and assign the payoff for all the agents of the pop (well-mixed)
					calculatePayoffWithNeighborsGlobally ();
					
				} else {
					
					// calculate payoffs and assign the payoff for the groups formed by the network
					calculatePayoffWithNeighborsFromNetwork ();
				}
								
				// show the result of the last step in the console				
				if (currentStep == ((int) params.getIntParameter("maxSteps") - 1))
					log.log (Level.FINE, "Final step; Group achievement;" + groupAchievement[currentStep] 
							+ "; Institution prevalence;" + institutionPrevalence[currentStep] +";\n");		
				
				/*System.out.println("Step " + currentStep + ", A-" + ((GamerAgent) agents.get(10)).gamerAgentId + 
						 " has str. " + ((GamerAgent) agents.get(10)).getCurrentStrategy() + ". Payoff: " + ((GamerAgent) agents.get(10)).getPayoff(currentStep));*/
							
				// plotting and saving additional output information for analysis
				plotSaveAdditionalInfo(currentStep);
															
			}				
							
		});
		
	}
	
	
	/**
	 * This method wraps all the processes of saving and plotting additional
	 * information to study the dynamics of the simulation (e.g., data about the institutions, wealth 
	 * distribution of the agents etc)
	 * 
	 * 
	 * @param _currentStep is the step of the simulation
	 * 
	 */

	protected void plotSaveAdditionalInfo(int _currentStep) {
						
		// GROUPS OR INSTITUTION INFORMATION
		if ((ModelParameters.OUTPUT_AGENTS_WEALTH) && (_currentStep == ((int) params.getIntParameter("maxSteps") - 1))) {

			try {

				// save
				File fileOutput = new File("./logs/AgentsWealth_" + params.getStringParameter("outputFile") + "." + this.MC_RUN + ".txt");
				PrintWriter printWriter = new PrintWriter(fileOutput);

				printWriter.write("agentId;degree;strategy;payoff\n");

				// loop for all the steps
				for (int i = 0; i < (int)params.getIntParameter("nrAgents"); i++) {
					
					if (params.getNetworkOption() == false)

						// print all info of the step without printing the degree as we don't have a network
						printWriter.write(i + ";-1;" + 
						((GamerAgent) agents.get(i)).getCurrentStrategy() + ";" + ((GamerAgent) agents.get(i)).getPayoff(_currentStep) + "\n");
					else 
						
						// print all info of the step
						printWriter.write(i + ";" + this.socialNetwork.getNeighborsOfNode(i).size() + ";" + 
						((GamerAgent) agents.get(i)).getCurrentStrategy() + ";" + ((GamerAgent) agents.get(i)).getPayoff(_currentStep) + "\n");
				}

				printWriter.close();

			} catch (FileNotFoundException e) {

				e.printStackTrace();
				log.log(Level.SEVERE, e.toString(), e);
			}

		}
		
		// SAVE THE NUMBER OF Cs, Ds, AND Ps FOR EACH GROUP APART FROM ITS SIZE		
		if ((ModelParameters.OUTPUT_GROUPS_INSTITUTIONS) && (_currentStep == ((int) params.getIntParameter("maxSteps") - 1))) {

			try {

				// save
				File fileOutput = new File("./logs/GroupsStrategies_" + params.getStringParameter("outputFile") + "." + this.MC_RUN + ".txt");
				PrintWriter printWriter = new PrintWriter(fileOutput);

				printWriter.write("groupId;groupSize;k_C;k_D;k_P;groupAchievement;institutionPrevalence\n");

				// loop for all the groups at the last step
				for (int k = 0; k < this.numberOfGroups; k++) {
										
					// print all info about k-th group
					if (params.getNetworkOption() == false) {
						
						float valueCoordination = k_C_Agents[(int) params.getIntParameter("maxSteps") - 1][k] + k_P_Agents[(int) params.getIntParameter("maxSteps") - 1][k] - 
								((float) params.getFloatParameter("thresholdCoordination") * (int) params.getIntParameter("groupSize"));
								
						// if no network, group size is fixed
						printWriter.write(k + ";" + (int) params.getIntParameter("groupSize") + ";" + 
								k_C_Agents[(int) params.getIntParameter("maxSteps") - 1][k] + ";" + 
								k_D_Agents[(int) params.getIntParameter("maxSteps") - 1][k] + ";" + 
								k_P_Agents[(int) params.getIntParameter("maxSteps") - 1][k] + ";");

						if (valueCoordination >= 0) 
							printWriter.write("1;");
						else printWriter.write("0;");
						if (k_P_Agents[(int) params.getIntParameter("maxSteps") - 1][k] >= 
								((float) params.getFloatParameter("thresholdContributors") * (int) params.getIntParameter("groupSize"))) 
							printWriter.write("1\n");
						else printWriter.write("0\n");	
						
					} else {
						
						// if network, it is given by the degree + 1 of the focal agent

						IntArrayList neighbors =this.socialNetwork.getNeighborsOfNode(k);	
						
						int k_Cs = 0;
						int k_Ds = 0;
						int k_Ps = 0;
						
						for (int i = 0; i < neighbors.size(); i++) {

							GamerAgent neighbor = (GamerAgent) agents.get(neighbors.get(i));							
							
							if (neighbor.getCurrentStrategy() == ModelParameters.COOPERATOR) 
								k_Cs++;

							else if (neighbor.getCurrentStrategy() == ModelParameters.DEFECTOR) 
								k_Ds++;

							else if (neighbor.getCurrentStrategy() == ModelParameters.PUNISHER) 
								k_Ps++;		

						}
						
						if (((GamerAgent) agents.get(k)).getCurrentStrategy() == ModelParameters.COOPERATOR) 
							k_Cs++;

						else if (((GamerAgent) agents.get(k)).getCurrentStrategy() == ModelParameters.DEFECTOR) 
							k_Ds++;

						else if (((GamerAgent) agents.get(k)).getCurrentStrategy() == ModelParameters.PUNISHER) 
							k_Ps++;	
						
						
						float valueCoordination = k_Cs + k_Ps - ((float) params.getFloatParameter("thresholdCoordination") * (neighbors.size() + 1));
														
						printWriter.write(k + ";" + (neighbors.size() + 1) + ";" + 
								k_Cs + ";" + 
								k_Ds + ";" + 
								k_Ps + ";");
						if (valueCoordination >= 0) 
							printWriter.write("1;");
						else printWriter.write("0;");
						if (k_Ps >= ((float) params.getFloatParameter("thresholdContributors") *  (neighbors.size() + 1))) 
							printWriter.write("1\n");
						else printWriter.write("0\n");	
						
					}
				}

				printWriter.close();

			} catch (FileNotFoundException e) {

				e.printStackTrace();
				log.log(Level.SEVERE, e.toString(), e);
			}

		}
		
	}


}
