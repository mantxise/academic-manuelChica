 package model;

import sim.engine.*;
import org.eclipse.collections.impl.list.mutable.primitive.IntArrayList;

/**
 * Class of the players of the CRD evolutionary game to also calculate fitness with the contacts of the network
 * 
 * @author mchica
 * @date 2022/04/26
 *
 */

public class GamerAgent implements Steppable {

	// ########################################################################
	// Variables
	// ########################################################################	

	
	private static final long serialVersionUID = 1L;

	//--------------------------------- Fixed -------------------------------//
						
	int gamerAgentId;				// A unique agent Id
		
	int groupId;					// the id of the group of the agent 
									// (if there is a network, the id of the group is the id of the agent as it is the focal agent of the group)
	
	int maxSteps;					// max number of steps of the simulation of the agent
	
	double b;						// value 'b' (benefit or endowment)
	
	int currentStep;				// the current step of the simulation
	
	//------------------------------- Dynamic -------------------------------// 
			

	char currentStrategy = ModelParameters.UNDEFINED_STRATEGY;		// current strategy used by the agent

	double payoffs[];				// array with the payoffs obtained at each step
	
	char evolutionStrategies[];		// array with the evolution in the strategies of the player (when it uses the update rule)

	boolean initialSeed;
	
	
	// ########################################################################
	// Constructors
	// ######################################################################## 		
	
	/**
	 * Initializes a new instance of the ClientAgent class.
	 * @param _gameId is the id for the agent
	 * @param _strategy is the strategy used at the beginning of the simulation
	 * @param _prob the probability to act at each step of the simulation
	 * @param _maxSteps the max steps of the simulation
	 * @param _T_rounds the T rounds to use the update rule
	 * 
	 */
	public GamerAgent( int _gamerId, 
					   char _strategy,
						int _maxSteps) { 
	    		
		this.gamerAgentId = _gamerId;
		this.currentStrategy = _strategy;
		this.maxSteps = _maxSteps;

		this.evolutionStrategies = new char[maxSteps];
		this.payoffs = new double[maxSteps];
		
		for (int i = 0; i < maxSteps; i++) {
			this.payoffs[i] = 0;
			this.evolutionStrategies[i] = 'U';
		}
		
		this.initialSeed = false;
	}	
	
	// ########################################################################	
	// Methods/Functions 	
	// ########################################################################

	//--------------------------- Get/Set methods ---------------------------//

	public boolean isInitialSeed() {
		return initialSeed;
	}

	public void setInitialSeed(boolean initialSeed) {
		this.initialSeed = initialSeed;
	}

	
	/**
	 * Gets the benefit 'b'
	 * @return
	 */
	public double getB() {
		return b;
	}

	/**
	 * Sets the benefit or endowment of the agent
	 * @param _b
	 */
	public void setB(double _b) {
		this.b = _b;
	}
	
	/**
	 * Gets the group of the agent
	 * @return
	 */
	public int getGroupId() {
		return this.groupId;
	}

	/**
	 * Sets the group for the agent
	 * @param _gr
	 */
	public void setGroupId(int _gr) {
		this.groupId = _gr;
	}
	
	/**
	 * Gets the id of the agent
	 * @return
	 */
	public int getGamerAgentId() {
		return gamerAgentId;
	}

	/**
	 * Sets the id of the agent
	 * @param gamerAgentId
	 */
	public void setGamerAgentId(int _gamerAgentId) {
		this.gamerAgentId = _gamerAgentId;
	}
	
	/**
	 * Gets the current strategy of the agent
	 * @return - the strategy
	 */
	public char getCurrentStrategy() {
		return currentStrategy;
	}

	/**
	 * Sets the strategy status of the agent
	 * @param _strategy - the current strategy to be set
	 */
	public void setCurrentStrategy (char _strategy) {
		this.currentStrategy = _strategy;
	}
			
	/**
	 * Gets the payoff array	 
	 */
	public double[] getPayoffs() {
		return payoffs;
	}

	/**
	 * Sets the payoff array
	 * @param _payoffs is the array to set
	 */
	public void setPayoffs(double[] _payoffs) {
		this.payoffs = _payoffs;
	}
	
	/**
	 * Gets the payoff value for a given step	 
	 */
	public double getPayoff(int _step) {
		return payoffs[_step];
	}
	
	/**
	 * Adds a payoff value to a step but without removing the previous value (i.e., adding it to a previous value)
	 * @param _addPayoff is the netwealth value
	 * @param _step is the step for the value
	 */
	public void addPayoff(double _addPayoff, int _step) {
		this.payoffs[_step] += _addPayoff;
	}

	/**
	 * Sets a payoff value to a step
	 * @param _payoff is the netwealth value
	 * @param _step is the step for the value
	 */
	public void setPayoff(double _payoff, int _step) {
		this.payoffs[_step] = _payoff;
	}
	
	/**
	 * Gets the array with the changing strategies
	 */
	public char[] getEvolutionStrategies() {
		return evolutionStrategies;
	}
	

	/**
	 * Returns true if the agent has changed its strategy this step. False if it has the same
	 */
	public boolean hasChangedStrategyAtStep (int _step) {
		
		if ( (_step > 0) && (evolutionStrategies [_step] != evolutionStrategies [(_step - 1)]) ) 
			return true;
		else 
			return false;		
	}
	
	/**
	 * Gets the value of the strategy for a current step 
	 */
	public char getEvolutionStrategies(int _step) {
		return evolutionStrategies [_step];
	}
	
	
	/**
	 * Sets the array with the evolution in the strategy changes
	 * @param _evolutionStrategies is the new array
	 */
	public void setEvolutionStrategies(char[] _evolutionStrategies) {
		this.evolutionStrategies = _evolutionStrategies;
	}
		
	/**
	 * Mutate the strategy
	 * @return if it is mutated
	 * @param state
	 */
	public boolean mutateStrategy (SimState state) {

		Model model = (Model) state;
		
		double r = model.random.nextDouble();
		
		if (r < model.params.getFloatParameter("mutProb") ) {
			
			//System.out.print("\n***** Mutated A-" + this.gamerAgentId + " from " + this.currentStrategy);
			
			// mutate to the new strategy (it can be the current one)
			int v = 1 + model.random.nextInt(3);
			
			if (v == 1)
				this.currentStrategy = ModelParameters.COOPERATOR;	
			else if (v == 2)
				this.currentStrategy = ModelParameters.DEFECTOR;
			else if (v == 3)
					this.currentStrategy = ModelParameters.PUNISHER;	
			else 
				System.err.println( "Fatal Error!! Mutating to a non existing strategy for the player");
			
			
			return true;	
			
		} else 
			
			return false;					
	}
	
	/**
	 * With this function we update the strategy with a stochastic pairwise rule using the Fermi distribution
	 * 
	 * Depending on the existence of network in the model, we compare just with the neighbors or with all the population (WM)
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return true if the agent has changed its strategy w.r.t. its previous strategy
	 */
	private boolean fermiRule (SimState state) {

		Model model = (Model) state;				
		GamerAgent neighbor;	
		
		// check if there is a network
		int j = -1;
				
		if (!model.params.getNetworkOption()) {
			
			// first choose one agent at random without being the agent itself
			do {
				// get one agent at random to imitate (from the whole pop, it doesn't need to belong to the same group)
				j = model.random.nextInt(model.agents.size());
	
				neighbor = (GamerAgent) (model.getAgents()).get(j);
				
			} while (this.gamerAgentId == neighbor.getGamerAgentId());
			
		} else {
			
			IntArrayList neighbors = model.socialNetwork.getNeighborsOfNode(this.gamerAgentId);
			
			// there is a network so pick up one direct contact at random			
			j = model.random.nextInt(neighbors.size());
			neighbor = (GamerAgent) (model.getAgents()).get(neighbors.get(j));
		}								
		
		double neighFitness = 0.;
		double focalAgentFitness = 0.;
		
		neighFitness = neighbor.getPayoff(currentStep - 1);
		focalAgentFitness = this.getPayoff(currentStep - 1);
		
		// calculate the prob using the Fermi distribution and fitness difference
		
		double beta = 5; // value beta set to 5 
			
		double probFermi = 1.0 / (1 + Math.exp(-1 * beta * (neighFitness - focalAgentFitness)));								

		// Check if the agent adopts the neighbor's strategy
		
		double r = model.random.nextDouble();
			
		//System.out.println("Focal A-" + this.gamerAgentId + " (str. " + this.currentStrategy + ") with fitness  " + focalAgentFitness + ". Neigh A-" 
		//		+ neighbor.gamerAgentId + " (str. " + neighbor.currentStrategy + ") fitness is " + neighFitness + ". Fermi prob is " + probFermi + ". r = " + r);
							
		if(r < probFermi) {
			
			// change the strategy!
			char newStrategyToImitate = neighbor.getEvolutionStrategies(currentStep - 1);
			
			// if we have a SA on Punishers, we cannot imitate punishers but just cooperation
			/*if (newStrategyToImitate == ModelParameters.PUNISHER && 
				model.params.getIntParameter("SA_type") == ModelParameters.SA_targetingPs)
				
					newStrategyToImitate = ModelParameters.COOPERATOR; */
			
			this.setCurrentStrategy (newStrategyToImitate);
							
			//System.out.println(" Strategy changed!! A-" + this.gamerAgentId + " to strategy " +
			//		this.currentStrategy + " by imitating A-" + neighbor.getGamerAgentId() + "\n");

			return true;
		}		
									
		return false;		
	}
		
	
	
	/**
	 * With this function we update the strategy used by the agent.
	 * We use the defined imitative ev. dynamics rule for calculating the change (if there is a change)
	 * 
	 * @param state - a simulation model object (SimState).
	 * @return true if the agent has changed its strategy w.r.t. its previous strategy
	 */
	public boolean updateRuleForStrategy (SimState state) {
		
		Model model = (Model) state;
				
		// it does not make sense to do it for the first step
		
		if (currentStep > 0) {
			
			switch ((int) model.params.getIntParameter("updateRule")) {

			case ModelParameters.FERMI_UPDATE_RULE:
				
				return this.fermiRule(state);
				
			case ModelParameters.PROPORTIONAL_UPDATE_RULE:
				
				throw new UnsupportedOperationException ("There is not any implementation of using something different from a stochastic pairwise rule with the Fermi function \n");
				
			case ModelParameters.UI_UPDATE_RULE:
				
				throw new UnsupportedOperationException ("There is not any implementation of using something different from a stochastic pairwise rule with the Fermi function \n");
		
			case ModelParameters.VOTER_UPDATE_RULE:
				
				throw new UnsupportedOperationException ("There is not any implementation of using something different from a stochastic pairwise rule with the Fermi function \n");
	
			case ModelParameters.MORAN_UPDATE_RULE:
				
				throw new UnsupportedOperationException ("There is not any implementation of using something different from a stochastic pairwise rule with the Fermi function \n");
					
			}
		}
						
		return false;					
	}	


	//--------------------------- Steppable method --------------------------//	
	
	/**
	 * Step of the simulation.
	 * @param state - a simulation model object (SimState).
	 */
	
	//@Override	
	public void step(SimState state) {

		Model model = (Model) state;
		
		currentStep = (int) model.schedule.getSteps();
			
		// check if we have a seed not to modify the strategy		
		if ( this.initialSeed == false ) {
			
			// mutate the strategy 			
			if (! this.mutateStrategy (state)) {

				// if no mutated, update rule
				this.updateRuleForStrategy(state);		
			}			
			
		}		
		
		// store the strategy of this step
		this.evolutionStrategies[currentStep] = this.currentStrategy; 			 
	}


}


