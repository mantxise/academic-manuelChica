package model;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.NoSuchElementException;

import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.graphstream.graph.Graph;

import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.stream.file.FileSourceDGS;


/**
 * 
 * Parameters of the model of evolutionary dynamics for the ToC dilemma using the definitions of paper:
 * Vasconcelos13 "A bottom-up institutional approach to cooperative governance of risky commons", Nature climate change 2013
 * 
 * The game has 3 strategies (C, D, P). It is played by groups using the social network:
 * 
 * All the strategies start with an initial endowment or benefit 'b'
 * 
 * Cooperators C contribute with a fraction 'c' \in [0,1] of this initial benefit 'b'
 * Punishers P contribute with a fraction 'c' \in [0,1] of this initial benefit 'b' plus punishment tax (\pi)
 * Defectors do not contribute
 * 
 * If the joint number of Cs/Ps in a group is below n_{pg}, everyone in the group will lose everything with a probability 'r'. 
 * Otherwise, everyone keep whatever they have.
 * This is called the risk r\in[0,1] for players in the group to lose everything when there is not a minimum number of cooperators or punishers
 * 

	Handling missing properties			https://commons.apache.org/proper/commons-configuration/userguide/howto_basicfeatures.html
				
 * @author mchica
 * @date 2022/04/22
 * @place Oeiras, Lisboa
 *
 */

public class ModelParameters {

	// Read configuration file (apache commons configuration 2.7)
	Configuration config;

	// constants to get different options for simple or SA runs
	public final static int NO_SA = 0;
	//public final static int SA_INITIAL_POPULATION = 1;
	public final static int SA_riskParam = 2;
	public final static int SA_mutProb = 3;
	public final static int SA_riskParam_cost = 4;
	public final static int SA_targetingPsByDegree = 5;
	public final static int SA_targetingPsAtRandom = 6;
	public final static int SA_targetingCsByDegree = 7;
	public final static int SA_targetingCsAtRandom = 8;
	
	// CONFIGURATION TO CALCULATE, STORE STATISTICS	
	public static boolean OUTPUT_GROUPS_INSTITUTIONS = false;  
	public static boolean OUTPUT_AGENTS_WEALTH = false;  
	
	// FOR THE STRATEGY TYPE FOR AGENTS
	public final static char UNDEFINED_STRATEGY = 'U';
	public final static char COOPERATOR = 'C';
	public final static char DEFECTOR = 'D';
	public final static char PUNISHER = 'P';

	public final static int WELL_MIXED_POP = -1;
	public final static int NETWORK = 0;
	
	// TYPE OF UPDATE RULE FOR THE AGENTS
	public final static int PROPORTIONAL_UPDATE_RULE = 1;
	public final static int UI_UPDATE_RULE = 2;
	public final static int VOTER_UPDATE_RULE = 3;
	public final static int FERMI_UPDATE_RULE = 4;
	public final static int MORAN_UPDATE_RULE = 5;
	


	// ########################################################################
	// Variables
	// ########################################################################

	String outputFile;

	// modified just to use a static SN from a file

	// FILE_NETWORK ONLY!!
	boolean network;				// true if having a structured network such as SF or Lattice (read from file). false if we do not have it and it is a WM

	// graph read from file
	Graph graphFromFile;



	// --------------------------- Wrapper methods for Config ---------------------------//
	//

	/**
	 * This function add a new parameter to the map of parameters of the model
	 * 
	 * @param _parameterKey is the key of the new parameter to create
	 * @param _value is the value to set to the parameter
	 */
	public void addParameter (String _parameterKey, Object _value) {		
		this.config.addProperty(_parameterKey, _value);		
	}
	
	/**
	 * This function set an existing parameter to the map of parameters of the model
	 * 
	 * @param _parameterKey is the key of the existing parameter to set
	 * @param _value is the value to set to the parameter
	 */
	public void setParameterValue (String _parameterKey, Object _value) {		
		this.config.setProperty(_parameterKey, _value);		
	}
		
	/**
	 * This function retrieve a parameter of type int from the configuration structure of parameters
	 */
	public int getIntParameter (String _parameterKey) {		
		
		return this.config.getInt(_parameterKey);		
		
	}

	/**
	 * This function retrieve a parameter of type float from the configuration structure of parameters
	 */
	public float getFloatParameter (String _parameterKey) {		
		
		return this.config.getFloat (_parameterKey);		
		
	}
	
	/**
	 * This function retrieve a parameter of type long from the configuration structure of parameters
	 */
	public long getLongParameter (String _parameterKey) {		
		
		return this.config.getLong (_parameterKey);		
		
	}

	/**
	 * This function retrieve a parameter of type String from the configuration structure of parameters
	 */
	public String getStringParameter (String _parameterKey) {		
		
		return this.config.getString (_parameterKey);		
		
	}
	
	// --------------------------- Methods for SN configuration ---------------------------//
	//
			
		
	/**
	* @return the value of having a network or not
	*/
	public boolean getNetworkOption () {
		return this.network;
	}
	
	/**
	* @param _v if having a network from file
	*/
	public void setNetworkOption (boolean _v) {
		this.network = _v;
	}
	

	/**
	 * @return the graph
	 */
	public Graph getGraph () {
		return graphFromFile;
	}

	/**
	 * @param _graph
	 *            to set
	 */
	public void setGraph (Graph _graph) {
		this.graphFromFile = _graph;
	}


	/**
	 * @param _graph
	 *            to set
	 * @throws IOException
	 */
	public void readGraphFromFile(String fileNameGraph) throws IOException {

		FileSourceDGS fileSource = new FileSourceDGS();
		graphFromFile = new SingleGraph("SNFromFile");

		fileSource.addSink(graphFromFile);
		fileSource.readAll(fileNameGraph);

		fileSource.removeSink(graphFromFile);		
	
	}
	

	// ########################################################################
	// Constructors
	// ########################################################################

	/**
	 * 
	 */
	public ModelParameters() {

	}

	// ########################################################################
	// Export methods
	// ########################################################################

	public String export() {

		String values = "";

		values += exportGeneral() + "------\n";
		values += exportSpecifics();

		return values;
	}

	private String exportSpecifics() {

		String result = "";

		result += "groupSize = " + config.getInt("groupSize") + "\n";
		result += "percentageCooperators = " + config.getFloat("percentageCooperators") + " (k_C = " + config.getInt("k_C") +")\n";
		result += "percentageDefectors = " + config.getFloat("percentageDefectors") + " (k_D = " + config.getInt("k_D") + ")\n";
		result += "percentagePunishers = " + config.getFloat("percentagePunishers") + " (k_P = " + config.getInt("k_P") +")\n";
		result += "initialSeedsPs = " + config.getFloat("initialSeedsPs") + "\n";		
		result += "initialSeedsCs = " + config.getFloat("initialSeedsCs") + "\n";

		
		result += "riskParam = " + config.getFloat("riskParam") + "\n";
		result += "punishmentTax = " + config.getFloat("punishmentTax") + "\n";
		result += "punishmentFine = " + config.getFloat("punishmentFine") + "\n";
		result += "thresholdContributors = " + config.getFloat("thresholdContributors") + "\n";
		result += "thresholdCoordination = " + config.getFloat("thresholdCoordination") + "\n";
		result += "c = " + config.getFloat("c") + "\n";
		result += "b = " + config.getFloat("b") + "\n";
		

		return result;

	}
	
	/**
	 * Prints simple statistics evolution during the time.
	 */
	public void printParameters(PrintWriter writer) {

		// printing general params
		writer.println(this.export());

	}

	private String exportGeneral() {

		String result = "";

		result += "MC_runs = " + config.getInt("MCRuns") + "\n";
		result += "seed = " + config.getLong("seed") + "\n";
		result += "nrAgents = " + config.getInt("nrAgents") + "\n";
		result += "maxSteps = " + config.getInt("maxSteps") + "\n";

		result += "Network? = " + this.network + "\n";
		result += "SNFile = " + config.getString("SNFile") + "\n";		
		
		if (config.getInt("updateRule") == ModelParameters.PROPORTIONAL_UPDATE_RULE)
			result += "updateRule = PROPORTIONAL_UPDATE_RULE\n";
		
		else if (config.getInt("updateRule") == ModelParameters.UI_UPDATE_RULE)
			result += "updateRule = UI_UPDATE_RULE\n";
		
		else if (config.getInt("updateRule") == ModelParameters.VOTER_UPDATE_RULE) {
			result += "updateRule = VOTER_UPDATE_RULE\n";
			result += "mutProb = " + config.getFloat("mutProb") + "\n";
		}
					
		else if (config.getInt("updateRule") == ModelParameters.FERMI_UPDATE_RULE)
			result += "updateRule = FERMI_UPDATE_RULE\n";
		
		else if (config.getInt("updateRule") == ModelParameters.MORAN_UPDATE_RULE)
			result += "updateRule = MORAN_UPDATE_RULE\n";
		
		result += "mutProb = " + config.getFloat("mutProb") + "\n";
			
		return result;
	}

	/** 
	 * Generate the absolute number of initial adopters and agents with the WPT options
	 */
	public void updateInitialAdoptersFromPercentages() {

		int k_C = (int) Math.round(config.getInt("nrAgents") * config.getFloat("percentageCooperators"));
		int k_D = (int) Math.round(config.getInt("nrAgents") * config.getFloat("percentageDefectors"));

		config.addProperty("k_C", k_C);
		config.addProperty("k_D", k_D);
		config.addProperty("k_P", config.getInt("nrAgents") - (k_C + k_D));
		
		// init value before running a SA
		config.addProperty("initialSeedsPs", -1);
		config.addProperty("initialSeedsCs", -1);
		
	}
		
	
	/**
	 * Reads parameters from the configuration file.
	 */
	public void readParameters(String CONFIGFILENAME) {

		Configurations configs = new Configurations();

		try {

			// Read parameters from the file
			this.config = configs.properties(new File(CONFIGFILENAME));									
			
			// check if the percentage of initial adopters is valid

			if ((config.getInt("typeOfNetwork") == WELL_MIXED_POP) && (config.getInt("nrAgents") % config.getInt("groupSize")) != 0) {
				throw new IOException("The total number of players is not a mutiple of the groups' size. "
						+ "Check params nrAgents and groupSize parameters\n");
			}
			if ((config.getFloat("percentageCooperators") + config.getFloat("percentageDefectors") + config.getFloat("percentagePunishers")) != 1.0) {
				throw new IOException("Error with % of Cs, Ds, and Ps. It is != 100%. "
						+ "Check params percentageCooperators, percentageDefectors and percentagePunishers\n");
			}
			
			if (config.getInt("updateRule") != ModelParameters.FERMI_UPDATE_RULE) {
				
				throw new UnsupportedOperationException ("There is not any implementation of using something different from a stochastic pairwise rule with the Fermi function \n");
			}
						
			// set type of network			
			if (config.getInt("typeOfNetwork") == NETWORK) 	
				this.network = true;
			else if (config.getInt("typeOfNetwork") == WELL_MIXED_POP) 
					this.network = false;			
								
			
			// if having a SN from file to read, do it
			if (this.network == true) 
				this.readGraphFromFile(config.getString("SNFile"));
															
												
		} catch (IOException e) {

			System.err.println("ModelParameters: Error when handling or opening the properties file " + CONFIGFILENAME + "\n"
					+ e.getMessage());
			e.printStackTrace(new PrintWriter(System.err));
			
		} catch (ConfigurationException ce) {

			System.err.println("ModelParameters: Error when managing the configuration module (Apache) with file " + CONFIGFILENAME + "\n"
					+ ce.getMessage());
			ce.printStackTrace(new PrintWriter(System.err));
			
		} catch (NoSuchElementException noSuch) {

			System.err.println("Warning ModelParameters: Property not defined in " + CONFIGFILENAME + "\n"
					+ noSuch.getMessage());
		}
	}
	
}
