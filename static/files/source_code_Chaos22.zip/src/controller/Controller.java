package controller;

import view.RunStats;

import java.util.logging.Level;
import java.util.logging.Logger;


import model.*;

/** 
 * Controller of the CRD model
 * 
 * This class is the controller to call the model  
 * It calls the model, run it to get all the steps and returns a list
 * of simulated values
 * 
 * @author mchica
 * @date 2022/04/22
 * @place Las Palmas GC
 * 
 */

public class Controller {

	// LOGGING
	private static final Logger log = Logger.getLogger( Model.class.getName() );
	
	protected Model model = null;
	
	
	/**
	 * @return the ModelParameters object where all the parameters are defined
	 */
	public ModelParameters getModelParameters() {
		return model.getParametersObject();
	}


	/**
	 * Set the ModelParameters object for all the defined parameters 
	 */
	public void setModelParameters(ModelParameters _params) {
		model.setParametersObject(_params);
	}

	
	/**
	 * Constructor having config, seed and maxSteps
	 */
	public Controller(ModelParameters _params, String _paramsFile) {
				
		Model.setConfigFileName(_paramsFile);
		
		this.model = new Model(_params);
	}
		
	
	/**
	 * Run the model one time
	 * @return the statistics after running the model
	 * 
	 */
	public RunStats runModel() {
		
		// starting and looping the mode

		int mcRuns = model.getParametersObject().getIntParameter("MCRuns");
		int maxSteps = model.getParametersObject().getIntParameter("maxSteps");
		
		// object to store results into the stats object
		
		RunStats stats = new RunStats(mcRuns, maxSteps);

		log.log(Level.FINE, "\n**Starting MC agent-based simulation (networked CRD)\n");
		log.log (Level.FINE, "\n" + model.getParametersObject().export()  + "\n");	

        System.out.print(mcRuns + " MC runs"  + ": ");
     
        
   		for (int i = 0; i <  mcRuns; i++) {
						
			// for each MC run we start the model and run it
    		        
			model.start();
			
			do {					
				if (!model.schedule.step(model)) break;
				 				
			} while (model.schedule.getSteps() <  maxSteps );			

			model.finish();	
					        
	        // store to the stats object
		        
			stats.setk_CWholePopForRun(i, model.getk_C_WholePopArray());
			stats.setk_DWholePopForRun(i, model.getk_D_WholePopArray());
			stats.setk_PWholePopForRun(i, model.getk_P_WholePopArray());
			
			stats.setGroupAchievementForRun(i, model.getGroupAchievement());
			stats.setInstitutionPrevalenceForRun(i, model.getInstitutionPrevalence());
			
			stats.setCostSeedingForRun(i, model.getCostSeeding());
			
			// to show some logs about activity of the agents
			// model.printStatisticsScreen ();	
	        
			log.log(Level.FINE, "MC-" + (i+1) + "/" + 
					mcRuns + " ended\n\n");

	        System.out.print(".");
		}						
        
        System.out.println("");
        		        			    	
        
		return stats;
		
	}
		
}
