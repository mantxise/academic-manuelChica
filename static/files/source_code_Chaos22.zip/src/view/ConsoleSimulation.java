package view;

import java.io.IOException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import controller.Controller;
import model.Model;
import model.ModelParameters;

//----------------------------- MAIN FUNCTION -----------------------------//

/**
 * Main function for the CRD networked model 
 * 
 * @author mchica
 * @date 2022/04/22
 * @place Oeiras, Lisboa
 */

public class ConsoleSimulation {		
	

	// LOGGING
	private static final Logger log = Logger.getLogger( Model.class.getName() );
	
	/**
	 * Create an options class to store all the arguments of the command-line call of the program
	 * 
	 * @param options the class containing the options, when returned. It has to be created before calling
	 */
	private static void createArguments (Options options) {
				
					
		options.addOption("paramsFile", true, "Pathfile with the parameters file");
		options.getOption("paramsFile").setRequired(true);
		
		options.addOption("SNFile", true, "File with the SN to run");
		
		options.addOption("outputFile", true, "File to store all the information about the simulation");
		options.getOption("outputFile").setRequired(true);
		
		options.addOption("percentageCooperators", true, "% of agents to be cooperators at the beginning of the simulation");
		options.addOption("percentageDefectors", true, "% of agents to be defectors at the beginning of the simulation");
		options.addOption("percentagePunishers", true, "% of agents to be punishers at the beginning of the simulation");

		options.addOption("punishmentTax", true, "parameter to set the tax to be paid by punishers");
		options.addOption("punishmentFine", true, "parameter to set the tax fine of the defectors");
		options.addOption("riskParam", true, "parameter \\in [0,1] for the risk to lose everything");
		options.addOption("thresholdContributors", true, "threshold for minium number of contributors (Ps)");
		options.addOption("thresholdCoordination", true, "threshold for minium number of coordination (Cs and Ps)");
		options.addOption("mutProb", true, "mutation probability \\in [0, 1]");
		options.addOption("c", true, "cost");
		
		options.addOption("maxSteps", true, "Max number of steps of the simulation");

		options.addOption("MCRuns", true, "Number of MC simulations");
		options.addOption("seed", true, "Seed for running the MC simulations");
				
		// parameters for SA
		//options.addOption("SA_initialPop", false, "If running a SA over the initial population parameters");		
		options.addOption("SA_riskParam", false, "If running a SA over the riskParam parameter");	
		options.addOption("SA_riskParam_cost", false, "If running a SA over the riskParam and c parameters");	
		options.addOption("SA_mutProb", false, "If running a SA over the mutProb parameter");

		options.addOption("SA_targetingPsByDegree", false, "If running a SA over the number of Ps according to descending degree");
		options.addOption("SA_targetingPsAtRandom", false, "If running a SA over the number of Ps at random");		
		
		options.addOption("SA_targetingCsByDegree", false, "If running a SA over the number of Cs according to descending degree");
		options.addOption("SA_targetingCsAtRandom", false, "If running a SA over the number of Cs at random");				
				
		// to show help
		options.addOption("help", false, "Show help information");	
		
	}
	
	/**
	 * MAIN CONSOLE-BASED FUNCTION TO RUN A SIMPLE RUN OR A SENSITIVITY ANALYSIS OF THE MODEL PARAMETERS
	 
	 * @param args
	 */
	public static void main (String[] args) {
    	
		String paramsFile = "";
		String outputFile = "";

		ModelParameters params = null;
		
		// parsing the arguments
		Options options = new Options();
		
		createArguments (options);		

		// create the parser
	    CommandLineParser parser = new DefaultParser();
	    
	    try {
	    	
	        // parse the command line arguments for the given options
	        CommandLine line = parser.parse( options, args );

			// get parameters
			params = new ModelParameters();	
			
	        // retrieve the arguments
	        		    
		    if( line.hasOption( "paramsFile" ) )		    
		    	paramsFile = line.getOptionValue("paramsFile");
		    else 		    	
		    	System.err.println( "A parameters file is needed");

		    if( line.hasOption( "outputFile" ) ) 			    
		    	outputFile = line.getOptionValue("outputFile");

		    // read parameters from file
			params.readParameters(paramsFile);

			// add the output file to the configuration of the model
			params.addParameter("outputFile", outputFile);
						
			// once parameters from file are loaded, we modify those read by arguments of command line		
			
		    // load the parameters file and later, override them if there are console arguments for these parameters
			
			 // MC
		    if( line.hasOption( "MCRuns" ) ) 			    
		    	params.setParameterValue("MCRuns", Integer.parseInt(line.getOptionValue("MCRuns")));

		    // seed
		    if( line.hasOption( "seed" ) ) 			    
		    	params.setParameterValue("seed", Long.parseLong(line.getOptionValue("seed")));

		    // maxSteps
		    if( line.hasOption( "maxSteps" ) ) 			    
		    	params.setParameterValue("maxSteps", Integer.parseInt(line.getOptionValue("maxSteps")));
		    	    			    
			
		    if( line.hasOption( "percentageCooperators" ) ) 			    
		    	params.setParameterValue("percentageCooperators", Float.parseFloat(line.getOptionValue("percentageCooperators")));
			
		    if( line.hasOption( "percentageDefectors" ) ) 			    
		    	params.setParameterValue("percentageDefectors", Float.parseFloat(line.getOptionValue("percentageDefectors")));

		    if( line.hasOption( "riskParam" ) ) 			    
		    	params.setParameterValue("riskParam", Float.parseFloat(line.getOptionValue("riskParam")));
		    
		    if( line.hasOption( "punishmentTax" ) ) 			    
		    	params.setParameterValue("punishmentTax", Float.parseFloat(line.getOptionValue("punishmentTax")));

		    if( line.hasOption( "punishmentFine" ) ) 			    
		    	params.setParameterValue("punishmentFine", Float.parseFloat(line.getOptionValue("punishmentFine")));
		    
		    if( line.hasOption( "thresholdContributors" ) ) 			    
		    	params.setParameterValue("thresholdContributors", Float.parseFloat(line.getOptionValue("thresholdContributors")));

		    if( line.hasOption( "thresholdCoordination" ) ) 			    
		    	params.setParameterValue("thresholdCoordination", Float.parseFloat(line.getOptionValue("thresholdCoordination")));

		    if( line.hasOption( "mutProb" ) ) 			    
		    	params.setParameterValue("mutProb", line.getOptionValue("mutProb"));
		    
		    if( line.hasOption( "c" ) ) 			    
		    	params.setParameterValue("c", line.getOptionValue("c"));
		    
		    
		    // save file for the SN
		    if( line.hasOption( "SNFile" ) ) 
		    	// read again the network apart from setting the name of the file (inside next function)
		    	try {

					params.readGraphFromFile(line.getOptionValue("SNFile"));
					
		    	} catch (IOException e) {

					System.err.println("ConsoleSimulation: Error with SN file when loading parameters for the simulation " + line.getOptionValue("SNFile") + "\n"
							+ e.getMessage());
					e.printStackTrace(new PrintWriter(System.err));
				}
		    			  
		  		   
		    		
		    // help information
		    if( line.hasOption("help") ) {
			    	
			    // automatically generate the help statement
			    HelpFormatter formatter = new HelpFormatter();
			    formatter.printHelp( "CRD Networked. Last update April 2022. Manuel Chica", options);			   	
			}	
		  		    		    
		   		    				
		   if( line.hasOption( "SA_riskParam" ) ) {
		    	
		    	// we have to run a SA on the risk param
		    	params.setParameterValue("SA_type", ModelParameters.SA_riskParam);
		    	
		    } else if( line.hasOption( "SA_mutProb" ) ) {
		    	
		    	// we have to run a SA on the mut Prob
		    	params.setParameterValue("SA_type", ModelParameters.SA_mutProb);
		    			    	
		    } else if( line.hasOption( "SA_riskParam_cost" ) ) {
		    	
		    	// we have to run a SA on the mut Prob
		    	params.setParameterValue("SA_type", ModelParameters.SA_riskParam_cost);
		    			    	
		    } else if( line.hasOption( "SA_targetingPsAtRandom" ) ) {
		    	
		    	// we have to run a SA on the number of Ps in the pop
		    	params.setParameterValue("SA_type", ModelParameters.SA_targetingPsAtRandom);
		    	
		    } else if( line.hasOption( "SA_targetingPsByDegree" ) ) {
		    	
		    	// we have to run a SA on the number of Ps in the pop
		    	params.setParameterValue("SA_type", ModelParameters.SA_targetingPsByDegree);
		    	
		    } else if( line.hasOption( "SA_targetingCsAtRandom" ) ) {
		    	
		    	// we have to run a SA on the number of Ps in the pop
		    	params.setParameterValue("SA_type", ModelParameters.SA_targetingCsAtRandom);
		    	
		    } else if( line.hasOption( "SA_targetingCsByDegree" ) ) {
		    	
		    	// we have to run a SA on the number of Ps in the pop
		    	params.setParameterValue("SA_type", ModelParameters.SA_targetingCsByDegree);
		    	
		    } else {
		    	
		    	params.setParameterValue("SA_type", ModelParameters.NO_SA);
		    }
		   
		    // to update initial adopters from percentage
		    params.updateInitialAdoptersFromPercentages();
		    
	    }
	    
	    catch (ParseException exp ) {
	    	
	        // oops, something went wrong
	        System.err.println( "Parsing failed.  Reason: " + exp.getMessage() );
			log.log(Level.SEVERE, "Parsing failed.  Reason: " + exp.toString(), exp);
			
	    } catch (IllegalArgumentException e ) {
	    	
	        // oops, something went wrong
	        System.err.println( "IllegalArguments for command line.  Reason: " + e.getMessage() );
			log.log(Level.SEVERE, "IllegalArguments for command line.  Reason: " + e.toString(), e);
			
	    }
	    	
        System.out.println("\n****** STARTING NETWORKED CRD ******\n");

        Date date = new Date();
    	System.out.println("Experiment output file: **" + params.getStringParameter("outputFile") + "**" );
        System.out.println("Launched on " + date.toString()+ "\n" + "\nParameters of the model:\n-----------------------");
    	
        File fileAllMC = new File ("./logs/" + "AllMCruns_" + params.getStringParameter("outputFile") + ".txt");
        File fileSummaryMC = new File ("./logs/" + "SummaryMCruns_" +  params.getStringParameter("outputFile") + ".txt");
        File fileAllMCLQ = new File ("./logs/" + "AllMCrunsLQ_" + params.getStringParameter("outputFile") + ".txt");
        File fileSummaryMCLQ = new File ("./logs/" + "SummaryMCrunsLQ_" +  params.getStringParameter("outputFile") + ".txt");
        File fileTimeSeriesMC = new File ("./logs/" + "TimeSeriesMCruns_" +   params.getStringParameter("outputFile") + ".txt");
       
        // the SA check    	    			
        int SA = params.getIntParameter("SA_type");
        
	    if (SA == ModelParameters.NO_SA) {
	    	
	    	// no SA, simple run
	    	
	    	RunStats stats;
	    	
	    	// print parameters for double-checking
		    PrintWriter out = new PrintWriter(System.out, true);
	        params.printParameters(out);
	        
	        log.log(Level.FINE, "\n*** Parameters' values of this model:\n" + params.export());
	        
	        
	        // START PREPARING CONTROLLER FOR RUNNING
			long time1 = System.currentTimeMillis ();
		
			Controller controller;
			
			controller = new Controller (params, paramsFile);
			
	        // END PREPARING CONTROLLER FOR RUNNING
	 		
			
			// BEGIN RUNNING MODEL WITH ALL THE MC SIMULATION
			
	 		stats = controller.runModel();	
	 		
	 		// END RUNNING MODEL WITH ALL THE MC SIMULATION
	 		
	 		stats.setExpName (params.getStringParameter("outputFile"));
	 		
	 		long  time2  = System.currentTimeMillis( );
	 		System.out.println("\n****** " + (double)(time2 - time1)/1000 + "s spent during the simulation");
	 		
	 		stats.calcAllStats();
	         
	 		// print the stats in the screen 		
	 		stats.printSummaryStats(out, false);
			stats.printSummaryStatsByAveragingLastQuartile(out, false);  // also the last quartile info

	 		System.out.println();
	 		
	 		// print the stats into a file
	        System.out.println("\n****** Stats also saved into a file ******\n");
	         
	        PrintWriter printWriter;
	         
	 		try {
	 			
	 			
	 			// print all the runs info into a file
	 			printWriter = new PrintWriter (fileAllMC);
	 			stats.printAllStats (printWriter, false);
	 	        printWriter.close (); 
	 	        
	 	        // print all the runs info (last quartiles of the sims) into a file
	 			printWriter = new PrintWriter (fileAllMCLQ);
	 			stats.printAllStatsByAveragingLastQuartile (printWriter, false);
	 	        printWriter.close ();  
	 	        
	 	        // print the summarized MC runs into a file
	 	        printWriter = new PrintWriter (fileSummaryMC);
	 			stats.printSummaryStats (printWriter, false);
	 	        printWriter.close ();    
	 	        
	 	        // print the summarized MC runs (last quartiles of the sims) into a file
	 	        printWriter = new PrintWriter (fileSummaryMCLQ);
	 			stats.printSummaryStatsByAveragingLastQuartile(printWriter, false);
	 	        printWriter.close ();    

	 	        // print the time series into a file
	 	        printWriter = new PrintWriter (fileTimeSeriesMC);
	 			stats.printTimeSeriesStats (printWriter);
	 	        printWriter.close ();    
	 	        
	 	        
	 	        
	 		} catch (FileNotFoundException e) {
	 			
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 			
	 		    log.log( Level.SEVERE, e.toString(), e );
	 		} 
	    	
	    } else {
	    
	    	if ( SA == ModelParameters.SA_riskParam) {
	    		

	    		SensitivityAnalysis.setParam1Info ("riskParam",(float) 0, 1, (float)0.01);

	    		SensitivityAnalysis.runSAOnOneParameter (params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    		
	    	} else if ( SA == ModelParameters.SA_mutProb) {

	    		SensitivityAnalysis.setParam1Info ("mutProb",(float) 0, 1, (float)0.1);

	    		SensitivityAnalysis.runSAOnOneParameter (params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	} else if ( SA == ModelParameters.SA_riskParam_cost) {

	    		SensitivityAnalysis.setParam1Info ("riskParam",(float) 0, 1, (float)0.05);
	    		SensitivityAnalysis.setParam2Info ("c",(float) 0, (float)0.5, (float)0.025);

	    		SensitivityAnalysis.runSAOnTwoParameters(params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	} else if ( SA == ModelParameters.SA_targetingPsAtRandom || SA == ModelParameters.SA_targetingPsByDegree) {

	    		// we have to remove the mutation
		    	//params.setParameterValue("mutProb", 0);
		        //System.out.println("Note: mutation probability set to 0 when targeting Ps");

	    		int min = 0;
	    		int max = (int) ((int)params.getIntParameter("nrAgents") * 0.1);
	    		int step = 25;
	    		
	    		SensitivityAnalysis.runSAOnTargetingPunishers (min, max, step, params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	}  	else if ( SA == ModelParameters.SA_targetingCsAtRandom || SA == ModelParameters.SA_targetingCsByDegree) {

	    		// we have to remove the mutation
		    	//params.setParameterValue("mutProb", 0);
		        //System.out.println("Note: mutation probability set to 0 when targeting Ps");

	    		int min = 0;
	    		int max = (int) ((int)params.getIntParameter("nrAgents") * 0.1);
	    		int step = 25;
	    		
	    		SensitivityAnalysis.runSAOnTargetingCooperators (min, max, step, params, paramsFile, fileAllMC, fileSummaryMC, fileAllMCLQ, fileSummaryMCLQ);
	    		
	    	}	
	    }								
	}
}

