package view;

// package for std and mean

import java.io.PrintWriter;
import java.util.Locale;

import org.apache.commons.math3.stat.descriptive.*;


/** 
 * StatsRun for the ToC model with risk and punishers
 * 
 * This class will store all the results for the MonteCarlo simulation.
 * It will also update the stats and error metrics w.r.t. the historical data.
 * 
 * @author mchica
 *
 */
public class RunStats {

	private int numberRuns;				// number of MC simulations

	private int numberSteps;			// number of steps simulation

	/*private StatsArrayData Cs;
	private StatsArrayData Ds;
	private StatsArrayData Ps;
	private StatsArrayData GA;
	private StatsArrayData IP;*/
	
	// fields for k_C members of the population (time series)
	private int k_C[][];				// all the k_C members (each for run and step)
	private double avgk_C[];			// average k_C over all the runs for each step
	private double stdk_C[];			// std k_C over all the runs for each step
	private double[] min_k_C;
	private double[] max_k_C;
	
	// fields for k_D members of the population (time series)
	private int k_D[][];				// all the k_D members (each for run and step)
	private double avgk_D[];			// average k_D over all the runs for each step
	private double stdk_D[];			// std k_D over all the runs for each step
	private double[] min_k_D;
	private double[] max_k_D;
	
	// fields for k_P members of the population (time series)
	private int k_P[][];				// all the k_P members (each for run and step)
	private double avgk_P[];			// average k_P over all the runs for each step
	private double stdk_P[];			// std k_P over all the runs for each step
	private double[] min_k_P;
	private double[] max_k_P;
	
	// fields for groupAchievement
	private double groupAchievement[][];			// all the groupachievement metrics (each for run and step)
	private double avgGroupAchievement[];			
	private double stdGroupAchievement[];			
	private double[] min_GroupAchievement;
	private double[] max_GroupAchievement;
	
	// fields for institutionPrevalence
	private double institutionPrevalence[][];			// all the institutionPrevalence metrics (each for run and step)
	private double avgInstitutionPrevalence[];			
	private double stdInstitutionPrevalence[];			
	private double[] min_InstitutionPrevalence;
	private double[] max_InstitutionPrevalence;
	
	// fields for costSeeding
	private double costSeeding[];			// all the institutionPrevalence metrics (each for run and step)
	private double avgCostSeeding;			
	private double stdCostSeeding;
	
	private String expName;				// the key name of this experiment (all the MC runs)
	
	
	// ########################################################################	
	// Methods/Functions 	
	// ########################################################################

	//--------------------------- Getters and setters ---------------------------//


	/**
	 * @return the numberRuns
	 */
	public int getNumberRuns() {
		return numberRuns;
	}

	/**
	 * @param _numberRuns the numberRuns to set
	 */
	public void setNumberRuns(int _numberRuns) {
		this.numberRuns = _numberRuns;
	}

	/**
	 * @return the stdk_D
	 */
	public double[] getStdk_D() {
		return stdk_D;
	}

	/**
	 * @param _stdk_D the stdk_D to set
	 */
	public void setStdk_D(double _stdk_D[]) {
		this.stdk_D= _stdk_D;
	}

	/**
	 * @return the avgk_D
	 */
	public double[] getAvgk_D() {
		return avgk_D;
	}

	/**
	 * @param _avgk_D the avgk_D to set
	 */
	public void setAvgk_D(double _avgk_D[]) {
		this.avgk_D = _avgk_D;
	}

	/**
	 * @return the k_D
	 */
	public int[][] getk_D() {
		return k_D;
	}

	/**
	 * @param _k_D the k_D to set
	 */
	public void setk_D(int _k_D[][]) {
		this.k_D = _k_D;
	}
	
	/**
	 * @return the stdk_P
	 */
	public double[] getStdk_P() {
		return stdk_P;
	}

	/**
	 * @param _stdk_P the stdk_P to set
	 */
	public void setStdk_P(double[] _stdk_P) {
		this.stdk_P = _stdk_P;
	}

	/**
	 * @return the avgk_P
	 */
	public double[] getAvgk_P() {
		return avgk_P;
	}

	/**
	 * @param _avgk_P the avgk_P to set
	 */
	public void setAvgk_P(double _avgk_P[]) {
		this.avgk_P = _avgk_P;
	}

	/**
	 * @return the k_P
	 */
	public int[][] getk_P() {
		return k_P;
	}

	/**
	 * @param _k_P the k_P to set
	 */
	public void setk_P(int _k_P[][]) {
		this.k_P = _k_P;
	}

	
	public String getExpName() {
		return expName;
	}

	public void setExpName(String expName) {
		this.expName = expName;
	}

	
	/**
	 * @param _netWealth the netWealth to set for run _numberOfRun
	 */
	public void setGroupAchievementForRun (int _numberOfRun, double _grAchievement[]) {

		for (int i = 0; i < this.numberSteps; i++)
			this.groupAchievement[_numberOfRun][i] = _grAchievement[i];
	}
	
	/**
	 * @param 
	 */
	public void setCostSeedingForRun (int _numberOfRun, double _cost) {
		this.costSeeding[_numberOfRun] = _cost;
	}
		
	
	/**
	 * @param
	 */
	public void setInstitutionPrevalenceForRun (int _numberOfRun, double _instPrevalence[]) {

		for (int i = 0; i < this.numberSteps; i++)
			this.institutionPrevalence[_numberOfRun][i] = _instPrevalence[i];
	}
		
		
	/**
	 * @param _k_C k_C value to set for run _numberOfRun for the whole pop
	 */
	public void setk_CWholePopForRun(int _numberOfRun, int _k_C[]) {
		
		for (int i = 0; i < this.numberSteps; i++)
			this.k_C[_numberOfRun][i] = _k_C[i];
		
	}

	/**
	 * @param _k_D k_D value to set for run _numberOfRun
	 */
	public void setk_DWholePopForRun(int _numberOfRun, int _k_D[]) {
		
		for (int i = 0; i < this.numberSteps; i++)
			this.k_D[_numberOfRun][i] = _k_D[i];
		
	}

	/**
	 * @param _numberOfRun number of the run to which we will set the value of k_P 
	 * @param k_P k_P value to set for run _numberOfRun
	 */
	public void setk_PWholePopForRun(int _numberOfRun, int _k_P[]) {
		
		for (int i = 0; i < this.numberSteps; i++)
			this.k_P[_numberOfRun][i] = _k_P[i];
		
	}
	
	
	/**
	 * @return the stdk_C
	 */
	public double[] getStdk_C() {
		return stdk_C;
	}

	/**
	 * @param _stdk_C the stdk_C to set
	 */
	public void setStdk_C(double[] _stdk_C) {
		this.stdk_C = _stdk_C;
	}

	/**
	 * @return the avgk_C
	 */
	public double[] getAvgk_C() {
		return avgk_C;
	}

	/**
	 * @param _avgk_C the avgk_C to set
	 */
	public void setAvgk_C(double _avgk_C[]) {
		this.avgk_C = _avgk_C;
	}

	/**
	 * @return the k_C
	 */
	public int[][] getk_C() {
		return k_C;
	}

	/**
	 * @param _k_C the k_C to set
	 */
	public void setk_C(int _k_C[][]) {
		this.k_C = _k_C;
	}
	
	/**
	 * @return the numberSteps
	 */
	public int getNumberSteps() {
		return numberSteps;
	}

	/**
	 * @param _numberSteps the numberSteps to set
	 */
	public void setNumberSteps(int _numberSteps) {
		this.numberSteps = _numberSteps;
	}
	
    
	//--------------------------- Constructor ---------------------------//
	/**
	 * constructor of Stats
	 * @param _nRuns
	 */
	public RunStats (int _nRuns, int _nSteps){

		numberRuns = _nRuns;
		numberSteps = _nSteps;

		/*this.Cs = new StatsArrayData("k_C", _nRuns, _nSteps);
		this.Ds = new StatsArrayData("k_D", _nRuns, _nSteps);
		this.Ps = new StatsArrayData("k_P", _nRuns, _nSteps);
		this.IP = new StatsArrayData("institutionPrevalence", _nRuns, _nSteps);
		this.GA = new StatsArrayData("groupAchievement", _nRuns, _nSteps);*/
			
				
		// allocating space for metrics
		this.k_C = new int[_nRuns][_nSteps];
		this.k_D = new int[_nRuns][_nSteps];
		this.k_P = new int[_nRuns][_nSteps];
		this.groupAchievement = new double[_nRuns][_nSteps];
		this.institutionPrevalence = new double[_nRuns][_nSteps];
		this.costSeeding = new double[_nRuns];

		this.avgk_C = new double[_nSteps];	
		this.stdk_C = new double[_nSteps];
		this.min_k_C = new double[_nSteps];	
		this.max_k_C = new double[_nSteps];

		this.avgk_D = new double[_nSteps];	
		this.stdk_D = new double[_nSteps];
		this.min_k_D = new double[_nSteps];	
		this.max_k_D = new double[_nSteps];

		this.avgk_P = new double[_nSteps];	
		this.stdk_P = new double[_nSteps];
		this.min_k_P = new double[_nSteps];	
		this.max_k_P = new double[_nSteps];
		

		this.avgGroupAchievement = new double[_nSteps];	
		this.stdGroupAchievement = new double[_nSteps];
		this.min_GroupAchievement = new double[_nSteps];	
		this.max_GroupAchievement = new double[_nSteps];

		this.avgInstitutionPrevalence = new double[_nSteps];	
		this.stdInstitutionPrevalence = new double[_nSteps];
		this.min_InstitutionPrevalence = new double[_nSteps];	
		this.max_InstitutionPrevalence = new double[_nSteps];
		
	}
		
	/**
	 * This method prints all the steps values (avg and stdev of the MC RUNS) to a stream file (or to the console)
	 * @param writer that is opened before calling the function
	 */
	public void printTimeSeriesStats(PrintWriter writer) {
		
		writer.println("step;"
				+ "k_CAvg;k_CStd;k_CMin;k_CMax;k_DAvg;k_DStd;k_DMin;k_DMax;k_PAvg;k_PStd;k_PMin;k_PMax;" +
				"groupAchievementAvg;groupAchievementStd;groupAchievementMin;groupAchievementMax;" +
				"institutionPrevalenceAvg;institutionPrevalenceStd;institutionPrevalenceMin;institutionPrevalenceMax;" );
		
		for (int i = 0; i < this.numberSteps; i++) {
			
			String toPrint = i + ";" 
					+ String.format(Locale.US,"%.4f", this.avgk_C[i]) + ";" + String.format(Locale.US,"%.4f", this.stdk_C[i]) + ";" 
					+ String.format(Locale.US,"%.4f", this.min_k_C[i]) + ";" + String.format(Locale.US,"%.4f", this.max_k_C[i]) + ";"
					+ String.format(Locale.US,"%.4f", this.avgk_D[i]) + ";" + String.format(Locale.US,"%.4f", this.stdk_D[i]) + ";" 
					+ String.format(Locale.US,"%.4f", this.min_k_D[i]) + ";" + String.format(Locale.US,"%.4f", this.max_k_D[i]) + ";"
					+ String.format(Locale.US,"%.4f", this.avgk_P[i]) + ";" + String.format(Locale.US,"%.4f", this.stdk_P[i]) + ";" 
					+ String.format(Locale.US,"%.4f", this.min_k_P[i]) + ";"+ String.format(Locale.US,"%.4f", this.max_k_P[i]) + ";"
					+ String.format(Locale.US,"%.4f", this.avgGroupAchievement[i]) + ";" + String.format(Locale.US,"%.4f", this.stdGroupAchievement[i]) + ";" 
					+ String.format(Locale.US,"%.4f", this.min_GroupAchievement[i]) + ";" + String.format(Locale.US,"%.4f", this.max_GroupAchievement[i]) + ";" 
					+ String.format(Locale.US,"%.4f", this.avgInstitutionPrevalence[i]) + ";" + String.format(Locale.US,"%.4f", this.stdInstitutionPrevalence[i]) + ";"
					+ String.format(Locale.US,"%.4f", this.min_InstitutionPrevalence[i]) + ";" + String.format(Locale.US,"%.4f", this.max_InstitutionPrevalence[i]) + ";"
					+ "\n";  				
			
			// returnTimeSeriesStatsAtStep
			
			writer.print (toPrint);
		}			
	}
		

	/**
	 * This method prints summarized stats (avg and std of MC runs) to a stream file (or to the console)
	 * @param append true if we append the line to an existing file, false if we destroy it first
	 * @param writer that is opened before calling the function
	 */
	public void printSummaryStats (PrintWriter writer, boolean append) {
		
		String toPrint = "keyNameExp;" + this.expName + ";k_C;" + 
				String.format(Locale.US,"%.4f", this.avgk_C[(this.numberSteps - 1)]) + ";" + 
				String.format(Locale.US,"%.4f", this.stdk_C[(this.numberSteps - 1)]) + ";k_D;" + 
				String.format(Locale.US,"%.4f", this.avgk_D[(this.numberSteps - 1)]) + ";" + 
				String.format(Locale.US,"%.4f", this.stdk_D[(this.numberSteps - 1)]) + ";k_P;" +
				String.format(Locale.US,"%.4f", this.avgk_P[(this.numberSteps - 1)]) + ";" + 
				String.format(Locale.US,"%.4f", this.stdk_P[(this.numberSteps - 1)]) + ";groupAchievement;" +
				String.format(Locale.US,"%.4f", this.avgGroupAchievement[(this.numberSteps - 1)]) + ";" + 
				String.format(Locale.US,"%.4f", this.stdGroupAchievement[(this.numberSteps - 1)]) + ";institutionPrevalence;" +
				String.format(Locale.US,"%.4f", this.avgInstitutionPrevalence[(this.numberSteps - 1)]) + ";" + 
				String.format(Locale.US,"%.4f", this.stdInstitutionPrevalence[(this.numberSteps - 1)]) + ";costSeeding;" +
				String.format(Locale.US,"%.4f", this.avgCostSeeding) + ";" + 
				String.format(Locale.US,"%.4f", this.stdCostSeeding) + ";";
		
		// returnSummaryStatsAtFinalStep
		
		if (append) {
			writer.append (toPrint);
			writer.append("\n");
		} else {
			writer.println (toPrint);
		}				
				
	}
	
	/**
	 * This method prints (by appending to an existing file) the 
	 * summarized stats (avg and std of MC runs) to a stream file (or to the console)
	 * @param writer that is opened before calling the function
	 */
	public void appendSummaryStats (PrintWriter writer) {		
		printSummaryStats (writer, true);				
	}
	
	/**
	 * This method prints all the stats of the MC runs (by appending to an existing file) 
	 * to a stream file (or to the console)
	 * @param writer that is opened before calling the function
	 */
	public void appendAllStats (PrintWriter writer) {		
		printAllStats (writer, true);				
	}

	
	/**
	 * This method prints all the stats of the MC runs to a stream file (or to the console)
	 * @param writer that is opened before calling the function
	 * @param append true if we append the line to an existing file, false if we destroy it first
	 */
	public void printAllStats (PrintWriter writer, boolean append) {
		 			
		for (int i = 0; i < this.numberRuns; i++) {
			
			String toPrint = "keyNameExp;" + this.expName + ";MCrun;" + i + ";k_C;" 
				+  String.format(Locale.US,"%d", this.k_C[i][(this.numberSteps - 1)]) + ";k_D;" 
				+ String.format(Locale.US,"%d", this.k_D[i][(this.numberSteps - 1)]) + ";k_P;" 
				+ String.format(Locale.US,"%d", this.k_P[i][(this.numberSteps - 1)]) + ";groupAchievement;" 
				+ String.format(Locale.US,"%f", this.groupAchievement[i][(this.numberSteps - 1)]) + ";institutionPrevalence;" 
				+ String.format(Locale.US,"%f", this.institutionPrevalence[i][(this.numberSteps - 1)]) + ";" 
				+ String.format(Locale.US,"%f", this.costSeeding[i]) + ";\n";
		
			
			if (append) 	
				writer.append (toPrint);				
			else 					
				writer.print (toPrint);					
		}	
	}
	
	/**
	 * This method prints summarized stats of the last quartile of the simulation (avg and std of MC runs) 
	 * to a stream file (or to the console)
	 * @param append true if we append the line to an existing file, false if we destroy it first
	 * @param writer that is opened before calling the function
	 */
	public void printSummaryStatsByAveragingLastQuartile (PrintWriter writer, boolean append) {
		
		double lastQuartilek_C = 0.;
		double lastQuartilek_D = 0.;
		double lastQuartilek_P = 0.;
		double lastQuartileInstitutionPrevalence = 0.;
		double lastQuartileGroupAchievement = 0.;

		double lastQuartilek_CStd = 0.;
		double lastQuartilek_DStd = 0.;
		double lastQuartilek_PStd = 0.;
		double lastQuartileInstitutionPrevalenceStd = 0.;
		double lastQuartileGroupAchievementStd = 0.;
		
		// check the number of steps which means the last 25% of them
		int quartileSteps = (int) Math.round(0.25*this.numberSteps);
		
		for ( int j = 1; j <= quartileSteps; j++) {
			
			// averaging the MC outputs for the last quartile of the simulation
			
			lastQuartilek_C += this.avgk_C[(this.numberSteps - j)];
			lastQuartilek_D += this.avgk_D[(this.numberSteps - j)];
			lastQuartilek_P += this.avgk_P[(this.numberSteps - j)];
			lastQuartileGroupAchievement += this.avgGroupAchievement[(this.numberSteps - j)];
			lastQuartileInstitutionPrevalence += this.avgInstitutionPrevalence[(this.numberSteps - j)];
			
			// averaging the MC stdev outputs for the last quartile of the simulation
			lastQuartilek_CStd += this.stdk_C[(this.numberSteps - j)];
			lastQuartilek_DStd += this.stdk_D[(this.numberSteps - j)];
			lastQuartilek_PStd += this.stdk_P[(this.numberSteps - j)];
			lastQuartileGroupAchievementStd += this.stdGroupAchievement[(this.numberSteps - j)];
			lastQuartileInstitutionPrevalenceStd += this.stdInstitutionPrevalence[(this.numberSteps - j)];	
			
		}

		lastQuartilek_C /= quartileSteps;
		lastQuartilek_D /= quartileSteps;
		lastQuartilek_P /= quartileSteps;
		lastQuartileGroupAchievement /= quartileSteps;
		lastQuartileInstitutionPrevalence /= quartileSteps;
		
		lastQuartilek_CStd /= quartileSteps;
		lastQuartilek_DStd /= quartileSteps;
		lastQuartilek_PStd /= quartileSteps;
		lastQuartileGroupAchievementStd /= quartileSteps;
		lastQuartileInstitutionPrevalenceStd /= quartileSteps;
		
		
		// dataX.returnSummaryStatsByAveragingLQ()
		
		String toPrint = "LQkeyNameExp;" + this.expName + ";k_CLQ;" 
				+ String.format(Locale.US,"%.4f", lastQuartilek_C) + ";" + String.format(Locale.US,"%.4f", lastQuartilek_CStd) 	+ ";k_DLQ;" 
				+ String.format(Locale.US,"%.4f", lastQuartilek_D) + ";" + String.format(Locale.US,"%.4f", lastQuartilek_DStd) + ";k_PLQ;" 
				+ String.format(Locale.US,"%.4f", lastQuartilek_P) + ";" + String.format(Locale.US,"%.4f", lastQuartilek_PStd) + ";groupAchievementLQ;" 
				+ String.format(Locale.US,"%.4f", lastQuartileGroupAchievement) + ";" + String.format(Locale.US,"%.4f", lastQuartileGroupAchievementStd) + ";institutionPrevalenceLQ;" 
				+ String.format(Locale.US,"%.4f", lastQuartileInstitutionPrevalence) + ";" + String.format(Locale.US,"%.4f", lastQuartileInstitutionPrevalenceStd) + ";";
				
		if (append) {
			writer.append (toPrint);
			writer.append("\n");
		} else {
			writer.println (toPrint);
		}	
			
	}
	
	
	/**
	 * This method prints all the averaging stats in the last quartile of the simulation for all 
	 * the MC runs to a stream file (or to the console)
	 * @param writer that is opened before calling the function
	 * @param append true if we append the line to an existing file, false if we destroy it first
	 */
	public void printAllStatsByAveragingLastQuartile (PrintWriter writer, boolean append) {
		
		for ( int i = 0; i < this.numberRuns; i++) {
			
			// dataX.computeLastQuartile()
						
			double lastQuartileNW = 0.;
			double lastQuartilek_C = 0.;
			double lastQuartilek_D = 0.;
			double lastQuartilek_P = 0.;
			double lastQuartileStrategyChanges = 0.;
			double lastQuartileGroupAchievement = 0.;
			double lastQuartileInstitutionPrevalence = 0.;
			
			// check the number of steps which means the last 25% of them
			int quartileSteps = (int)Math.round(0.25*this.numberSteps);
			
			for ( int j = 1; j <= quartileSteps; j++) {
				lastQuartilek_C += this.k_C[i][(this.numberSteps - j)];
				lastQuartilek_D += this.k_D[i][(this.numberSteps - j)];
				lastQuartilek_P += this.k_P[i][(this.numberSteps - j)];
				lastQuartileGroupAchievement += this.groupAchievement[i][(this.numberSteps - j)];
				lastQuartileInstitutionPrevalence += this.institutionPrevalence[i][(this.numberSteps - j)];
			}

			lastQuartileNW /= quartileSteps;
			lastQuartilek_C /= quartileSteps;
			lastQuartilek_D /= quartileSteps;
			lastQuartilek_P /= quartileSteps;
			lastQuartileStrategyChanges /= quartileSteps;
			lastQuartileInstitutionPrevalence /= quartileSteps;
			lastQuartileGroupAchievement /= quartileSteps;
			
			// dataX. 
			String toPrint = "LQKeyNameExp;" + this.expName + ";MCrun;" + i + ";netWealthLQ;" + 
					String.format(Locale.US,"%.4f", lastQuartileNW) + ";k_CLQ;" 
					+ String.format(Locale.US,"%.4f", lastQuartilek_C) + ";k_DLQ;" 
					+ String.format(Locale.US,"%.4f", lastQuartilek_D) + ";k_PLQ;" 
					+ String.format(Locale.US,"%.4f", lastQuartilek_P) + ";groupAchivementLQ;" 
					+ String.format(Locale.US,"%.4f", lastQuartileGroupAchievement) + ";institutionPrevalenceLQ;" 
					+ String.format(Locale.US,"%.4f", lastQuartileInstitutionPrevalence) + ";strategyChangesLQ;" 
					+ String.format(Locale.US, "%.4f", lastQuartileStrategyChanges) + ";\n";
					
			if (append) 
				writer.append (toPrint);		
			else 
				writer.print (toPrint);
		}		
	}
	
	
	/**
	 * This method is for calculating all the statistical information for 
	 * the runs of the metrics
	 * 	 
	 */
	public void calcAllStats () {
					
		// dataX.calcAllStats()
		
		for( int j = 0; j < this.numberSteps; j++) {
			
			// Get a DescriptiveStatistics instance
			DescriptiveStatistics statsk_C = new DescriptiveStatistics();
			DescriptiveStatistics statsk_D = new DescriptiveStatistics();
			DescriptiveStatistics statsk_P = new DescriptiveStatistics();
			DescriptiveStatistics statsInstitutionPrevalence = new DescriptiveStatistics();
			DescriptiveStatistics statsGroupAchievement = new DescriptiveStatistics();
			DescriptiveStatistics statsCostSeeding = new DescriptiveStatistics();
			
			// Add the data from the array
			for( int i = 0; i < this.numberRuns; i++) {
				
		        statsk_C.addValue(this.k_C[i][j]);
		        statsk_D.addValue(this.k_D[i][j]);
		        statsk_P.addValue(this.k_P[i][j]);
		        	        
		        statsGroupAchievement.addValue(this.groupAchievement[i][j]);			        
		        statsInstitutionPrevalence.addValue(this.institutionPrevalence[i][j]);	 
		        statsCostSeeding.addValue(this.costSeeding[i]);
		        
			}

			// calc mean and average for all of them
			
			this.avgk_C[j] = statsk_C.getMean();	
			this.stdk_C[j] = statsk_C.getStandardDeviation();
			this.min_k_C[j] = statsk_C.getMin();	
			this.max_k_C[j] = statsk_C.getMax();
			
			this.avgk_D[j] = statsk_D.getMean();	
			this.stdk_D[j] = statsk_D.getStandardDeviation();
			this.min_k_D[j] = statsk_D.getMin();	
			this.max_k_D[j] = statsk_D.getMax();

			this.avgk_P[j] = statsk_P.getMean();	
			this.stdk_P[j] = statsk_P.getStandardDeviation();
			this.min_k_P[j] = statsk_P.getMin();	
			this.max_k_P[j] = statsk_P.getMax();
			

			this.avgGroupAchievement[j] = statsGroupAchievement.getMean();	
			this.stdGroupAchievement[j] = statsGroupAchievement.getStandardDeviation();
			this.min_GroupAchievement[j] = statsGroupAchievement.getMin();	
			this.max_GroupAchievement[j] = statsGroupAchievement.getMax();

			this.avgInstitutionPrevalence[j] = statsInstitutionPrevalence.getMean();	
			this.stdInstitutionPrevalence[j] = statsInstitutionPrevalence.getStandardDeviation();
			this.min_InstitutionPrevalence[j] = statsInstitutionPrevalence.getMin();	
			this.max_InstitutionPrevalence[j] = statsInstitutionPrevalence.getMax();
			
			this.avgCostSeeding = statsCostSeeding.getMean();	
			this.stdCostSeeding = statsCostSeeding.getStandardDeviation();
		}				
	}

}
